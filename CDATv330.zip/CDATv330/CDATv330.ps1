using namespace system.xml.linq
 
# Case Data Acquistion Tool Version 3.3.0
# For Powrshell - Please Run in Admin Powershell if not elevated 
# Please issue "set-executionpolicy Unrestricted" to run this powershell script



param
            (

                [parameter(Mandatory=$False)]

                [switch] $ALL,
                [switch] $Preload,
                [switch] $EVENTS,
                [switch] $Drivers,
                [switch] $Security,
                [switch] $Network,
                [switch] $BIOS,
                [switch] $Power,
                [switch] $Data,
                [switch] $Issues,
                [switch] $Readme

            )

# Intro Message
Write-output ""
Write-output "Loading CDAT, please wait..."
Write-output ""

# Version ID

$CDATVer = "3.3.0"
$CDATv = "330"

#Dir Prep
            #Temp Dir Logic
            
            $Tempdir = "C:\temp\"
                    
            If (!(test-path $Tempdir))
            {
                [VOID] (mkdir $Tempdir)
            }

# System type determination

$systype=(Get-WmiObject win32_ComputerSystem).PCSystemType 

# Quick Data Variables

If($systype -eq 2)

        {
                $BatteryPN = (Get-WmiObject -namespace root\wmi -class BatteryStaticData).DeviceName
        }

$Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
$SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
$SerialNumber = (Get-CimInstance win32_bios).serialnumber
$Time = ((get-date).ToLocalTime()).ToString("DD-MM-yyyy HHmm")
$ECMajor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMajorVersion
$ECMinor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMinorVersion
$Baseboard = (Get-WmiObject win32_baseboard).SerialNumber

$AntiVirus =  Get-WmiObject -class "AntiVirusProduct" -Namespace "root\SecurityCenter2" | Format-table displayName, timestamp
$Firewall = Get-WmiObject -class "FirewallProduct" -Namespace "root\SecurityCenter2" | Format-table displayName, timestamp
$registryPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power"
$registryName = "HiberbootEnabled"
$Refresh = (Get-WmiObject Win32_videocontroller).currentrefreshrate

$ProcDetect = (Get-WmiObject win32_processor).Manufacturer
$ARMDetect = (Get-WmiObject win32_processor).SocketDesignation

$ProcDetect = (Get-WmiObject win32_processor).Manufacturer
#$Wlansvc = (sc.exe qc "wlansvc" | Select-String "START_TYPE" | ForEach-Object { ($_ -replace '\s+', ' ').trim().Split(" ") | Select-Object -Last 1 })


# Quick Data Battery Variables
if ($systype -eq 2)
        {
            $designCap = (get-wmiobject -namespace root\wmi batteryStaticData).DesignedCapacity
            $RemainingCap = (Get-WmiObject -Namespace 'ROOT\WMI' BatteryStatus).RemainingCapacity
            $LastChargedCap = ((Get-WmiObject -Namespace 'ROOT\WMI' BatteryFullChargedCapacity).FullChargedCapacity)
            $manufacturer = (get-wmiobject -namespace root\wmi Batterystaticdata).ManufactureName
            $pluggedIn = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline
            $charging = (get-wmiobject -namespace root\wmi batterystatus).Charging
            $discharging = (get-wmiobject -namespace root\wmi batterystatus).Discharging
            $cycleCount = (get-wmiobject -namespace root\wmi batteryCycleCount).CycleCount
            $health = [int](($LastChargeDCap * 100) / $designCap)
        }


# Misc Functions

Function DockCollection
            {


            }
Function OEMCheck 

                {
                        If ((Get-CimInstance -ClassName Win32_bios).manufacturer -eq "Lenovo")
                                {

                                        If (test-path .\Templates\)

                                                {

                                                }

                                        else 
                                        
                                                {
                            
                                                    $CDATv = "330"
                                                    Write-Output "The Templates directory is not present, please ensure Templates directory is in the same directory as CDATv$CDATv and try again"
                                                    Exit
                                                
                                                }
                                    }
                        
                        Else 
                                    {
                                        $SysMFG =(Get-CimInstance -ClassName Win32_bios).manufacturer

                                        Write-output ""
                                        Write-output "CDAT only runs on Lenovo branded systems, this system is a $SysMFG"
                                        Write-output ""
                                        EXIT

                                    }
                }

Function FailSample

                {
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber

                    Write-Output "=======================================" 
                    Write-output "     System Service Check List         " 
                    Write-Output "=======================================" 
                    Write-Output " " 
                    Write-Output "This system is $Model $SystemFamily $SerialNumber"
                    Write-output "If a system sample is requested or required by Lenovo to debug your issue."
                    Write-Output "Please include the following information below."
                    ### OS Credentials Request
                    Write-Output ""
                    Write-Output "*Please provide Login information with admin credentials, that include the login ID and password."

                    ### Supervisor password check
                    $SVPCheck = (Get-WmiObject -Class Win32_ComputerSystem -Namespace Root\cimv2).AdminPasswordStatus
                    if ($SVPCheck -eq 1)
                            {
                            
                                Write-Output "*Please provide the Supervisor password for the system sample you are providing to Lenovo."

                            }
                    else
                            {
                               
                            } 

                    ### Bitlocker check
                    $BLStatus = (Get-BitLockerVolume).ProtectionStatus
                    if ($BLStatus -eq "On")
                            {
                                Write-Output "*Please Provide the Bitlocker Recovery Key."

                            }
                    
                    ### Memory Dump Check
                    $DumpCHK = Test-path -Path C:\Windows\*Memory*.dmp
                    $TargetDir = "C:\Windows\"
        
                    If ($DumpCHK -eq $True)
                        {
                            Write-output "*If this system is sent to Lenovo as a system sample, please provide the following memory dump files." 
                            get-ChildItem $targetDir Memory*.dmp
        
                        }
                    Write-output ""
                    ### Mini Dump Check
                    $MiniCheck = test-path C:\Windows\minidump\*
                    $MiniTarget = "C:\Windows\minidump"
                    If ($MiniCheck -eq $True)
                    {
                        Write-output "*Please provide the following mini-dump files" 
                        get-ChildItem $MiniTarget *.dmp
    
                    }
                    
                }

Function CDATHelp
                {
                     #Banner Dialog

                Write-Host "`n`t`t **********************************************`n"
                Write-Host "`n`t`t       CDATv$CDATVEr Readme and Change Log     `n"
                Write-Host "`n`t`t **********************************************`n"


                # ReadMe

                write-output '
    
                                .DESCRIPTION
                                    This tool runs from powershell or from EXE to collect logs for case analysis.
                                
                                .REQUIREMENTS
                                    For PS1 - Must run in admin Power Shell console with scripts enabled.
                                    For PS1 and EXE - Templates must be in the root folder of Ps1 or EXE.
                            
                                .USAGE
                                    For PS1
                                        PS> .\CDAT(Version).ps1 (For selection Menu)
                                        PS> .\CDAT(Version).ps1 -[Command line option]
                                    For EXE
                                        Double click or execute from CLI.
                                
                                .MENU OPTIONS

                                    Choose the appropriate menu item to run that specific collection.

                                    [ 1] All Data Collections.
                                    [ 2] Windows & Preload Collection.
                                    [ 3] Windows Events & BSOD Mini Dump Collection.
                                    [ 4] HWD, Vpro, ME & Driver Collection.
                                    [ 5] BCD, TPM, and BitLocker Collection.
                                    [ 6] Network and WAN Collection.
                                    [ 7] BIOS Setting Collection.
                                    [ 8] Power, Sleep, and Battery Collection.
                                    [ 9] Quick System Data Collection.
                                    [10] Potential Issues Collection.
                                    [R]  Readme and Changes

                                .COMMAND LINE OPTIONS

                                    -All 
                                        Runs all collections available.
                                    
                                    -Preload
                                        Collects Windows and Preload data.
                                    
                                    -Events 
                                        Collects Windows event logs and Mini Dump files.
                                    
                                    -Drivers 
                                        Collects hardware and driver information.

                                    -Security
                                        Collects Boot Data Config, TPM and Bitlocker infromation.
                                    
                                    -Network
                                        Collects Network and WAN collection data.

                                    -BIOS 
                                        Collects Bios Setting Information.

                                    -Power 
                                        Collects power, sleep, and battery data.
                                    
                                    -Data 
                                        Collects Quick system data.

                                    -Issues
                                        Collects Potential Issues collection.

                                    -Readme 
                                        Shows readme and help.


                                .CHANGE LOG

                                    CDATv3.3.0 Changes:
                                    ===================
                                        Fixed - Issue with WER report collection logs 1001.
                                        Fixed - Issue with Dock Manager log collection.
                                        Fixed - Issue where Win event logs messages are truncated.
                                        Fixed - Issue where Vantage logs are truncated.
                                        Fixed - Issue where drivers.log is not generated by option [4].
                                        Fixed - Issue with DSC detection - added version 4.1.
                                        Fixed - Issue with Odometer data in Quick Data reporting incorrectly.
                                        Fixed - Highlighted "Lenovo Commercial Vantage not installed" in red text.
                                        Fixed - Issue with Windows Startup log being truncated.
                                        Fixed - Issue with hotfix log being truncated.
                                        Fixed - Issue with Services log being truncated.
                                        Fixed - Issue with Scheduled Tasks log being truncated.
                                        Fixed - Issue with WindowsInstalledApps log being truncated.


                                    CDATv3.2.9 Changes:
                                    ===================
                                        Fixed - Dxdiag files being leftover instead of deleted.
                                        Fixed - Dxdiag file names.
                                        Fixed - Shortened some file names.
                                        Fixed - Battery Slider text grammar.
                                        Fixed - Improved LCVantage detection.
                                        Added - Readme info for DSC detection and related tip.
                                        Added - QuickData > SMBIOS version data. 
                                        Added - Power manager registry log data.
                                        Added - Smart standby registry log data.


                                    CDATv3.2.8 Changes:
                                    ===================
                                        Fixed - Message issue with MFGSTAT. 
                                        Fixed - Issue with system event log collection.  
                                        Fixed - SRUMUtil not creating HTML report. 
                                        Fixed - Various messaging issues. 
                                        Fixed - QuickData - camera detection issue. 
                                        Fixed - DSC detection.
                                        Fixed - QuickData - no banner for Lenovo updates when LCVantage is not installed.
                                        Fixed - Issue with application even log txt collection.
                                        Added - QuickData - BIOS Boot Post Time.    
                                                                   

                                    CDATv3.2.7 Changes:
                                    ===================
                                        Fixed - Issue with command line switches with .exe.
                                        Fixed - Issue with Quickdata biometric device query.
                                        Added - Sleepstudy duration to max - 28 days.

                                    CDATv3.2.6 Changes:
                                    ===================
                                        Fixed - QuickData Collection is no longer overwritten after repeat runs.
                                        Fixed - DxDiag Error when run option 1.
                                        Fixed - QuickData Collection > OS Original Install Date: removed extra characters.
                                        Fixed - QuickData Collection > Disk Information not reported sdd correctly.
                                        Fixed - BIOS Settings Detection between business and consumer systems.
                                        Fixed - QuickData > Video Cards - Ficed an issue with systems with two display adapters.
                                        Fixed - QUickData > Missing windows update will not error if internet is not connected.
                                        Added - QuickData Collection > CDAT Observations.
                                        Added - Network > WlanReport set to 45 days.
                                        Added - QuickData > Power > Power Slider added.
                                        Added - Command line options.

                                    CDATv3.2.5 Changes:
                                    ===================
                                        Fixed - Various Bugs.

                                    CDATv3.2.4 Changes:
                                    ===================
                                        Added - Bluetooth System Report.
                                        Added - Various Changes to Quick Data Collection.
                                        Added - Active Firewall list to Quick Data Collection.
                                        Added - Support for Desktop and Workstation.
                                        Added - Battery Report now records a duration of 14 days.
                                        Added - QuickData > Original OS Install Date.
                                        Fixed - Various Bugs.
                                        Fixed - System Up Time values in Quick Data Collection.
                                        Fixed - Quick Data Collection > Missing WU Dialog.
                                        Fixed - Quick Data Collection > Video Card to display mulitple video devices seperately.
                                        Fixed - Unexpected Shutdown logic.
                                        Fixed - CDAT now reports DT Bios settings correctly.


                                    CDATv3.2.3 Changes:
                                    ===================
                                        Added - Quick Data Collection > Added key power timer values.
                                        Added - Potential Issues > Flags Fast Startup if not enabled.
                                        Added - Potential Issues > Alert if Critical Battery Action is set to Do Nothing.
                                        Added - Potential Issues > Alert if Battery Cycle count is less than 50.
                                        Added - Potential Issues > Alert the number of Unexpected shutdowns.
                                        


                                    CDATv3.2.2 Changes:
                                    ===================
                                        Fixed - An issue with MSNFO32.txt collection.
                                        Fixed - Bug that reported some Dock types incorrectly.
                                        Added - Attached Monitor Names to QuickData > Attached Displays.
                                        Added - powercfg -qh to gather more detailed power data sets.
                                        Added - Smart Standby Driver Version in Quick Data Collection.
                                        Added - MFG Date (if Preload installed) to Quick Data Collection.
                                        Added - Battery Barcode Number to Quick Data Collection.
                                        Added - Standby Budget Percentage to Quick Data Collection.
                                        Added - Sleep Diagnostics Report.
                                        Added - Attached USB Flash Drives to Quick Data Collection.
                                        Added - Power Timer Log.

                                    CDATv3.2.1 Changes:
                                    ===================
                                        Fixed - Various Bugs.
                                        Fixed - Moved Dxdiag log to Video and Graphics dir.
                                        Added - Total Virtual Memory to Quick Data.

                                    CDATv3.2.0 Changes:
                                    ===================
                                        Fixed - Various Bugs.
                                        Added - System Known Issues Report.
                                        Added - Video Card driver Info and PNP to Quick Collection.
                                        Added - Dxdiag log to options 1 and 4.

                                    CDATv3.1.9 Changes:
                                    ====================
                                        Fixed - Some Dock Information reports twice in Quick Data Collection.
                                        Fixed - Teams Detection code bug.
                                        Fixed - Lenovo View Driver extenstion detection issue.
                                        Added - Teams, Office, and Zoom Detection in Quick Data Collection.
                                        Added - Quick Data now records UUID.
                                        Added - Sleep states to Quick Data report.
                                        Added - SRUMUTIL.HTML to "Power & Battery" and "All" Collections.

                                    CDATv3.1.8 Changes:  
                                    ====================
                                        Fixed - Renamed devicemanager.nfo to MSINFO32.nfo.
                                        Fixed - Issue where networkinterface logs are incosistent.
                                        Fixed - Updated Readme information for EXE.
                                        Added - Quick Collection Data for each menu option 2-8.
                                        Added - Improved dock detection to include more models.
                                        Added - Lenovo View Driver Extension Check in Quick Data > Attached Cam.

                                    CDATv3.1.7 Changes:  
                                    ====================
                                        Added - OEM INF to driver Log.
                                        Fixed - Escalating to Admin message issue.
                                        Fixed - Various Bugs

                                    CDATv3.1.6 Changes:  
                                    ====================
                                        Added - Enhanced BIOS Setting Log.
                                        Added - Dock Detection for Docks with USB-C Video out.
                                        Fixed - Various Bugs
                                        
                                    CDATv3.1.5 Changes:  
                                    ====================
                                        FIXED - Various Bugs.
                                        Added - Driver INF ID File.
                                        Added - Driver INF Install Time Log.

                                    CDATv3.1.4 Changes:  
                                    ====================
                                        FIXED - Various Bugs.
                                        FIXED - Audio device driver file was truncated.
                                        FIXED - Issue where ARM is not identified in Quick Collection.
                                        FIXED - XML file collection error.
                                        Added - Driver collection list INF file name.

                                    CDATv3.1.3 Changes:  
                                    ====================
                                        FIXED - Various Bugs.
                                        Added - XML File collection.
                                        Added - Intel ME FW to Quick Data.
                                        Added - Preload Flag to Quick Data.

                                    CDATv3.1.2 Changes:  
                                    ====================
                                        Added - System Active/Idle Time Logs.
                                        Added - Event logs saved as text files.
                                        FIXED - DeviceManager Logs.
                                        FIXED - Various Bugs.

                                    CDATv3.1.1 Changes:  
                                    ====================
                                        Added - Lenovo- Dock dir in All Collection.
                                        Added - Gathering Dock Attach History.
                                        Added - Gathering Various Dock Logs.
                                        FIXED - DSC detection.
                                        FIXED - Various Bugs.

                                    CDATv3.1.0 Changes:  
                                    ====================
                                    	Added - Audio Properties to QuickDataCollection
                                    	Added - DSC Status to All Data Collections
                                    	Added - Graphics resolution to QuickDataCollection
                                    	Added - Graphics refresh rate to QuickDataCollection
                                    	Added - Screen saver timeout to QuickDataCollection 

                                    CDATv3.0.8 Changes:  
                                    ====================
                                    	Added - Transcript of onscreen log progress
                                    	Added - WLAN Report
                                    	Added - SMBIOS Report
                                    	Added - Registry Data Report
                                    	Added - Windows Environment Variables Report
                                    	Added - IM Controller Plugin Version Log
                                    	Added - Reboot History Report

                                    CDATv3.0.7 Changes:  
                                    ====================
                                    	Added - Zip files now have corresponding option number (1-9).
                                    	Fixed - When running option 5, errors fixed.

                                    CDATv3.0.6 Changes:  
                                    ====================
                                    	Fixed - Misc Bugs.
                                     
                                    CDATv3.0.5 Changes:  
                                    ====================
                                    	Added - Escalate to Admin if not launched as Admin Powershell.
                                    	Added - Alternative battery data detection for ARM systems.
                                    	Added - DeviceManager.NFO and DeviceManager.txt are now collected.
                                    	Added - Detection if SVP is set (Quick Data Collection).
                                    	Added - Detection for Locked BIOS Setting (Quick Data Collection).
                                    	Added - System Uptime to Quick Data Collection.
                                    	Fixed - When Design Capacity is not reported by the system battery.
                                                                    
                                    CDATv3.0.4 Changes:  
                                    ====================
                                    	Fixed - Misc Bugs
                                    	Fixed - System Update Log to read LenovoVantageSystemUpdate.log

                                    CDATv3.0.3 Changes:  
                                    ====================
                                    	Fixed - Vantage Detection Code.
                                    	Added - PowerShell Version data to Quick Data Collection Log.

                                    CDATv3.0.2 Changes:  
                                    ====================
                                    	Fixed - Misc Messaging

                                    CDATv3.0.1 Changes:  
                                    ====================
                                    	Fixed - Misc Messaging

                                    CDATv3.0.0 Changes:  
                                    ====================

                                    	Added - Menu option for Quick Data Collection.
                                    	Added - Disk FW and Temp available in Quick Data Collection and HWD Information.
                                    	Added - CPU Temp in Quick Data Collection.
                                    	Added - Various Quick Data Collection Sections.       
                            ' | more
                }

### START OF Functions ###
# Misc Functions

Function LenovoBIOS 

                    {
                        $systype=(Get-WmiObject win32_ComputerSystem).PCSystemType 
                        If ($systype -eq 2)
                                            {
                                                If ($True -eq $(Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}))
                                                    {
                                                        
                                                        


                                                                Write-Output "======================================="
                                                                Write-output "    BIOS Settings                      " 
                                                                Write-Output "=======================================" 
                                                                                        
                                                                #ThinkPad Logic
                                                                                                    
                                                                Get-BiosSettings | ForEach-Object{$_.View()} 
                                                                                                    
                                                                #Get-WmiObject -Namespace root\wmi -Class Lenovo_BiosSetting | Select-object CurrentSetting 
                                                            
                                                                    


                                                    }
                                        
                                            else    {

                                                            Write-Output "======================================="
                                                            Write-output "    BIOS Settings                      " 
                                                            Write-Output "=======================================" 
                                                        
                                                            Write-output "This System does not have an API interface to BIOS settings" 
                                                
                                                    }
                                            }  

                            If ($systype -eq 1)

                                            {
                                                If ($True -eq $(Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}))
                                                
                                                    {
                                                        Write-Output "======================================="
                                                        Write-output "    BIOS Settings                      " 
                                                        Write-Output "=======================================" 
                                                        $DesktopBIOS = (Get-WmiObject -class Lenovo_BiosSetting -namespace root\wmi | select-object currentsetting | Out-String).Trim()
                                                        $DesktopBIOS
                                                    }
                                                
                                                else 

                                                    {
                                                        Write-Output "======================================="
                                                        Write-output "    BIOS Settings                      " 
                                                        Write-Output "=======================================" 
                                                    
                                                        Write-output "This System does not have an API interface to BIOS settings" 
                                                    }
                                            }
                    }

Function BattFW
                {
                    $BattFW = (Get-PnpDevice -Class Firmware | Get-PnpDeviceProperty -KeyName "DEVPKEY_Device_DeviceDesc" | Where-object {$_.Data -like "*battery*"}).Data 
                    if ($systype -eq 2)
                        {
                            if(!($BattFW))
                                {
                                    Write-Output "Battery Firmware: Battery FW not detected"
                                }
                            else
                                {
                                    Write-Output "Battery Firmware:             $BattFW"
                                }


                        }
                }
function UnexpectedShutdown
                {
                    if ($True -eq (Get-EventLog -LogName System -EntryType error | Where-Object{$_.Source -ne "DCOM"}  | Where-Object{$_.Message -like "The previous system shutdown*"}))
                        {
                            
                            $UnexpectedShutdowns = (Get-EventLog -LogName System -EntryType error | Where-Object{$_.Source -ne "DCOM"}  | Where-Object{$_.Message -like "The previous system shutdown*"} | Measure-object -line).Lines
                                        
                                        if ($UnexpectedShutdowns -gt 0)
                                                {
                                                    Write-Output "* This system shows $UnexpectedShutdowns unexpected shutdowns, which may indicate an issue or trigger point, please review the Unexpected Shutdowns section of this report."
                                                }

                        }
                                            

                    else                
                        {

                            write-output "* This system shows 0 unexpected shutdowns, which may indicate an issue or trigger point, please review the Unexpecteed Shutdowns section of this report."

                        }

                }
Function BT
            {
                Write-Output "======================================="
                Write-output "    Bluetooth Information              " 
                Write-Output "=======================================" 
                $BTDevice = (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Bluetooth(R)*'}).Description
                $BTDriver = (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Bluetooth(R)*'}).DriverVersion
                Write-output "Device: $($BTDevice)"
                Write-output "Driver: $($BTDriver)"
                (write-output  $(Get-PnpDevice | Where-Object {$_.Class -eq "Bluetooth"} | Format-Table -AutoSize -Wrap) )
                Write-output ""
                Write-output "Other BT Driver Information"
                Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Bluetooth*'} | select-object DeviceName, DriverVersion | format-table -wrap
            }
Function ActiveFirewall
        {
            $computer   = '.'                                             # $env:COMPUTERNAME
            $namespaces = "ROOT\SecurityCenter", "ROOT\SecurityCenter2"
            $classname  = "FirewallProduct"
            $ActiveFireWall = foreach ($namespace in $namespaces) {
                $aux = Get-WmiObject -Class $classname -Namespace $namespace -ComputerName $computer
                if ($aux) {
                    $aux | Select-Object -Property [a-z]* -ExcludeProperty PSComputerName, 
                            Scope, Path, Options, ClassPath, Properties, SystemProperties, 
                            Qualifiers, Site, Container
                }
            }
            if ( $ActiveFireWall ) { $ActiveFireWall.displayName }
                    
        }
Function CriticalBatteryActionAC
        {
            $CriticalBatteryActionAC =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery action'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue

            if ($CriticalBatteryActionAC -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($CriticalBatteryActionAC -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($CriticalBatteryActionAC -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($CriticalBatteryActionAC -eq 3)
                {
                    Write-output "Shutdown"
                }

        }

Function CriticalBatteryActionDC
        {
            $CriticalBatteryActionDC =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery action'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue

            if ($CriticalBatteryActionDC -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($CriticalBatteryActionDC -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($CriticalBatteryActionDC -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($CriticalBatteryActionDC -eq 3)
                {
                    Write-output "Shutdown"
                }

        }

Function DevMan 
        {

            
            $ConfigManagerErrorCode = @{
                Name = 'ConfigManagerErrorCode'
                Expression = {
                # property is an array, so process all values
                $value = $_.ConfigManagerErrorCode
                
                switch([int]$value)
                    {
                    0          {'This device is working properly.'}
                    1          {'This device is not configured correctly.'}
                    2          {'Windows cannot load the driver for this device.'}
                    3          {'The driver for this device might be corrupted, or your system may be running low on memory or other resources.'}
                    4          {'This device is not working properly. One of its drivers or your registry might be corrupted.'}
                    5          {'The driver for this device needs a resource that Windows cannot manage.'}
                    6          {'The boot configuration for this device conflicts with other devices.'}
                    7          {'Cannot filter.'}
                    8          {'The driver loader for the device is missing.'}
                    9          {'This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.'}
                    10         {'This device cannot start.'}
                    11         {'This device failed.'}
                    12         {'This device cannot find enough free resources that it can use.'}
                    13         {'Windows cannot verify this device''s resources.'}
                    14         {'This device cannot work properly until you restart your computer.'}
                    15         {'This device is not working properly because there is probably a re-enumeration problem.'}
                    16         {'Windows cannot identify all the resources this device uses.'}
                    17         {'This device is asking for an unknown resource type.'}
                    18         {'Reinstall the drivers for this device.'}
                    19         {'Failure using the VxD loader.'}
                    20         {'Your registry might be corrupted.'}
                    21         {'System failure: Try changing the driver for this device. Windows is removing this device.'}
                    22         {'This device is disabled.'}
                    23         {'System failure: Try changing the driver for this device.'}
                    24         {'This device is not present, is not working properly, or does not have all its drivers installed.'}
                    25         {'Windows is still setting up this device.'}
                    26         {'Windows is still setting up this device.'}
                    27         {'This device does not have valid log configuration.'}
                    28         {'The drivers for this device are not installed.'}
                    29         {'This device is disabled because the firmware of the device did not give it the required resources.'}
                    30         {'This device is using an Interrupt Request (IRQ) resource that another device is using.'}
                    31         {'This device is not working properly because Windows cannot load the drivers required for this device.'}
                    default    {"$value"}
                    }
                    
                }  
            }
            #endregion define calculated property
            
            <# retrieve all instances...
            Get-CimInstance -ClassName Win32_PNPEntity | 
                # ...and output properties "Caption" and "ConfigManagerErrorCode". The latter is defined
                # by the hashtable in $ConfigManagerErrorCode:
                Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log" -width 300
                 C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log
                
            
                #Gather Devices with Issues
        
                    Write-output "Creating - Devices with Issues Report"
                    Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap > C:\temp\CDAT$CDATv\Installed-HWD\DevicesWithIssues.log #>

                # Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap

                
                if ($true -eq (Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0}))
                    {

                        Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize

                    }
                else 
                    {
                        write-output ""
                        Write-output "All devices apprear to be working properly"
                        write-output ""
                    }
        }

Function PowerButtonActionAC
        {
            $PowerButtonActionAC =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Power button action'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue

            if ($PowerButtonActionAC -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($PowerButtonActionAC -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($PowerButtonActionAC -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($PowerButtonActionAC -eq 3)
                {
                    Write-output "Shutdown"
                }
            if ($PowerButtonActionAC -eq 4)
                {
                    Write-output "Turn off display"
                }


        }

Function PowerButtonActionDC
        {
            $PowerButtonActionDC =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Power button action'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue

            if ($PowerButtonActionDC -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($PowerButtonActionDC -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($PowerButtonActionDC -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($PowerButtonActionDC -eq 3)
                {
                    Write-output "Shutdown"
                }
            if ($PowerButtonActionDC -eq 4)
                {
                    Write-output "Turn off display"
                }


        }

Function LidCloseAC
        {
            $LidClose =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Lid close action'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue

            if ($LidClose -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($LidClose -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($LidClose -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($LidClose -eq 3)
                {
                    Write-output "Sleep"
                }

        }

Function LidCloseDC
        {
            $LidClose =($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Lid close action'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue

            if ($LidClose -eq 0)
                {
                    Write-output "Do Nothing"
                }
            if ($LidClose -eq 1)
                {
                    Write-output "Sleep"
                }
            if ($LidClose -eq 2)
                {
                    Write-output "Hibernate"
                }
            if ($LidClose -eq 3)
                {
                    Write-output "Sleep"
                }

        }



Function VantageUpdate

                {
                    $VantageUpdate = Test-path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\SystemUpdateAddin\Logs\EnableLogs'
                    
                    If ($VantageUpdate -eq $True)
                            {
                            
                                Write-Output "MFG Date:       $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\MachineInfo\MFGDATE'| Select-Object -ExpandProperty VersionToReport)"
                        
                            }

                    else 
                            {
                                
                            }



                }

Function WER

        {
            # get-winevent -filterHashtable @{logname='application';ID='1001'} -MaxEvents 200 | format-table -autosize -wrap
                $WER = get-winevent -filterHashtable @{logname='application';ID='1001'} -Erroraction Ignore
                if ($null -eq $WER)
                    {
                        
                        Write-output "Windows Error Reporting Logs 1001  are not present" > C:\temp\CDAT$CDATv\Windows-Event-Logs\WindowsErrorReportingDetail.log

                    }
                
                else 
                    {

                        get-winevent -filterHashtable @{logname='application';ID='1001'} -MaxEvents 200 | format-table -autosize -wrap > C:\temp\CDAT$CDATv\Windows-Event-Logs\WindowsErrorReportingDetail.log
                    
                    }
        
        }
            
Function DumpCHK
        {
            $DumpCHK = Test-path -Path C:\Windows\*Memory*.dmp
            $TargetDir = "C:\Windows\"

            If ($DumpCHK -eq $True)
                {
                    Write-output "=======================================" 
                    Write-output "     Full Kernel Dumps                 " 
                    Write-output "=======================================" 
                    get-ChildItem $targetDir Memory*.dmp

                }

            Else 
                {
                    Write-output "=======================================" 
                    Write-output "     Full Kernel Dumps                 " 
                    Write-output "=======================================" 
                    Write-output "No Full Kernel Memory Dumps found in C:\Windows\"

                }
        }


Function DevMan 
        {

            
            $ConfigManagerErrorCode = @{
                Name = 'ConfigManagerErrorCode'
                Expression = {
                # property is an array, so process all values
                $value = $_.ConfigManagerErrorCode
                
                switch([int]$value)
                    {
                    0          {'This device is working properly.'}
                    1          {'This device is not configured correctly.'}
                    2          {'Windows cannot load the driver for this device.'}
                    3          {'The driver for this device might be corrupted, or your system may be running low on memory or other resources.'}
                    4          {'This device is not working properly. One of its drivers or your registry might be corrupted.'}
                    5          {'The driver for this device needs a resource that Windows cannot manage.'}
                    6          {'The boot configuration for this device conflicts with other devices.'}
                    7          {'Cannot filter.'}
                    8          {'The driver loader for the device is missing.'}
                    9          {'This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.'}
                    10         {'This device cannot start.'}
                    11         {'This device failed.'}
                    12         {'This device cannot find enough free resources that it can use.'}
                    13         {'Windows cannot verify this device''s resources.'}
                    14         {'This device cannot work properly until you restart your computer.'}
                    15         {'This device is not working properly because there is probably a re-enumeration problem.'}
                    16         {'Windows cannot identify all the resources this device uses.'}
                    17         {'This device is asking for an unknown resource type.'}
                    18         {'Reinstall the drivers for this device.'}
                    19         {'Failure using the VxD loader.'}
                    20         {'Your registry might be corrupted.'}
                    21         {'System failure: Try changing the driver for this device. Windows is removing this device.'}
                    22         {'This device is disabled.'}
                    23         {'System failure: Try changing the driver for this device.'}
                    24         {'This device is not present, is not working properly, or does not have all its drivers installed.'}
                    25         {'Windows is still setting up this device.'}
                    26         {'Windows is still setting up this device.'}
                    27         {'This device does not have valid log configuration.'}
                    28         {'The drivers for this device are not installed.'}
                    29         {'This device is disabled because the firmware of the device did not give it the required resources.'}
                    30         {'This device is using an Interrupt Request (IRQ) resource that another device is using.'}
                    31         {'This device is not working properly because Windows cannot load the drivers required for this device.'}
                    default    {"$value"}
                    }
                    
                }  
            }
            #endregion define calculated property
            
            <# retrieve all instances...
            Get-CimInstance -ClassName Win32_PNPEntity | 
                # ...and output properties "Caption" and "ConfigManagerErrorCode". The latter is defined
                # by the hashtable in $ConfigManagerErrorCode:
                Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log" -width 300
                 C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log
                
            
                #Gather Devices with Issues
        
                    Write-output "Creating - Devices with Issues Report"
                    Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap > C:\temp\CDAT$CDATv\Installed-HWD\DevicesWithIssues.log #>

                # Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap

                
                if ($true -eq (Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0}))
                    {

                        Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize

                    }
                else 
                    {
                        write-output ""
                        Write-output "All devices apprear to be working properly"
                        write-output ""
                    }
        }
Function Odo

        {
            #$Batt = (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Battery_Cycles[0]
            #$SSD = (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).SSD_Read_Write_count[0]
            #$Shock = (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Shock_Events[0]
            #$CPU = (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).CPU_Uptime[0]
            #$Therm = (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Thermal_events[0]

            If (!(Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror))

                    {

                    }

            else
                    {
                        Write-output "=======================================" 
                        Write-output "     Odometer Data                     " 
                        Write-output "=======================================" 
                        Write-output ""
                        Write-Output "CPU Uptime:           $((Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).CPU_Uptime[0])"
                        Write-Output "Battery Cycles:       $((Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Battery_Cycles[0])"
                        Write-Output "Shock Events:         $((Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Shock_Events[0])"
                        Write-Output "Thermal Events:       $((Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).Thermal_events[0])"
                        Write-Output "SSD Read/Write:       $((Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror).SSD_Read_Write_count[0])"
                        Write-Output ""


                    }

        }

Function LenovoVan
        {
            $VantageAPP = Get-AppxPackage -Name "*LenovoSettingsforEnterprise*"
            If ($VantageAPP.name -eq "E046963F.LenovoSettingsforEnterprise")
                    {
                                $Vantage = $((Get-WMIObject -Namespace root\Lenovo -ClassName *Lenovo_Updates* -list -recurse -EA 0).Name)
                        
                                If ($Vantage -eq "Lenovo_Updates")

                                {
                                            #Gather System Update Data to folder
                                            Write-output "=======================================" 
                                            Write-output "     Available FW and Driver Udpates   " 
                                            Write-output "=======================================" 
                                            Get-WmiObject -Namespace ROOT\Lenovo -Class Lenovo_Updates | Where-Object {$_.Status -eq "Applicable"} | select-object PackageID, Severity, Status, Version,Title | Format-Table

                                }

                                else
                                {        
                                            Write-output "=======================================" 
                                            Write-output "     Available FW and Driver Udpates   " 
                                            Write-output "=======================================" 
                                            Write-output " Lenovo Commericial Vantage logging is not enabled."

                                }
                    }

        }

Function MiniD
        {


                If (!(test-path C:\Windows\minidump\*))
                {
                    Write-output "=======================================" 
                    Write-output "     Mini Dumps                        " 
                    Write-output "=======================================" 
                    write-output ""
                    Write-output "No minidumps found in C:\Windows\Minidump" 
                    write-output ""

                }

                else
                {        
                    #Gather mini-dump to folder

                    Write-output "=======================================" 
                    Write-output "     Mini Dumps                        " 
                    Write-output "=======================================" 
                    Get-ChildItem C:\windows\minidump\ | Where-Object {$_.Length -lt 10000KB}  | Format-Table


                }

        }

Function SRUM

        {
            foreach($file in $(Get-ChildItem -Recurse *.csv))
            {
            .\templates\srumutil.ps1 -Path $file -Out $($file.Name.Replace(".csv",".html"))
            }

        }

Function MemDetails
        {

            $MemPN = (get-wmiobject win32_physicalmemory).Partnumber
            $MemSN = (get-wmiobject win32_physicalmemory).SerialNumber
            $MemBank =  (get-wmiobject win32_physicalmemory).Banklabel
            $Memory = (Get-WmiObject win32_physicalmemory).manufacturer


            [PSCustomObject]@{Mfg= $Memory; MemBank = $memBank; PartNumber= $memPN; MEMSN = $MEMSN} | Format-List 
        }

Function Teams
        {
            $TeamsPath = Test-path $env:UserProfile\AppData\Roaming\Microsoft\Teams\settings.json
            #Get-Content $env:UserProfile"\AppData\Roaming\Microsoft\Teams\settings.json" | ConvertFrom-Json | Select Version, Ring, Enviroment
            
            If ($TeamsPath -eq $True)
                    {
                    
                        Write-Output "Teams:        $((Get-Content $env:UserProfile"\AppData\Roaming\Microsoft\Teams\settings.json" | ConvertFrom-Json).version)"
                
                    }

            else 
                    {
                        
                    }



        }

Function Office

                {
                    $OfficePath = Test-path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
                    
                    If ($OfficePath -eq $True)
                            {
                            
                                Write-Output "Office:       $(Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'| Select-Object -ExpandProperty VersionToReport)"
                        
                            }

                    else 
                            {
                                
                            }

                }

    
Function ZoomChk

                {

                    $Zoom = Get-Package -Name Zoom -erroraction silentlyContinue

                    If ($Zoom.Name -eq 'Zoom')
                            {
                                Write-Output "Zoom:         $((Get-Package -Name Zoom).Version)"
                            }

                    else
                            {

                            }

                }


function VersionBanner
        {

            Write-Host "`n`t`t **************************************`n"
            Write-Host "`n`t`t           Lenovo CDAT v$($CDATVer)    `n" 
            Write-Host "`n`t`t **************************************`n"

        }

Function DockDetect

        {

            $DockAudio4 = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "ThinkPad Thunderbolt 4 Dock USB Audio"}).Name
            $DockAudio3 = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "ThinkPad Thunderbolt 3 Dock USB Audio"}).Name
            $DockAudioUSBC = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "ThinkPad USB-C Dock Gen2 USB Audio"}).Name
            $DockEssential = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "Lenovo Thunderbolt 3 ES Dock USB Audio"}).Name
            $DockMini = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "Lenovo USB-C Mini Dock"}).Name
            $DockGeneric = (Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object {$_.Name -eq "ThinkPad Dock USB Audio"}).Name
            $Manufacturer = (Get-WmiObject win32_computersystem).Manufacturer
  

                If ($Manufacturer -like "Lenovo")

                        {

                                If ($DockAudio4 -eq "ThinkPad Thunderbolt 4 Dock USB Audio")
                                    {

                                        Write-output "Dock:         ThinkPad Thunderbolt 4 Dock"
                                    }

                                If ($DockAudio3 -eq "ThinkPad Thunderbolt 3 Dock USB Audio")
                                    {

                                        Write-output "Dock:         ThinkPad Thunderbolt 3 Dock"
                                    }

                                If ($DockAudioUSBC -eq "ThinkPad USB-C Dock Gen2 USB Audio")
                                    {

                                        Write-output "Dock:         ThinkPad USB-C Dock Gen2"
                                    }

                                If ($DockMini -eq "Lenovo USB-C Mini Dock")
                                    {

                                        Write-output "Dock:         Lenovo USB-C Mini Dock"
                                    }

                                If ($DockEssential -eq "Lenovo Thunderbolt 3 ES Dock USB Audio")
                                    {

                                        Write-output "Dock:         Lenovo Thunderbolt 3 Essential Dock"
                                    }

                                If ($DockGeneric -eq "ThinkPad Dock USB Audio")
                                    {

                                        Write-output "Dock:         ThinkPad Dock Attached"
                                    }

                                # VID_17EF&PID_A359 - ThinkPad Hybrid USB-C with USB-A Dock - 40AF
                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_A359*" }))
                                    {
                                        
                                        Write-output "Dock:         ThinkPad Hybrid USB-C with USB-A Dock 40AF"
                                      
                                    }

                                # VID_17EF&PID_3062 - ThinkPad USB-C Dock - 40A9

                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_3062*" }))
                                    {
                                        
                                        Write-output "Dock:         ThinkPad USB-C Dock 40A9"
                                    
                                    }
                                
                                # VID_17EF&PID_30CA - Thinkpad Universal USB-C Smart Dock - 40B2
                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_30CA*" }))
                                    {
                                        
                                        Write-output "Dock:         Thinkpad Universal USB-C Smart Dock 40B2"
                                    
                                    }

                                <#    "device_name": "ThinkPad Universal USB-C Dock v2","dock_identifier": "VID_17EF&PID_30F0","machine_type": "40B7",#>
                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_30F0*" }))
                                    {
                                        
                                        Write-output "Dock:         ThinkPad Universal USB-C Dock v2 40B7"
                                    
                                    }

                                # VID_17EF&PID_30FC - Lenovo USB-C Dock (Windows Only) - 40B5
                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_30FC*" }))
                                    {
                                        
                                        Write-output "Dock:         Lenovo USB-C Dock (Windows Only) 40B5"
                                    
                                    }

                                # VID_17EF&PID_3082 - ThinkPad Thunderbolt 3 Essential Dock - 40AV
                                If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_3092*" }))
                                    {
                                        
                                        Write-output "Dock:         ThinkPad Thunderbolt 3 Essential Dock 40AV"
                                    
                                    }
                                
                                # VID_17EF&PID_40AU - USB-C Mini Dock - 40AU
                                    If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_10C9*" }))
                                    {
                                        
                                        Write-output "Dock:         Lenovo USB-C Mini Dock 40AU"
                                    
                                    } 

                                <# VID_17EF&PID_17EF - USB-C Mini Dock - 40B9
                                    If ((Get-WmiObject Win32_USBControllerDevice -ErrorAction Stop | ForEach-Object { [wmi]($_.Dependent) } | Where-Object  {$_.DeviceID -like "*VID_17EF&PID_306F*" }))
                                    {
                                        
                                        Write-output "Dock:         Lenovo USB-C Dual Display Dock 40B9"
                                    
                                    } #>



                Else 
                        
                                    {
                                    

                                    }

                        }

        }

function Get-BiosSettings() {
    <#
    .SYNOPSIS
    Returns lenovo ThinkPad BIOS settings

    .DESCRIPTION
    Uses lenovo ThinkPad unique WMI. The process needs administrator privilege to access the target WMI objects.

    .PARAMETER Item
    List of regular expression strings to filter with BIOS setting Item.

    Default is '.+'.

    .PARAMETER Value
    List of regular expression strings to filter with Value of each BIOS setting.

    Default is '.+'.

    .PARAMETER CimSession
    A CIM session object to access a target system. Default is a DCOM session to local machine.

    .EXAMPLE
    PS > Get-BiosSettings network, '^bootorder$'

    Item             Value                 Selections
    ----             -----                 ----------
    IPv4NetworkStack {Enable}              {Disable, Enable}
    IPv6NetworkStack {Enable}              {Disable, Enable}
    BootOrder        {NVMe0, USBHDD, HDD0} {HDD0, HDD1, HDD2, HDD3...}
    NetworkBoot      {PCILAN}              {HDD0, HDD1, HDD2, HDD3...}


    Returns setup items that has a name with a substring "network" or with a string "bootorder".

    .EXAMPLE
    PS > Get-BiosSettings -value balance

    Item                             Value      Selections
    ----                             -----      ----------
    AdaptiveThermalManagementBattery {Balanced} {MaximizePerformance, Balanced}
    CoolModeEnable                   {Balanced} {Performance, Balanced, Cool}


    Returns setup items that has a value with substring "balance".

    .EXAMPLE
    PS > Get-BiosSettings SecureBoot -CimSession (New-CimSession -ComputerName TABLET-xxxxxxxx -Credential user@ccc.com)

    Item       Value     Selections
    ----       -----     ----------
    SecureBoot {Disable} {Disable, Enable}


    Returns BIOS SecureBoot setting on a remote computer 'TABLET-xxxxxxxx' with credential of a user 'user@ccc.com'.

    .EXAMPLE
    PS > Get-BiosSettings | %{$_.View()}

    [WakeOnLAN (Disable)]
     Disable, ACOnly, ACandBattery, Enable

    [EthernetLANOptionROM (Disable)]
     Disable, Enable
    ...............


    A View() method makes all data visible.

    .LINK
    https://www.google.com/search?q=thinkpad+bios+wmi
    https://msdn.microsoft.com/en-us/library/windows/hardware/dn614028(v=vs.85).aspx

    #>
    [CmdletBinding()]
    Param(
        [string[]]$Item = '.+',
        [string[]]$Value = '.+',
        [System.Object]$CimSession
    )

    if (-not $CimSession) {
        $CimSession = New-CimSession
    }
    Write-Verbose -Message "Get-BiosSettings on $($CimSession.ComputerName)"

    #
    # Get a CIM instance of Lenovo_GetBiosSelections for later use.
    #
    $oSel = Get-CimInstance -NameSpace root/WMI -Class Lenovo_GetBiosSelections -CimSession $CimSession

    #
    # Process all instances of Lenovo_BiosSetting, then convert each to an output object.
    #
    Get-CimInstance -NameSpace root/WMI -Class Lenovo_BiosSetting -CimSession $CimSession | Where-Object { $_.CurrentSetting } | ForEach-Object {
        if (($c = $_.CurrentSetting.Split(",")).Count -ge 2) {
            $cItem = $c[0]
            $cValue = $c[1]

            if (($Item | Where-Object { $cItem -match $_ }) -and ($Value | Where-Object { $cValue -match $_ })) {
                $o = New-Object PSCustomObject
                $o | Add-Member -MemberType NoteProperty -Name "Item" -Value $cItem
                $o | Add-Member -MemberType NoteProperty -Name "Value" -Value $cValue.Split(":")
                $o | Add-Member -MemberType NoteProperty -Name "Selections" -Value `
                (Invoke-CimMethod -InputObject $oSel -MethodName "GetBiosSelections" -Arguments @{Item = $o.Item } -Verbose:$false).Selections.Split(",")
                $o | Add-Member -MemberType ScriptMethod -Name "View" -Value $ViewBiosSettings
                $o
            }
        }
        else {
            Write-Warning "CurrentSetting field `"$($_.CurrentSetting)`" has invalid format"
        }
    }
}

$ViewBiosSettings = {
    <#
    .SYNOPSIS
    A ScriptMethod of the Get-BiosSettings that generates a string for easy reading.

    #>
    Param(
    )

    "$("[{0} ({1})]`n{2}`n" -f $this.Item, ([string]::Join(":", $this.Value)), ([string]::Join(", ", $this.Selections)))"
}


function Export-BiosSettings() {
    <#
    .SYNOPSIS
    Exports lenovo ThinkPad BIOS settings to a file

    .DESCRIPTION
    Exports objects from Get-BiosSettings to a json file. The process needs administrator privilege to access the target WMI objects.

    Equivalent with
    Get-BiosSettings [arguments] | ConvertTo-Jason | Out-File -FilePath $Path -Encoding ascii

    .PARAMETER Path
    Name of an exported file.

    Default is ".\bios-settings.$($bios.ComputerName).$($bios.SerialNumber).$($bios.SMBIOSBIOSVersion).$((Get-Date).ToString("yyyy-MM-dd")).json"

    .PARAMETER Item
    List of regular expression strings to filter with BIOS setting Item.

    Default is '.+'.

    .PARAMETER Value
    List of regular expression strings to filter with Value of each BIOS setting.

    Default is '.+'.

    .PARAMETER Html
    Output format is html.

    Default is JSON

    .PARAMETER CimSession
    A CIM session object to access a target system. Default is a DCOM session to a local machine.

    .EXAMPLE
    PS C:\temp> Export-BiosSettings -Item bootorder$
    BIOS setup data was exported to C:\temp\bios-settings.TABLET-3E1KFQHF.15000018.N1OET36W (1.21 ).2018-01-11.json.

    Exports only an item "BootOrder". An example of generated file is below.
    Editing this file allows you to define a new "BootOrder" setting for Set-BiosSettings().

    {
        "Item":  "BootOrder",
        "Value":  [
                    "NVMe0",
                    "USBHDD"
                ],
        "Selections":  [
                        "HDD0",
                        "HDD1",
                        "HDD2",
                        "HDD3",
                        "HDD4",
                        "PCILAN",
                        "ATAPICD0",
                        "ATAPICD1",
                        "ATAPICD2",
                        "USBFDD",
                        "USBCD",
                        "USBHDD",
                        "OtherHDD",
                        "OtherCD",
                        "NVMe0",
                        "NVMe1",
                        "NODEV"
                    ]
    }

    #>
    [CmdletBinding(SupportsShouldProcess)]
    Param(
        [string]$Path,
        [string[]]$Item = '.+',
        [string[]]$Value = '.+',
        [switch]$Html,
        [System.Object]$CimSession
    )

    if (-not $CimSession) {
        $CimSession = New-CimSession
    }
    Write-Verbose -Message "Export-BiosSettings on $($CimSession.ComputerName)"

    if ($Html) {
        $ext = 'html'
    }
    else {
        $ext = 'json'
    }

    if (-not $Path) {
        try {
            $cs = Get-CimInstance -ClassName Win32_ComputerSystem -CimSession $CimSession
            $bios = Get-CimInstance -ClassName Win32_BIOS -CimSession $CimSession
            $Path = ".\bios-settings.$($cs.Name).$($cs.SystemFamily).$($bios.SMBIOSBIOSVersion).$((Get-Date).ToString("yyyy-MM-dd")).$($ext)"
            if (!(Test-Path -Path $Path -IsValid)) {
                throw "Invalid PATH"
            }
        }
        catch {
            $Path = ".\bios-settings.$($CimSession.ComputerName).$($ext)"
        }
    }

    $tmpJson = New-TemporaryFile
    Get-BiosSettings -Item $Item -Value $Value -CimSession $CimSession | ConvertTo-Json | Out-File -FilePath $tmpJson -Encoding utf8

    if ($Html) {
        JsonToHtml -Path $tmpJson -Html "$($HtmlPath)\template_bios-settings.html" -Out $Path
        Remove-Item -Path $tmpJson
    }
    else {
        Move-Item -Path $tmpJson -Destination $Path -Force
        Get-Item -Path $Path
    }
}

function Set-BiosSettings() {
    <#
    .SYNOPSIS
    Changes lenovo ThinkPad BIOS setting

    .DESCRIPTION
    The process uses lenovo ThinkPad unique WMI, then needs administrator privilege to access the target WMI objects.

    .PARAMETER Item
    A regular expression string of a BIOS setting Item name to be changed.

    .PARAMETER Value
    List of regular expression strings to specify values to be set. A first matched value in possible settings replaces each input value.

    .PARAMETER Svp
    A ThinkPad BIOS supervisor password string. In ASCII format or in scancode format.

    .PARAMETER Encoding
    Password string encoding.

    .PARAMETER Langauge
    Langauge of the password.

    .PARAMETER Path
    Array of name of json files with expected BIOS settings, exported from Get-BiosSettings.
    Input from pipeline is accepted, and wildcards are permitted.

    .PARAMETER SkipSave
    Skip to save and finalize the change requests via. SaveBiosSettings() for subsequent calls.

    .PARAMETER Restart
    Restart a computer at successful completion of operation.

    .PARAMETER CimSession
    A CIM session object to access a target system. Default is a DCOM session to a local machine.

    .EXAMPLE
    PS > Set-BiosSettings -Item bootorder$ -Value usbhdd, nvme0, pcilan

    Item                           Current          -> New
    ----                           -------             ---
    BootOrder                      NVMe0:USBHDD:HDD0 -> USBHDD:NVMe0:PCILAN

    Confirm
    Are you sure you want to perform this action?
    Performing the operation "Change" on target "BIOS settings".
    [Y] Yes  [A] Yes to All  [N] No  [L] No to All  [S] Suspend  [?] Help
    (default is "Y"):Y

    Restart the system to take effect.


    Changes boot priority order.

    .EXAMPLE
    PS > Set-BiosSettings fn ena -Confirm:$false

    Item                           Current          -> New
    ----                           -------             ---
    FnCtrlKeySwap                  Disable          -> Enable
    FnSticky                       Disable          -> Enable
    FnKeyAsPrimary                 Disable          -> Enable

    Restart the system to take effect.


    Enables setting items with a substring "fn". No confirmation prompt.

    .EXAMPLE
    PS >  '.\bios-settings.TABLET-3E1KFQHF.15000018.N1OET36W (1.21 ).2018-01-11.json' | Set-BiosSettings -SkipSave -Svp svp -Confirm:$false

    Item                           Current          New
    ----                           -------          ---
    BootOrder                      NVMe0:USBHDD     NVMe0:PCILAN:USBHDD

    WARNING: Calling SaveBiosSettings() was skipped. The process before system restart is required to take effect.


    Imports new BIOS settings from a file. The file was exported from Get-BiosSettings, then edited to change the BoootOrder as above.

    Saving the requested change via. SaveBiosSettings() is skipped with -SkipSave option. It allows subsequent calls of this function, but no effect until the save by another call.

    On a system with BIOS supervisor password is set, the process needs to provide it explicitly.

    .LINK
    https://www.google.com/search?q=thinkpad+bios+wmi
    https://msdn.microsoft.com/en-us/library/windows/hardware/dn614028(v=vs.85).aspx

    #>
    [OutputType([String])]
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    Param(
        [string]$Item,
        [string[]]$Value,
        [string]$Svp,
        [ValidateSet('ascii', 'scancode')][string]$Encoding = 'ascii',
        [ValidateSet('us', 'fr', 'gr')][string]$Langauge = 'us',
        [Parameter(ValueFromPipeline = $true)][string[]]$Path,
        [switch]$SkipSave,
        [switch]$Restart,
        [System.Object]$CimSession
    )

    Begin {
        if (-not $CimSession) {
            $CimSession = New-CimSession
        }
        Write-Verbose -Message "Set-BiosSettings on $($CimSession.ComputerName)"

        #
        # Current BIOS settings
        #
        $cObj = Get-BiosSettings -CimSession $CimSession

        #
        # Will be filled with BIOS setting items to be expected on this request
        #
        $obj = New-Object System.Collections.ArrayList

        #
        # Define a password string.
        #
        if ($Svp) {
            $passwordSetting = ",$($Svp.ToLower()),$($Encoding.ToLower()),$($Langauge.ToLower())"
        }
        else {
            $passwordSetting = ""
        }

        #
        # Define a request specified by arguments.
        #
        if ($Item -and $Value) {
            $cObj | Where-Object { $_.Item -match $Item } | ForEach-Object {
                $argReq = New-Object PSCustomObject
                $argReq | Add-Member -MemberType NoteProperty -Name "Item" -Value $_.Item
                $argReq | Add-Member -MemberType NoteProperty -Name "Value" -Value $Value
                $argReq | Add-Member -MemberType NoteProperty -Name "Selections" -Value $_.Selections
                $argReq | Get-BiosSettingsChange -Current $cObj | ForEach-Object { $obj.Add($_) > $null }
            }
        }
    }

    Process {
        #
        # Capture requests from files.
        #
        foreach ($p in $Path) {
            Get-ChildItem -Path $p -File | ForEach-Object {
                $fileName = $_.FullName
                Get-Content -Path $fileName -Raw | ConvertFrom-Json | ForEach-Object { $_ } | ForEach-Object {
                    # Filter the object with rough sanity check.
                    if ($_ | Get-Member -MemberType NoteProperty -Name Selections) {
                        $_ | Get-BiosSettingsChange -Current $cObj | ForEach-Object { $obj.Add($_) > $null }
                    }
                    else {
                        Write-Warning "Ignored the file `"$($fileName)`" that does not match this process."
                        return
                    }
                }
            }
        }
    }

    End {
        #
        # Change BIOS setiing, if any.
        #
        if ($obj.Count) {
            #
            # Show which item will be changed by this process.
            # Object direct out does not come to the screen before a user prompt below...
            #
            $format = "{0, -30} {1, -16} {2}"
            ""
            $format -f "Item", "Current", "New"
            $format -f "----", "-------", "---"
            $obj | ForEach-Object {
                $format -f $_.Item, $_.ValueString, $_.NewValueString
            }
            ""

            #
            # Prompt to user if proceed or not. Then, ask BIOS to change the settings via. WMI.
            #
            if ($PSCmdlet.ShouldProcess("BIOS settings of $($CimSession.ComputerName)", "Change")) {
                #
                # Set each setting item.
                #
                $oSet = Get-CimInstance -NameSpace root/WMI -Class Lenovo_SetBiosSetting -CimSession $CimSession

                $obj | ForEach-Object {
                    $setString = "$($_.Item),$($_.NewValueString)$($passwordSetting);"

                    Write-Verbose "SetBiosSetting(`"$($setString)`")"
                    $method = Invoke-CimMethod -InputObject $oSet -MethodName "SetBiosSetting" -Arguments @{parameter = $setString }
                    if (-not ($method.return -like "Success")) {
                        Write-Error -Message "Failed to set `"$($setString)`" with $($method.return)."
                    }
                }

                #
                # Finalize the request by saving the setting.
                #
                if (-not $SkipSave) {
                    if ($passwordSetting.Length) {
                        $passwordSetting = $passwordSetting.Trim(",")
                    }
                    $saveString = "$($passwordSetting);"

                    Write-Verbose "SaveBiosSettings(`"$($saveString)`")"
                    $oSave = Get-CimInstance -NameSpace root/WMI -Class Lenovo_SaveBiosSettings -CimSession $CimSession
                    $method = Invoke-CimMethod -InputObject $oSave -MethodName "SaveBiosSettings" -Arguments @{parameter = $saveString }
                    if ($method.return -like "Success") {
                        if ($Restart -and $PSCmdlet.ShouldProcess($CimSession.ComputerName, "Restart to take effect")) {
                            Restart-Computer -ComputerName $CimSession.ComputerName
                        }
                        else {
                            Write-Output "`nRestart $($CimSession.ComputerName) to take effect."
                        }
                    }
                    else {
                        Write-Error -Message "Failed to finalize setting change request with $($method.return)."
                    }
                }
                else {
                    Write-Warning "Calling SaveBiosSettings() was skipped. The process before system restart is required to take effect."
                }
            }
        }
    }
}

function Get-BiosSettingsChange() {
    <#
    .SYNOPSIS
    Returns BIOS setup items to be changed

    .DESCRIPTION
    Define a requested BIOS setup value string, then returns an object for setup item change when and only when the requested value is different with current's.

    .PARAMETER Request
    Object of a BIOS setup item with expected setting.

    .PARAMETER Current
    Objects of all BIOS setup items with current BIOS setting.

    #>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)][PSCustomObject[]]$Request,
        [Parameter(Mandatory = $true)][PSCustomObject[]]$Current
    )

    Process {
        foreach ($r in $Request) {
            $Current | Where-Object { $r.Item -eq $_.Item } | ForEach-Object {
                #
                # Build an array of new values with strings in Selections.
                #
                $newValue = @()
                foreach ($v in $r.Value) {
                    foreach ($s in $_.Selections) {
                        if ($itemMatch = ($s -match $v)) {
                            $newValue += $s
                            break
                        }
                    }
                    if (-not $itemMatch) {
                        Write-Warning "Ignored the requested value `"$($v)`" for a stetup item `"$($_.Item)`"."
                    }
                }

                if ($newValue.Count) {
                    $ValueString = [string]::Join(":", $_.Value)
                    $NewValueString = [string]::Join(":", $newValue)

                    if ($NewValueString -ne $ValueString) {
                        $o = New-Object PSCustomObject
                        $o | Add-Member -MemberType NoteProperty -Name "Item" -Value $_.Item
                        $o | Add-Member -MemberType NoteProperty -Name "Value" -Value $_.Value
                        $o | Add-Member -MemberType NoteProperty -Name "Selections" -Value $_.Selections
                        $o | Add-Member -MemberType NoteProperty -Name "ValueString" -Value $ValueString
                        $o | Add-Member -MemberType NoteProperty -Name "NewValueString" -Value $NewValueString
                        $o
                    }
                }
            }
        }
    }
}

function Reset-BiosSettings() {
    <#
    .SYNOPSIS
    Loads default settings of lenovo ThinkPad BIOS

    .DESCRIPTION
    The process uses lenovo ThinkPad unique WMI, then needs administrator privilege to access the target WMI objects.

    .PARAMETER Svp
    A ThinkPad BIOS supervisor password string. In ASCII format or in scancode format.

    .PARAMETER Encoding
    Password string encoding.

    .PARAMETER Langauge
    Langauge of the password.

    .PARAMETER SkipSave
    Skip to save and finalize the change requests via. SaveBiosSettings() for subsequent calls.

    .PARAMETER CimSession
    A CIM session object to access a target system. Default is a DCOM session to a local machine.

    .LINK
    https://www.google.com/search?q=thinkpad+bios+wmi
    https://msdn.microsoft.com/en-us/library/windows/hardware/dn614028(v=vs.85).aspx

    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    Param(
        [string]$Svp,
        [ValidateSet('ascii', 'scancode')][string]$Encoding = 'ascii',
        [ValidateSet('us', 'fr', 'gr')][string]$Langauge = 'us',
        [switch]$SkipSave,
        [System.Object]$CimSession
    )

    if (-not $CimSession) {
        $CimSession = New-CimSession
    }
    Write-Verbose -Message "Reset-BiosSettings on $($CimSession.ComputerName)"

    #
    # Prompt to user if proceed or not. Then, ask BIOS to change the settings via. WMI.
    #
    if ($PSCmdlet.ShouldProcess("BIOS settings of $($CimSession.ComputerName)", "Reset to default")) {
        #
        # Define a password string.
        #
        if ($Svp) {
            $passwordSetting = "$($Svp.ToLower()),$($Encoding.ToLower()),$($Langauge.ToLower());"
        }
        else {
            $passwordSetting = ";"
        }

        #
        # Request to load default settings.
        #
        Write-Verbose "LoadDefaultSettings(`"$($passwordSetting)`")"
        $oLoad = Get-CimInstance -NameSpace root/WMI -Class Lenovo_LoadDefaultSettings -CimSession $CimSession
        $method = Invoke-CimMethod -InputObject $oLoad -MethodName "LoadDefaultSettings" -Arguments @{parameter = $passwordSetting }
        if (-not ($method.return -like "Success")) {
            Write-Error -Message "Failed to load default settings with $($method.return)."
        }

        #
        # Finalize the request by saving the setting.
        #
        if (-not $SkipSave) {
            Write-Verbose "SaveBiosSettings(`"$($passwordSetting)`")"
            $oSave = Get-CimInstance -NameSpace root/WMI -Class Lenovo_SaveBiosSettings -CimSession $CimSession
            $method = Invoke-CimMethod -InputObject $oSave -MethodName "SaveBiosSettings" -Arguments @{parameter = $passwordSetting }
            if ($method.return -like "Success") {
                Write-Output "`nRestart the system to take effect."
            }
            else {
                Write-Error -Message "Failed to finalize setting change request with $($method.return)."
            }
        }
        else {
            Write-Warning "Calling SaveBiosSettings() was skipped. The process before system restart is required to take effect."
        }
    }
}
Function DriverDate

        {

            # Initializing parameters (modify the Output folder by changing the $TargetDirectory define in the first line)
                    # $TargetDirectory = "C:\temp\DriversINFTest\"
                    $hostname = $ENV:COMPUTERNAME
                    # Get Third Party drivers used, that are not provided by Microsoft and presumably included in the OS
                    $drivers = Get-WmiObject Win32_PNPSignedDriver | Where-Object {$_.DriverProviderName -ne "Microsoft"}
                    # Initialize the list of detected driver packages as an array
                    # $DriverFolders = @()
                    foreach ($d in $drivers) {
                        # We initialize the list of driver files for each driver
                        $DriverFiles = @()
                        # For each driver instance from WMI class Win32_PNPSignedDriver, we compose the related WMI object name from the other WMI driver class, Win32_PNPSignedDriverCIMDataFile
                        $ModifiedDeviceID = $d.DeviceID -replace "\\", "\\"
                        $Antecedent = "\\" + $hostname + "\ROOT\cimv2:Win32_PNPSignedDriver.DeviceID=""$ModifiedDeviceID"""
                        # Get all related driver files for each driver listed in WMI class Win32_PNPSignedDriver
                        $DriverFiles += Get-WmiObject Win32_PNPSignedDriverCIMDataFile | Where-Object {$_.Antecedent -eq $Antecedent}
                        if ($Null -ne $DriverFiles) {
                            foreach ($i in $DriverFiles) {
                                # We elliminate double backslashes from the file paths
                                $path = $i.Dependent.Split("=")[1] -replace '\\\\', '\'
                                # We elliminate the trailing and ending quotes from the file paths
                                $path2 = $path.Substring(1,$path.Length-2)
                                # On the first pass, we only process the INF files as there is a very low chance of existing more than one driver package on the same machine, with the same INF file legth
                                if ($path2.Split("\\")[$path2.Split("\\").Length-1].split(".")[1] -eq "inf") {
                                    # We get the file attributes for each INF file
                                    $CurrentDeviceID = $d.DeviceID
                                    Write-output "Current Device ID is $CurrentDeviceID"
                                    $filedetails = $i.Dependent
                                    Write-output "Current inf file is $filedetails"
                                    $where = $filedetails.split("=")[1]
                                    $query = "select * from CIM_DataFile where Name=$where"
                                    $InstallDate = Get-WmiObject -Namespace "ROOT\CIMV2" -Query $query
                                    $ReadableDate = $InstallDate.ConvertToDateTime($InstallDate.InstallDate)
                                    Write-Output "Installation date is:"
                                    $ReadableDate
                                    } # End of if ($path2.Split("\\")[$path2.Split("\\").Length-1].split(".")[1] -eq "inf")
                                } # End of foreach ($i in $DriverFiles)
                            } # End of if ($DriverFiles -ne $null)
                        } # End of foreach ($d in $drivers)

        }
function IntelMEFW


        {
            $IntelMEFW = ($(Get-Ciminstance -class ME_System -namespace 'Root\Intel_ME'-ErrorAction Silentlycontinue))

            if ($null -eq $IntelMEFW)

                {

                }

            else 
            
                {
                    Write-output "ME FW:        $((Get-Ciminstance -class ME_System -namespace 'Root\Intel_ME').FWVersion)"
                }
            
        }

Function ProcDetect
{

# AMD or Intel Detection

$ProcDetect = (Get-WmiObject win32_processor).Manufacturer
$ARMDetect = (Get-WmiObject win32_processor).SocketDesignation


If ($ProcDetect -eq "AuthenticAMD")

                {
                    
                    Write-Output "AMD"

                }

If ($ProcDetect -eq "GenuineIntel")

                {
                    Write-output "Intel"
                    
                }

If ($ARMDetect -eq "Qualcomm")

                {
                    Write-output "ARM"
                    
                }


}       
function Preload    

        {
            if (Test-Path "C:\Windows\machineinfo.sav")

                {
                    Write-Output "Yes"
                }

            Else

                {
                    Write-Output "No"
                }

        }
function JsonConvert
{

<#
.SYNOPSIS
Builds html format reports

.PARAMETER Path
An array of file names to be converted to the html report. The file needs to be a JSON file with supposed members.
Accepts input from pipeline.

.PARAMETER Html
Name of the base html file

.PARAMETER Out
Name of a html file to be generated. Only one name can be specified even when two or more JSON files are processed.
It means that this switch has meaning only when one file is processed.

.PARAMETER Unicode
Force to convert all \uNNNNN characters to number.

.EXAMPLE
PS > ..\idleTime\JsonTo-Html.ps1 .\system-idletime.1.json

Result was saved to a file C:\dev\power\logs\system-idletime.1.html.

.EXAMPLE
PS > dir ..\logs\ | %{$_.FullName} | ..\idleTime\JsonTo-Html.ps1
Result was saved to a file C:\dev\power\logs\system-idletime.1.html.
Result was saved to a file C:\dev\power\logs\system-idletime.2.html.
Result was saved to a file C:\dev\power\logs\yy.html.

#>
#
# Command line option parameters
#
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)][String[]]$Path,
    [String]$Html = "C:\Temp\CDAT330\Templates\template.html",
    [string]$Out,
    [switch]$Unicode
)

Begin {
    $ErrorActionPreference = "Stop"
    Add-Type -AssemblyName System.Web

    if (-not (Test-Path -Path $Html -PathType Leaf)) {
        Write-Error -Category InvalidArgument -Message "The base html file $($Html) does not exist."
    }
}

Process {
    foreach ($p in $Path) {
        Get-Item -Path $p | Get-ChildItem -File | ForEach-Object {
            $f = $_
            try {
                if ($o = Get-Content -Path $f.FullName -Raw | ConvertFrom-Json) {

                    $json = $o | ConvertTo-Json -Depth 5 -Compress
                    
                    #ConvertTo-Json automatic character escape feature affects the characters in usageData so Regex was added to convert it back to actual string

                    if ($Unicode) {
                        $json = $json | ForEach-Object{
                            [Regex]::Replace($_,
                                "\\u(?<Value>[a-fA-F0-9]{4})", {
                                    param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                                        [System.Globalization.NumberStyles]::HexNumber))).ToString() } )}
                    }

                    # Compress the jason strings by gzip. Then, convert it to a BASE64 string.

                    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                    [System.IO.MemoryStream] $compressedData = New-Object System.IO.MemoryStream
                    $gzipStream = New-Object System.IO.Compression.GzipStream $compressedData, ([IO.Compression.CompressionMode]::Compress)
                    $gzipStream.Write($bytes, 0, $bytes.Length)
                    $gzipStream.Close()
                    $compressedData.Close()
                    $base64 = [System.Convert]::ToBase64String($compressedData.ToArray())

                    # Embed the BASE64 string of the compressed JSON report to the base html file.

                    $resultPath = $Out
                    if (-not $resultPath) {
                        $resultPath = "$($f.DirectoryName)\$($f.BaseName).html"
                    }

                    Get-Content -Path $Html | ForEach-Object {
                        $_ -replace 'const bodyCompressedBASE64 = null;', "const bodyCompressedBASE64 = `'$($base64)`'"
                    } | Out-File -FilePath $resultPath -Encoding utf8

                    if (Test-Path -Path $resultPath -PathType Leaf) {
                        Write-host "Result was saved to a file to system-idletime.html." -ForegroundColor DarkGreen
                    }
                }
            }
            catch {
                Write-Verbose -Message "Failed on handling a file $($f.FullName)`n $($_)"
            }
        }
    }
}

}

function Idlefunction
{
<#
.SYNOPSIS
Gathers system idle state time from Windows event log

.DESCRIPTION
The modern standby, legacy S3/S4 and shutdown/reboot are handled as an idle state.
Then, builds a weekly usage map.

.PARAMETER Weeks
Number of weeks to be sampled.

.PARAMETER Timeunit
Length of one time slot per minute.

.PARAMETER Path
Name of a result html file. Set $null to generate a unique file name.

.PARAMETER Diagnostics
Embed detailed information to JSON report.

.PARAMETER SxEntry
A Sx enter reason code to be flagged in the html report.

.PARAMETER MsEntry
A Modern Standby enter reason code to be flagged in the html report.

.PARAMETER shutdown
A shutdown reason code to be flagged in the html report.

#>
#
# Command line option parameters
#
[CmdletBinding()]
Param(
    [uint32]$Weeks = 1000,
    [uint32]$Timeunit = 15,
    [string]$Path = "C:\temp\CDAT$CDATv\system-idletime.html",
    [switch]$Diagnostics,
    [int32]$SxEntry = -1,
    [int32]$MsEntry = -1,
    [int32]$Shutdown = -1
)

function isSleepEntry {
    param (
        [Object]$Event
    )

    ($Event.EventCode -eq 42) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Power")
}

function isSleepExit {
    param (
        [Object]$Event
    )

    (($Event.EventCode -eq 1) -and ($Event.SourceName -like "Microsoft-Windows-Power-Troubleshooter")) -or `
    (($Event.EventCode -eq 130) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Power")) -or `
    (($Event.EventCode -eq 30) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Boot"))
}

function isShutdownEntry {
    param (
        [Object]$Event
    )

    ($Event.EventCode -eq 109) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Power")
}

function isShutdownExit {
    param (
        [Object]$Event
    )

    (($Event.EventCode -eq 20) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Boot"))
}

function isModernStandbyEntry {
    param (
        [Object]$Event
    )

    ($Event.EventCode -eq 506) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Power")
}

function isModernStandbyExit {
    param (
        [Object]$Event
    )

    (($Event.EventCode -eq 507) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Power")) -or `
    (($Event.EventCode -eq 30) -and ($Event.SourceName -like "Microsoft-Windows-Kernel-Boot"))
}

function isCriticalEvent {
    param (
        [Object]$Event
    )

    $Event.Type -like "Critical"
}

function findTimeZoneAfter {
    param (
        [datetime]$Time,
        [PSCustomObject[]]$TimeZones
    )

    # A first timezone object after the specified time is returned.

    $r = $TimeZones[$TimeZones.Length - 1]
    foreach ($tz in $TimeZones) {
        if ($tz.t -ge $Time) {
            $r = $tz
            break
        }
    }
    $r
}

function findTimeZoneForBefore {
    param (
        [datetime]$Time,
        [PSCustomObject[]]$TimeZones
    )

    # A last timezone object before the specified time is returned.

    $r = $TimeZones[0]
    foreach ($tz in $TimeZones) {
        if ($tz.t -gt $Time) {
            break
        }
        $r = $tz
    }
    $r
}

function Get-NumberOfDays {
    param (
        [PSCustomObject[]]$Timeslots,
        [datetime]$Start,
        [datetime]$End
    )

    # A number of whole weeks between start and end.

    $w = [System.Math]::Floor(($End - $Start).Days / 7)

    # Find a time offset in a week of start and end time

    $wd = [Array]::IndexOf($weekDayTable, [string]$Start.DayOfWeek)
    $weekOffsetStart = $Start - ($Start.Date - (New-TimeSpan -Days $wd))
    $wd = [Array]::IndexOf($weekDayTable, [string]$End.DayOfWeek)
    $weekOffsetEnd = $End - ($End.Date - (New-TimeSpan -Days $wd))

    # Add one day if a time slot is in a rest of days

    foreach ($s in $Timeslots) {
        $days = $w
        if ($weekOffsetEnd -ge $weekOffsetStart) {
            if (($weekOffsetStart -le $s.EndTime) -and ($s.StartTime -le $weekOffsetEnd)) {
                $days++
            }
        }
        else {
            if (($weekOffsetStart -le $s.EndTime) -or ($s.StartTime -le $weekOffsetEnd)) {
                $days++
            }
        }
        $s | Add-Member -MemberType NoteProperty -Name Days -Value $days
        $s
    }
}

# Script main body

$ErrorActionPreference = "Stop"
$weekDayTable = @("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
$powerState = @("Sx Unspecified", "S0", "S1", "S2", "S3 Suspend", "S4 Hibernate", "Fast Shutdown")

# Validate arguments

if ((60 * 24) % $Timeunit -ne 0) {
    Write-Error -Category InvalidArgument -Message "The Timeunit must be a divisor of (60 * 24)."
}

# Define a sample start time

$now = Get-Date
$after = $now - (New-TimeSpan -Days ($Weeks * 7))
$afterUTC = $after.ToUniversalTime().ToString("yyyyMMddHHmmss.FFFFFFF")

# Gather event log related with sleep

$EventQ = "Select * From Win32_NTLogEvent" + `
    " Where (Logfile=`'System`') And " + `
    " (TimeGenerated >= `'$($afterUTC)`') And " + `
    " (" + `
    " SourceName=`'Microsoft-Windows-Kernel-Power`'" + `
    " Or SourceName=`'Microsoft-Windows-Kernel-Boot`'" + `
    " Or SourceName=`'Microsoft-Windows-Power-Troubleshooter`'" + `
    " Or Type=`'Critical`'" + `
    " Or (SourceName=`'EventLog`' And EventCode=6013)" + `
    " Or (SourceName=`'Microsoft-Windows-Kernel-General`' And EventCode=1)" + `
    ")"

Write-output "Creating - Windows Data, please wait..." 
Start-sleep 10

                        try 
                                {
                                    
                                    $events = Get-CimInstance -Namespace root/CIMV2 -Query $EventQ -ErrorAction Ignore
                                
                                }

                        catch   
                                { 
                                    
                                    Write-Output "Error occured while gathering data on 1st attempt." > C:\temp\CDAT$CDATv\CDAT330IdleFunctionErrors.log
                                    Write-output "Attempting to Gather Data again..."
                                    $events = Get-CimInstance -Namespace root/CIMV2 -Query $EventQ -ErrorAction Ignore



                                }

# Create sleep session objects

$idleSessions = @()

[array]$sleepEvents = $events | Where-Object { (isSleepEntry -Event $_) -or (isSleepExit -Event $_) } | Sort-Object -Property TimeGenerated
$session = $null
foreach ($e in $sleepEvents) {
    if ($session) {
        if (isSleepExit -Event $e) {
            $session | Add-Member -MemberType NoteProperty -Name "Exit" -Value $e.TimeGenerated
            $session | Add-Member -MemberType NoteProperty -Name "ExitMessage" -Value $e.Message
            $idleSessions += $session
            $session = $null
        }
    }

    if (isSleepEntry -Event $e) {
        $session = [PSCustomObject]@{
            Category     = $powerState[$e.InsertionStrings[0]]
            Entry        = $e.TimeGenerated
            EntryMessage = $e.Message
            EntryReason  = $e.InsertionStrings[2]
        }
    }
}

# Create shutdown/reboot session objects

[array]$shutdownEvents = $events | Where-Object { (isShutdownEntry -Event $_) -or (isShutdownExit -Event $_) } | Sort-Object -Property TimeGenerated
$session = $null
foreach ($e in $shutdownEvents) {
    if ($session) {
        if (isShutdownExit -Event $e) {
            $session | Add-Member -MemberType NoteProperty -Name "Exit" -Value $e.TimeGenerated
            $session | Add-Member -MemberType NoteProperty -Name "ExitMessage" -Value $e.Message
            $idleSessions += $session
            $session = $null
        }
    }

    if (isShutdownEntry -Event $e) {
        $session = [PSCustomObject]@{
            Category     = "Shutdown"
            Entry        = $e.TimeGenerated
            EntryMessage = $e.Message
            EntryReason  = $e.InsertionStrings[2]
        }
    }
}

# Create modern standby session objects

[array]$msEvents = $events | Where-Object { (isModernStandbyEntry -Event $_) -or (isModernStandbyExit -Event $_) } | Sort-Object -Property TimeGenerated
$session = $null
foreach ($e in $msEvents) {
    if ($session) {
        if (isModernStandbyExit -Event $e) {
            $session | Add-Member -MemberType NoteProperty -Name "Exit" -Value $e.TimeGenerated
            $session | Add-Member -MemberType NoteProperty -Name "ExitMessage" -Value $e.Message
            try {
                $session | Add-Member -MemberType NoteProperty -Name "ExitReason" -Value ($e.InsertionStrings[9])
            }
            catch {
                Write-Verbose -Message "Modern Standby at $($session.Entry) does not have a wake event log."
            }

            $idleSessions += $session
            $session = $null
        }
    }

    if (isModernStandbyEntry -Event $e) {
        $session = [PSCustomObject]@{
            Category     = "Modern Standby"
            Entry        = $e.TimeGenerated
            EntryMessage = $e.Message
            EntryReason  = $e.InsertionStrings[0]
        }
    }
}

# Create critical event objects

$criticals = @()
[array]$criticalEvents = $events | Where-Object { isCriticalEvent -Event $_ } | Sort-Object -Property TimeGenerated
foreach ($e in $criticalEvents) {
    if (isCriticalEvent -Event $e) {
        $criticals += [PSCustomObject]@{
            Category = "CriticalEvent"
            Time     = $e.TimeGenerated.ToString("o")
            Source   = $e.SourceName
            EventID  = $e.EventCode
            Message  = $e.Message
        }
    }
}

# Create time zone information objects

$systemTimezones = [System.TimeZoneInfo]::GetSystemTimeZones()
$regexTz = '^[^\s]+\s+(?<tz>.+?)$'

[array]$timeZones = $events | Where-Object { ($_.EventCode -eq 6013) -and ($_.SourceName -eq 'EventLog') } | Sort-Object -Property TimeGenerated | ForEach-Object {
    if ($_.InsertionStrings[6] -match $regexTz) {

        # Find a timezone information for this event.

        $tz = $null
        foreach ($z in $systemTimezones) {
            if (($z.StandardName -eq $Matches.tz) -or ($z.DaylightName -eq $Matches.tz) -or ($z.Id -eq $Matches.tz)) {
                $tz = $z
                break
            }
        }

        # Create a time zone information object.

        if ($tz) {
            $utcOffset = ([System.TimeZoneInfo]::FindSystemTimeZoneById($tz.Id)).GetUtcOffset($_.TimeGenerated)

            [PSCustomObject]@{
                t         = $_.TimeGenerated
                Time      = $_.TimeGenerated.ToString("o")
                UtcOffset = $utcOffset
                OffsetMin = $utcOffset.TotalMinutes
                TimeZone  = $tz.Id
            }
        }
    }
}

# Add current timezone as a latest timezone.

$currentTZ = Get-TimeZone
$utcOffset = ([System.TimeZoneInfo]::FindSystemTimeZoneById($currentTZ.Id)).GetUtcOffset($now)

$lastTimezone = [PSCustomObject]@{
    t         = $now
    Time      = $now.ToString("o")
    UtcOffset = $utcOffset
    OffsetMin = $utcOffset.TotalMinutes
    TimeZone  = $currentTZ.Id
}
$timeZones += @($lastTimezone)

# Suppose that known first timezone had been kept for ten years.

$firstTimezone = $timeZones[0].PsObject.Copy()
$firstTimezone.t += New-TimeSpan -Days (3650 * -1)
$firstTimezone.Time = $firstTimezone.t.ToString("o")
$timeZones = @($firstTimezone) + $timeZones

# Create timezone change event objects. Suppose that an available timezone object just after this event was applied.

$tzChanges = @($timeZones[0].PsObject.Copy())
$tzChanges += $events | Where-Object {
    ($_.EventCode -eq 1) -and ($_.SourceName -eq 'Microsoft-Windows-Kernel-General') -and ($_.InsertionStrings[2] -eq "3")
} | Sort-Object -Property TimeGenerated | ForEach-Object {
    $tz = findTimeZoneAfter -Time $_.TimeGenerated -TimeZones $timeZones | ForEach-Object { $_.PsObject.Copy() }

    $tz.t = $_.TimeGenerated
    $tz.Time = $_.TimeGenerated.ToString("o")
    $tz
}

# Sort objects

$idleSessions = $idleSessions | Sort-Object -Property Entry
$criticalEvents = $criticalEvents | Sort-Object -Property Time

# Create an object for general information

$os = Get-CimInstance -ClassName Win32_OperatingSystem

$logInformation = [PSCustomObject]@{
    ComputerName = $env:COMPUTERNAME
    OSVersion    = $os.Version
    From         = $after.ToString("o")
    To           = $now.ToString("o")
    Weeks        = $Weeks
}

if ($SxEntry -ge 0) {
    $logInformation | Add-Member -MemberType NoteProperty -Name FocusedSxEntry -Value $SxEntry
}
if ($MsEntry -ge 0) {
    $logInformation | Add-Member -MemberType NoteProperty -Name FocusedMsEntry -Value $MsEntry
}
if ($Shutdown -ge 0) {
    $logInformation | Add-Member -MemberType NoteProperty -Name FocusedShutdown -Value $Shutdown
}

# Create weekdays time slot objects

$timeSlots = @()
$slotLength = New-TimeSpan -Minutes $Timeunit

for ($i = 0; $i -lt (60 * 24 * 7); $i += $Timeunit) {
    $time = New-TimeSpan -Minutes $i
    $dayOfWeek = $weekDayTable[$time.Days]
    $timeOfDay = $time - (New-TimeSpan -Days $time.Days)

    $slot = [PSCustomObject]@{
        StartTime = $time
        EndTime   = $time.Add($slotLength)
        DayOfWeek = $dayOfWeek
        IdleCount = 0
        Start     = $timeOfDay.ToString("hh\:mm")
        End       = $timeOfDay.Add($slotLength).ToString("hh\:mm")
    }
    $timeSlots += $slot
}

$timeSlots = Get-NumberOfDays -Timeslots $timeSlots -Start $idleSessions[0].Entry -End $now

# Map idle state

foreach ($s in $idleSessions) {

    # Take care of the case that idle session is longer than one week.

    $weeksDelta = [Math]::Floor((($s.Exit - $s.Entry).Days) / 7)
    if ($weeksDelta -lt 0) {
        $weeksDelta = 0
    }

    # Find time zone at this idle session, then save it to the idle session object.

    $tz = findTimeZoneForBefore -Time $S.Exit -TimeZones $tzChanges
    $s | Add-Member -MemberType NoteProperty -Name TimeZone -Value $tz.TimeZone
    $s | Add-Member -MemberType NoteProperty -Name UtcOffset -Value $tz.OffsetMin

    # Find weekday & time of the event.

    $entry = $s.Entry.ToUniversalTime() + $tz.UtcOffset
    $exit = $s.Exit.ToUniversalTime() + $tz.UtcOffset

    $wd = [Array]::IndexOf($weekDayTable, [string]$entry.DayOfWeek)
    $sessionEntry = $entry - ($entry.Date - (New-TimeSpan -Days $wd))

    $wd = [Array]::IndexOf($weekDayTable, [string]$exit.DayOfWeek)
    $sessionExit = $exit - ($exit.Date - (New-TimeSpan -Days $wd))

    # Update idle count of each timeslot.

    if ($sessionExit -ge $sessionEntry) {
        foreach ($t in $timeSlots) {
            $t.IdleCount += $weeksDelta
            if (($sessionEntry -le $t.StartTime) -and ($sessionExit -ge $t.EndTime)) {
                $t.IdleCount++
            }
        }
    }
    else {
        foreach ($t in $timeSlots) {
            $t.IdleCount += $weeksDelta
            if (($sessionEntry -le $t.StartTime) -or ($sessionExit -ge $t.EndTime)) {
                $t.IdleCount++
            }
        }
    }
}

# Remove properties no longer used

foreach ($s in $idleSessions) {
    $start = $s.Entry.ToString("o")
    $exit = $s.Exit.ToString("o")
    $s.PSObject.Properties.Remove("Entry")
    $s.PSObject.Properties.Remove("Exit")
    $s | Add-Member -MemberType NoteProperty -Name "Entry" -Value $start
    $s | Add-Member -MemberType NoteProperty -Name "Exit" -Value $exit
}

foreach ($t in $timeSlots) {
    $t.PSObject.Properties.Remove("StartTime")
    $t.PSObject.Properties.Remove("EndTime")
}

# Build a result object

$out = [PSCustomObject]@{
    Information    = $logInformation
    IdleSessions   = $idleSessions
    CriticalEvents = $criticals
    IdleMap        = $timeSlots
}

if ($Diagnostics) {

    # Timezone objects

    foreach ($tz in $timeZones) {
        $tz.PSObject.Properties.Remove("t")
        $tz.PSObject.Properties.Remove("UtcOffset")
    }
    $out | Add-Member -MemberType NoteProperty -Name Timezones -Value $timeZones

    foreach ($tz in $tzChanges) {
        $tz.PSObject.Properties.Remove("t")
        $tz.PSObject.Properties.Remove("UtcOffset")
    }
    $out | Add-Member -MemberType NoteProperty -Name TimezoneChanges -Value $tzChanges

    # Additional information for diagnostic purpose

    $logInformation | Add-Member -MemberType NoteProperty -Name Computer -Value (Get-CimInstance -ClassName Win32_ComputerSystem)
    $logInformation | Add-Member -MemberType NoteProperty -Name BIOS -Value (Get-CimInstance -ClassName Win32_BIOS)
    $logInformation | Add-Member -MemberType NoteProperty -Name OS -Value $os
    $logInformation | Add-Member -MemberType NoteProperty -Name Disks -Value (Get-CimInstance -ClassName Win32_DiskDrive)
    $logInformation | Add-Member -MemberType NoteProperty -Name Batteries -Value (Get-CimInstance -ClassName Win32_Battery)
}

# Output result

$jsonFile = New-TemporaryFile
$out | ConvertTo-Json -Depth 2 | Out-File $jsonFile -Encoding utf8

if ((Test-Path -Path $jsonFile -PathType Leaf) -and ($jsonFile.Length -gt 0)) {
    if (-not $Path) {
        $Path = ".\system-idletime.$($logInformation.ComputerName).$($now.ToString("yyyy-MM-dd.HH-mm-ss")).html"
    }
    if ($result = $jsonFile.FullName | & JsonConvert -Html "C:\temp\CDAT330\Templates\template.html" -Out $Path) {
        Remove-Item $jsonFile
        $result
    }
}
}

function Intel_VPro

    {
        If ($((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*") -eq $true)                       

        {
            $AMT=(get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"}).CurrentSetting
            $AMT1=(get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"}).CurrentSetting
            
            if ($AMT -eq "AMTControl,Enable") {
    
                Write-Host "Creating - VPro Setting log"
                Get-WmiObject Win32_Processor > C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"}).CurrentSetting  >> C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                [void] (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"} >> C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
            }
            if ($AMT1 -eq "AMTControl,Disable") {
    
                Write-host "Please see IntelNonVproSystem log for more information on your CPU" 
                Get-WmiObject Win32_Processor > C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                (Get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"}).CurrentSetting  >> C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                [void] (Get-WmiObject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"} >> C:\temp\CDAT$CDATv\CDAT$CDATv-IntelVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
            }
            if (-not $AMT) 
                    {
                
                        Write-Output "Your CPU is not Vpro Capable - $((Get-WmiObject Win32_Processor).name)" > C:\temp\CDAT$CDATv\CDAT$CDATv-IntelNonVproSystem-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
            
                    }   
        }
    
        else 
        {
                Write-Host "Determing if this system is AMT capable, please wait..."
                Write-Host "This System does not have API interface to BIOS settings and does not have a VPro CPU" > C:\temp\CDAT$CDATv\CDAT$CDATv-NONThinkPadAMT$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
        }

    }

function Intel_ME

    {
        if (Get-WmiObject Win32_PnPSignedDriver | select-object DeviceName, DriverVersion | Where-Object{($_.DeviceName -like '*Intel*' -and $_.DeviceName -like '*WMI*')})
    
        {
        Write-Output "Creating - Intel ME Firmware Dump"
        [VOID] (Get-Ciminstance -class ME_System -namespace 'Root\Intel_ME' > C:\temp\CDAT$CDATv\CDAT$CDATv-IntelME-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
        }

        else
        {
        Write-output "Intel ME WMI provider software is not installed, install that software package and run this tool again" > C:\temp\CDAT$CDATv\CDAT$CDATv-IntelME-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
        Write-output "Your CPU is an $((Get-WmiObject Win32_Processor).Name)" >> C:\temp\CDAT$CDATv\CDAT$CDATv-IntelME-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
        }

    }

function AMD_DASH

        {


                    $Dash2=(get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "DashEnabled"}).CurrentSetting

    
                    if ($Dash2 -eq "DashEnabled,Disable") {
                        #Write-host "Your CPU $((Get-WmiObject Win32_Processor).name) supports Dash but is Disabled"
                        [VOID] (New-Item C:\temp\CDAT$CDATv\CDAT$CDATv-DashReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
                        Set-Content C:\temp\CDAT$CDATv\CDAT$CDATv-DashReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log "Your CPU is Dash Capable but is set to Disabled - $((Get-WmiObject Win32_Processor).name)"
                    
                    }
                    if ($Dash2 -eq "DashEnabled,Enable") {
                        #Write-host "Your CPU $((Get-WmiObject Win32_Processor).name) supports Dash and is Enabled"
                        [VOID] (New-Item C:\temp\CDAT$CDATv\CDAT$CDATv-DashReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
                        Set-Content C:\temp\CDAT$CDATv\CDAT$CDATv-DashReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log "Your CPU is Dash Capable but is set to Enabled - $((Get-WmiObject Win32_Processor).name)"
                    
                    }
        }


function Check_Program_Installed( $programName ) 

    {
    $x86_check = ((Get-ChildItem "HKLM:Software\Microsoft\Windows\CurrentVersion\Uninstall") |
    Where-Object { $_."Name" -like "*$programName*" } ).Length -gt 0
    
    Return $x86_check;
    }


function Scale
        
                    {
                        $scaling = (96,"100%","Small"),(120,"125%","Medium"),(144,"150%","Large"),(288,"300%","Custom")
                        $system_scale = (Get-ItemProperty -Path "HKLM:/Software/Microsoft/Windows NT/CurrentVersion/FontDPI").logpixels
                        
                        foreach($array in $scaling)
                                        {
                                            if($array[0] -eq $system_scale)
                                                    {
                                                        write-output "DPI Scaling:                      $($array[2]) ($($array[1]))"
                                                    }
                                        }

                        
                    }
function AMDDSC 

                    {

                                                                     # Purpose - to find if the client system has DSC enabled or disabled

                                    # Variables

                                            # $value ='DalDisableDSC'
                                            # $path ='HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000'
                                            # AMD $check = $null -eq (Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000" ).GetValue('DalDisableDSC')
                                            $Check = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000\DalDisableDSC'

                                        if ( $check -eq $False )

                                                        { Write-Output "DSC is Enabled" }

                                        if ($Check -eq $True)
                                                        {
                                                            $Reg0 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000" | select-object -ExpandProperty DalDisableDSC -ErrorAction SilentlyContinue

                                                            if ($Reg0 -eq 1)
                                                                    {Write-output "DSC is Disabled"}

                                                            if ($Reg0 -eq 0)
                                                                    {write-output "DSC was altered and is enabled"}

                                                        }


                    }

function IntelDSC 

            {

 
                                    # Purpose - to find if the client system has DSC enabled or disabled

                                    # Variables

                                            # $value ='DalDisableDSC'
                                            # $path ='HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000'and 0001'
                                            # INTEL $check1 = $null -eq $(Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0001" ).GetValue('DPMstDscDisable')
                                            $Check = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000\DPMstDscDisable'
                                            $Check1 = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0001\DPMstDscDisable'

                                        if ( $check -and $check1 -eq $False )

                                                        { Write-Output "DSC is Enabled" }

                                        if ($Check -or $Check1 -eq $True)
                                                        {
                                                            $Reg0 = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e330-11ce-bfc1-08002be10318}\0000" | select-object -ExpandProperty DPMstDscDisable -ErrorAction SilentlyContinue
                                                            if ($Reg0 -eq 1)
                                                                    {Write-output "DSC is Disabled"}
                                                            if ($Reg0 -eq 0)
                                                                    { Write-Output "DSC was altered and is enabled" }

                                                        }
            }

        Function DSC
                    {

                    # AMD or Intel Detection

                    $ProcDetect = (Get-WmiObject win32_processor).Manufacturer


                    If ($ProcDetect -eq "AuthenticAMD")

                                    {
                                        AMDDSC

                                    }

                    If ($ProcDetect -eq "GenuineIntel")

                                    {
                                        IntelDSC
                                        
                                    }

                    }              

        Function Get-RebootHistory {
                    <#
                    .SYNOPSIS
                        This will output who initiated a reboot or shutdown event.
                    
                    .NOTES
                        Name: Get-RebootHistory
                        Author: theSysadminChannel
                        Version: 1.0
                        DateCreated: 2020-Aug-5
                    
                    .LINK
                        https://thesysadminchannel.com/get-reboot-history-using-powershell -
                    
                    .EXAMPLE
                        Get-RebootHistory -ComputerName Server01, Server02
                    
                    .EXAMPLE
                        Get-RebootHistory -DaysFromToday 30 -MaxEvents 1
                    
                    .PARAMETER ComputerName
                        Specify a computer name you would like to check.  The default is the local computer
                    
                    .PARAMETER DaysFromToday
                        Specify the amount of days in the past you would like to search for
                    
                    .PARAMETER MaxEvents
                        Specify the number of events you would like to search for (from newest to oldest)
                    #>
                    
                    
                        [CmdletBinding()]
                        param(
                            [Parameter(
                                Mandatory = $false,
                                ValueFromPipeline = $true,
                                ValueFromPipelineByPropertyName = $true
                            )]
                            [string[]]  $ComputerName = $env:COMPUTERNAME,
                    
                            [int]       $DaysFromToday = 7,
                    
                            [int]       $MaxEvents = 9999
                        )
                    
                        BEGIN {}
                    
                        PROCESS {
                            foreach ($Computer in $ComputerName) {
                                try {
                                    $Computer = $Computer.ToUpper()
                                    $EventList = Get-WinEvent -ComputerName $Computer -FilterHashtable @{
                                        Logname = 'system'
                                        Id = '1074', '6008'
                                        StartTime = (Get-Date).AddDays(-$DaysFromToday)
                                    } -MaxEvents $MaxEvents -ErrorAction Stop
                    
                    
                                    foreach ($Event in $EventList) {
                                        if ($Event.Id -eq 1074) {
                                            [PSCustomObject]@{
                                                TimeStamp    = $Event.TimeCreated
                                                ComputerName = $Computer
                                                UserName     = $Event.Properties.value[6]
                                                ShutdownType = $Event.Properties.value[4]
                                            }
                                        }
                    
                                        if ($Event.Id -eq 6008) {
                                            [PSCustomObject]@{
                                                TimeStamp    = $Event.TimeCreated
                                                ComputerName = $Computer
                                                UserName     = $null
                                                ShutdownType = 'unexpected shutdown'
                                            }
                                        }
                    
                                    }
                    
                                } catch {
                                    Write-Error $_.Exception.Message
                    
                                }
                            }
                        }
                    
                        END {}
                    }

        function Get-Temperature
        
                {
                    $t = Get-WmiObject MSAcpi_ThermalZoneTemperature -Namespace "root/wmi" -ErrorAction SilentlyContinue
                    $returntemp = @()

                    foreach ($temp in $t.CurrentTemperature)
                    {


                    $currentTempKelvin = $temp / 10
                    $currentTempCelsius = $currentTempKelvin - 273.15

                    $currentTempFahrenheit = (9/5) * $currentTempCelsius + 32

                    $returntemp += $currentTempCelsius.ToString() + " C : " + $currentTempFahrenheit.ToString() + " F " 
                    }
                    return $returntemp
                }

        function Get-RegistryData 
        
                {
                    param (
                        [string]$Path
                    )
                
                    $o = Get-ItemProperty -Path $Path
                    $o.PSObject.Properties.Remove("PSParentPath")
                    $o.PSObject.Properties.Remove("PSChildName")
                    $o.PSObject.Properties.Remove("PSProvider")
                    $o
                }
        
        function GetPluginVersion 
        
                {
                    # $path= $args[0]
                    $versinfo = [system.diagnostics.fileversioninfo]::GetVersionInfo($args[0])
                    $obj = New-Object PSObject
                    $obj | Add-Member -MemberType NoteProperty -Name "PluginName" -Value $($args[1])
                    $obj | Add-Member -MemberType NoteProperty -Name "ProductVersion" -Value $($versinfo.ProductVersion)
                    $obj | Add-Member -MemberType NoteProperty -Name "FileVersion" -Value $($versinfo.FileVersion)
                    return $obj
                }
        
        
        function GetECFirmwareVersion 

                {
                    #get ec firmware version from registry key
                    $RegMainKey = "HARDWARE\\DESCRIPTION\\System\\BIOS"
                    $reg = [microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine', $computername)
                    $regkey = $reg.OpenSubKey($RegMainKey)
                    $ecstring = "EC Firmaware Version: $($regkey.GetValue("ECFirmwareMajorRelease")).$($regkey.GetValue("ECFirmwareMinorRelease"))"
                    return $ecstring
                }
        
        function GetTouchpadFirmwareVersion 
        
                {
                    #get touchpad firmware version from registry
                    #this is assuming that the touchpad vendor is synaptics
                
                    $RegMainKey = "SOFTWARE\\Synaptics\\OEM\\TouchPad"
                    $reg = [microsoft.win32.registrykey]::OpenRemoteBaseKey('LocalMachine', $computername)
                    $regkey = $reg.OpenSubKey($RegMainKey)
                    if ($regkey) {3.2.2
                        $regval = $regkey.GetValue("FirmwareVersion")
                        return "TouchPad Firmaware Version: $(($regval -shr 8) -band 0xF).$($regval -band 0xF)"
                    }
                    else {
                        return ""
                    }
                }

        Function ChargePercent
                {
                    $RemainingCap = (Get-WmiObject -Namespace 'ROOT\WMI' BatteryStatus).RemainingCapacity
                    $LastChargedCap = ((Get-WmiObject -Namespace 'ROOT\WMI' BatteryFullChargedCapacity).FullChargedCapacity)

                    if ($LastChargedCap -eq 0)
                        {
                            Write-output "Battery Last Full Charged Capacity reports a value of 0, please check your battery"
                        }
                    else 
                        {
                            ([Math]::Round($remainingCap/$lastChargedCap * 100))
                        }

                }

        function KnownIssues 
                    {
                        $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                        $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                        $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                        $Time = ((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")
                        $BIOS = (Get-WmiObject win32_bios).SMBiosBIOSVersion
                        $ECMajor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMajorVersion
                        $ECMinor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMinorVersion
                        $Baseboard = (Get-WmiObject win32_baseboard).SerialNumber
                        $UUID = (Get-CimInstance -Class Win32_ComputerSystemProduct).UUID


                        Write-output "=======================================" 
                        Write-output "     Potential Issues Collection       " 
                        Write-output "=======================================" 
                        Write-Output " " 
                        Write-Output "CDAT v$CDATVer Collection" 
                        Write-Output "ComputerName: $env:Computername"
                        Write-Output "Date:         $($Time)"  
                        Write-Output "System:       $($SystemFamily)"  
                        Write-Output "Baseboard SN: $($Baseboard)" 
                        Write-output "UUID:         $($UUID)"
                        Write-Output "MTM:          $($Model)"  
                        Write-Output "SN            $($SerialNumber)" 
                        Write-Output "Arch:         $(ProcDetect)" 
                        Write-Output "BIOS:         $($BIOS)"  
                        Write-Output "EC:           $($ECMajor).$($ECMinor)" 
                        IntelMEFW -ErrorAction SilentlyContinue
                        DockDetect -ErrorAction SilentlyContinue
                        Write-Output "WIN OS:       $((Get-CimInstance -ClassName CIM_OperatingSystem).Caption)"  
                        Write-Output "Build:        $((Get-WmiObject Win32_OperatingSystem).Version)"  
                        Write-Output "Version:      $((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").DisplayVersion)"  
                        Write-Output "Preload:      $(Preload)"
                        Write-Output " " 
                        Write-output "=======================================" 
                        Write-output "     CDAT Observations                 " 
                        Write-output "=======================================" 
                                                                    $ConfigManagerErrorCode = @{
                                                                        Name = 'ConfigManagerErrorCode'
                                                                        Expression = {
                                                                        # property is an array, so process all values
                                                                        $value = $_.ConfigManagerErrorCode
                                                                        
                                                                        switch([int]$value)
                                                                            {
                                                                            0          {'This device is working properly.'}
                                                                            1          {'This device is not configured correctly.'}
                                                                            2          {'Windows cannot load the driver for this device.'}
                                                                            3          {'The driver for this device might be corrupted, or your system may be running low on memory or other resources.'}
                                                                            4          {'This device is not working properly. One of its drivers or your registry might be corrupted.'}
                                                                            5          {'The driver for this device needs a resource that Windows cannot manage.'}
                                                                            6          {'The boot configuration for this device conflicts with other devices.'}
                                                                            7          {'Cannot filter.'}
                                                                            8          {'The driver loader for the device is missing.'}
                                                                            9          {'This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.'}
                                                                            10         {'This device cannot start.'}
                                                                            11         {'This device failed.'}
                                                                            12         {'This device cannot find enough free resources that it can use.'}
                                                                            13         {'Windows cannot verify this device''s resources.'}
                                                                            14         {'This device cannot work properly until you restart your computer.'}
                                                                            15         {'This device is not working properly because there is probably a re-enumeration problem.'}
                                                                            16         {'Windows cannot identify all the resources this device uses.'}
                                                                            17         {'This device is asking for an unknown resource type.'}
                                                                            18         {'Reinstall the drivers for this device.'}
                                                                            19         {'Failure using the VxD loader.'}
                                                                            20         {'Your registry might be corrupted.'}
                                                                            21         {'System failure: Try changing the driver for this device. Windows is removing this device.'}
                                                                            22         {'This device is disabled.'}
                                                                            23         {'System failure: Try changing the driver for this device.'}
                                                                            24         {'This device is not present, is not working properly, or does not have all its drivers installed.'}
                                                                            25         {'Windows is still setting up this device.'}
                                                                            26         {'Windows is still setting up this device.'}
                                                                            27         {'This device does not have valid log configuration.'}
                                                                            28         {'The drivers for this device are not installed.'}
                                                                            29         {'This device is disabled because the firmware of the device did not give it the required resources.'}
                                                                            30         {'This device is using an Interrupt Request (IRQ) resource that another device is using.'}
                                                                            31         {'This device is not working properly because Windows cannot load the drivers required for this device.'}
                                                                            default    {"$value"}
                                                                            }
                                                                            
                                                                        }  
                                                                    }
                                                                    #endregion define calculated property
                                                                    
                                                                    <# retrieve all instances...
                                                                    Get-CimInstance -ClassName Win32_PNPEntity | 
                                                                        # ...and output properties "Caption" and "ConfigManagerErrorCode". The latter is defined
                                                                        # by the hashtable in $ConfigManagerErrorCode:
                                                                        Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log" -width 300
                                                                        C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log
                                                                        
                                                                    
                                                                        #Gather Devices with Issues
                                                                
                                                                            Write-output "Creating - Devices with Issues Report"
                                                                            Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap > C:\temp\CDAT$CDATv\Installed-HWD\DevicesWithIssues.log #>
                                                        
                                                                        # Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap
                                                        
                                                                        #Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize
                                                
                                                #Sleep, Hibernation, Screen Off Timers
                                                
                                                $PowerPlanObj = [PSCustomObject]@{
                                                    InstanceId = $null
                                                    ElementName = $null
                                                    Settings =  New-Object System.Collections.Generic.List[PSObject]  
                                                }
                        
                                                try {
                                                    # Get the Active Power Plan
                                                    $ActivePlan = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_Powerplan where IsActive=True" -ErrorAction Stop
                                                    #write-output ("Active Plan: " + $ActivePlan.InstanceId + " - " + $ActivePlan.ElementName)    
                                                    # Set the Active Plan info in the object
                                                    $PowerPlanObj.InstanceId = $ActivePlan.InstanceId
                                                    $PowerPlanObj.ElementName = $ActivePlan.ElementName
                                                } catch {
                                                    write-host "Error Querying root\cimv2\power Win32_Powerplan - make sure you have an elevated window"
                                                    write-output $_.ToString()
                                                    exit
                                                }
                        
                                                # Get the readable names for the settings
                                                try {
                                                    $SettingNames = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_PowerSetting" -ErrorAction Stop
                                                } catch {
                                                    write-host "Error Querying root\cimv2\power Win32_PowerSetting"
                                                    write-host $_.ToString()
                                                    exit
                                                }
                                                # Loop through the setting names and add them to a hashtable by setting id (use this to get the friendly name)
                                                $SettingHash = @{}
                                                foreach ($i in $SettingNames) {
                                                    # Turn this Microsoft:PowerSetting\{29f6c1db-86da-48c5-9fdb-f2b67b1f44da} 
                                                    # into {29f6c1db-86da-48c5-9fdb-f2b67b1f44da} for the key
                                                    $SettingId = $i.InstanceId.Split("\")[-1]
                                                    # Add it to the hash
                                                    $SettingHash.Add($SettingId,$i)
                                                    # Example: $i.ElementName = Sleep after
                                                }
                        
                                                # Change Microsoft:PowerPlan\{381b4222-f694-41f0-9685-ff5bb260df2e} 
                                                # to 381b4222-f694-41f0-9685-ff5bb260df2e for the query
                                                $ActivePlanId = $PowerPlanObj.InstanceId.Split("\")[-1].Replace("{","").Replace("}","")
                                                try {
                                                    $Settings = Get-WmiObject -Namespace "root\cimv2\power" -Query "select InstanceId,SettingIndexValue from Win32_PowerSettingDataIndex Where InstanceId Like '%$ActivePlanId%'" -ErrorAction Stop
                                                } catch {
                                                    write-host "Error Querying root\cimv2\power Win32_PowerSettingDataIndex"
                                                    write-host $_.ToString()
                                                    exit
                                                }
                        
                                                foreach ($i in $Settings) {
                                                    $SettingObj = [PSCustomObject]@{
                        
                                                        SettingName = $SettingHash.($i.InstanceId.Split("\")[-1]).ElementName
                                                        SettingType = $null
                                                        SettingValue = $i.SettingIndexValue
                                                        
                                                    }
                                                    # Tag the settings AC or DC
                                                    if ($i.InstanceId -match "AC") {
                                                        $SettingObj.SettingType = "AC"
                                                    }
                                                    if ($i.InstanceId -match "DC") {
                                                        $SettingObj.SettingType = "DC"
                                                    }
                                                    # Add the setting to the list
                                                    $PowerPlanObj.Settings.Add($SettingObj)
                                                }
                        # Unexpected Shutdowns
                                                UnexpectedShutdown -erroraction SilentlyContinue
                                                
                        # FastStartup
                        $FastStartup =(Get-ItemProperty -Path $registryPath -Name $registryName | Select-Object -ExpandProperty "HiberbootEnabled")

                                    if ($FastStartup -eq 0)
                                            {
                                                Write-Output "* Fast Startup is Disabled - May be a potential Issue"
                                            }

                        # Critical Battery Action 
                        if ($systype -eq 2) {
                                    
                                                if ($(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery action'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue) -ne "2")
                                                        {
                                                            Write-Output "Critical Battery Action on battery power, is not set to hibernate - may be a potential issue"
                                                        }

                                            }
                        # Cycle Count
                        if ($systype -eq 2) {

                                                $cycleCount = (get-wmiobject -namespace root\wmi batteryCycleCount).CycleCount
                                                        if ($cycleCount -lt "50")
                                                                    {
                                                                        Write-Output "* Battery Cycle Count is less than 50 cycles - This COULD indicate a system plugged into AC all the time.  Always consult first use date of the battery using Lenovo Vantage"
                                                                    }  

                                            }   
                        # DeviceManager Bangs
                        $DevManCount = (Get-CimInstance -ClassName Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Measure-object -line).lines
                                            Write-output "* This system shows $DevManCount Issue(s) in Device Manager, please review the Device Manager Issues section of this report for more details."

                        # MiniDump Check
                        $MiniDumpCHK = Test-path -Path C:\Windows\minidump\*.dmp

                                        If ($MiniDumpCHK -eq $True)
                                            {
                                                $MiniDumpCount = (Get-ChildItem C:\windows\minidump | Where-Object {$_.Length -lt 10000KB} | Measure-object -line ).lines
                                                Write-Output "* This system shows $MiniDumpCount Mini Dump(s), please review the Mini Dump section of this report for more details."
                                            }


                        # KernelDump Check
                        $KernelDumpCHK = Test-path -Path C:\Windows\*Memory*.dmp

                                        If ($KernelDumpCHK -eq $True)
                                            {
                                                $KernelDumpCount = (Get-ChildItem C:\windows\*Memory*.dmp | Measure-object -line ).lines
                                                Write-Output "* This system shows $KernelDumpCount Kernel Dump(s), please review the Kernel Dump section of this report for more details."
                                            }
                                
                        # Dash Detection
                        # Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}

                        If ($True -eq $(Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}))
                        {
                            IF($ProcDetect -eq "AuthenticAMD")
                            {
                                $Dashdetect=(get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "DashEnabled"}).CurrentSetting
                                
                                if ($Dashdetect -eq "DashEnabled,Enable") 
                                {
                                    
                                    Write-Output "* This system shows DASH is enabled."

                                }
                            }
                        }
                        # Preload
                        


                            
                        Write-output "=======================================" 
                        Write-output "     Power Attributes                  " 
                        Write-output "=======================================" 
                                                    Write-output ""
                                                    Write-output "Plugged In"
                                                    write-output ""               
                                                    Write-output "`tSleep After                   $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                                                    Write-output "`tHibernate After:              $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                                                    Write-output "`tTurn off display after:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Turn off display after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                                                    Write-output "`tDisplay Brightness:           $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Display brightness'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                                                    Write-output "`tPower Button Action:          $(PowerButtonActionAC)"
                        If ($systype -eq 2)
                                            {
                                                    Write-output "`tCritical Battery Level:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery level'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                                                    Write-output "`tCritical Battery Action:      $(CriticalBatteryActionAC)"
                                                    Write-output "`tLid Close Action:             $(LidCloseAC)"

                                                    write-output ""                            
                                                    Write-output "On Battery"
                                                    write-output ""
                                                    Write-output "`tSleep After:                  $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins" 
                                                    Write-output "`tHibernate After:              $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins" 
                                                    Write-output "`tTurn off display after:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Turn off display after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins"
                                                    Write-output "`tDisplay Brightness:           $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Display brightness'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue) %"
                                                    Write-output "`tLid Close Action:             $(LidCloseDC)"
                                                    Write-output "`tPower Button Action:          $(PowerButtonActionDC)"
                                                    Write-output "`tCritical Battery Level:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery level'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                                                    Write-output "`tCritical Battery Action:      $(CriticalBatteryActionDC)"
                                                    Write-output "`tLid Close Action:             $(LidCloseDC)"
                                            }
                        
                        Write-output "=======================================" 
                        Write-output "     Device Manager Issues             " 
                        Write-output "======================================="
                        DevMan
                        Write-output "=======================================" 
                        Write-output "     Reboot History                    " 
                        Write-output "======================================="
                        Get-RebootHistory -erroraction SilentlyContinue $env:computername -DaysFromToday 180 -MaxEvents 1000
                        Write-output ""
                        Write-output "=======================================" 
                        Write-output "     Shutdown Details                  " 
                        Write-output "======================================="
                        if ($null -ne (Get-EventLog -LogName system -Source user32))
                                            {
                                                    Get-EventLog -LogName system -Source user32 | format-table -AutoSize -Wrap
                                            }
                        Write-output "=======================================" 
                        Write-output "     Unexpected Shutdowns              " 
                        Write-output "======================================="
                        if ($True -eq (Get-EventLog -LogName System -EntryType error | Where-Object{$_.Source -ne "DCOM"}  | Where-Object{$_.Message -like "The previous system shutdown*"}))
                                            {
                        
                                                Get-EventLog -LogName System -EntryType error | Where-Object{$_.Source -ne "DCOM"}  | Where-Object{$_.Message -like "The previous system shutdown*"} | format-table -AutoSize -wrap
                                            
                                            }
                        Write-output ""
                        Write-output "=======================================" 
                        Write-output "     Event Viewer Critical Errors      " 
                        Write-output "======================================="
                        $Logs = Get-Winevent -ListLog *

                                foreach ($Log in $Logs) {
                                Get-WinEvent -filterhashtable @{logname = $Log.LogName; level= 1} -ErrorAction SilentlyContinue | 
                                select-object LogName,TimeCreated,Id,LevelDisplayName,Message | Format-Table -Wrap
                                #export-csv -append log.csv
                                }
                        Write-output ""
                        MiniD
                        DumpCHK
                        Write-output ""
                        LenovoVan

                    }

        Function MissingWU

                    {

                        #List all missing updates
                        $session1 = New-Object -ComObject Microsoft.Update.Session -ErrorAction silentlycontinue

                        $searcher = $session1.CreateUpdateSearcher()

                        $result = $searcher.Search("IsInstalled=0")

                        #Updates are waiting to be installed 
                        $updates = $result.Updates;

                        $updates | Format-Table Title, IsDownloaded, IsHiden, IsInstalled, IsMandatory, IsPresent, AutoSelection, AutoDownload -AutoSize -Wrap

                    }

Function QuickData

               { 
                    # $AudioVolume = Get-AudioDevice -PlaybackVolume
                    $BIOS = (Get-WmiObject win32_bios).SMBiosBIOSVersion
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    $UUID = (Get-CimInstance -Class Win32_ComputerSystemProduct).UUID
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $Baseboard = (Get-WmiObject win32_baseboard).SerialNumber
                    #$CPUTemp = Get-WMIObject MSAcpi_ThermalZoneTemperature -Namespace "root/wmi"
                    

                    start-sleep 10
                    
                    #Output

                            Write-output "=======================================" 
                            Write-output "     ThinkPad Quick Data Collection    " 
                            Write-output "=======================================" 
                            Write-Output " " 
                            Write-Output "Tool Run Location: $(Get-Location)"
                            Write-Output "CDAT v$CDATVer Collection" 
                            Write-Output "ComputerName: $env:Computername"
                            Write-Output "Date:         $($Time)"  
                            Write-Output "System:       $($SystemFamily)"  
                            Write-Output "Baseboard SN: $($Baseboard)" 
                            
                                if (Test-path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\MachineInfo')
                                    {
                                        
                                        write-output "MFG DATE:     $((Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\MachineInfo\').MFGDATE)"
                                    
                                    }
        
                            Write-output "UUID:         $($UUID)"
                            Write-Output "MTM:          $($Model)"  
                            Write-Output "SN            $($SerialNumber)" 
                            Write-Output "Arch:         $(ProcDetect)" 
                            Write-Output "BIOS:         $($BIOS)"  
                            Write-Output "EC:           $($ECMajor).$($ECMinor)"
                            Write-Output "SMBIOS:       $((Get-CimInstance -NameSpace root/WMI -ClassName MSSmBios_RawSMBiosTables -ErrorAction SilentlyContinue).SmbiosMajorVersion).$((Get-CimInstance -NameSpace root/WMI -ClassName MSSmBios_RawSMBiosTables).SmbiosMinorVersion)" 
                            IntelMEFW -ErrorAction SilentlyContinue
                            DockDetect -ErrorAction SilentlyContinue
                            Write-Output "WIN OS:       $((Get-CimInstance -ClassName CIM_OperatingSystem).Caption)"  
                            Write-Output "Build:        $((Get-WmiObject Win32_OperatingSystem).Version)"  
                            Write-Output "Version:      $((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").DisplayVersion)"   
                            Write-Output "Preload:      $(Preload)"
                            Write-Output "$(systeminfo | Select-String "original")" 
                            $LastBIOSTime = 'HKLM:System\CurrentControlSet\Control\Session Manager\Power'
                            Write-output "Last Bios POST Time:       $((Get-ItemProperty -path $LastBIOSTime).FwPOSTTime /1000 ) s"
                            Write-Output "" 
                            Write-output "=======================================" 
                            Write-output "     System Up Time                    " 
                            Write-output "=======================================" 
                            Write-Output $((get-date) - (gcim Win32_OperatingSystem).LastBootUpTime) | select-object Days, Hours, Minutes, seconds | format-table
                            Write-output "=======================================" 
                            Write-output "     Hardware Info                     " 
                            Write-output "=======================================" 
                            Write-Output " " 
                            Write-Output "CPU:          $((Get-WmiObject Win32_Processor).Name)"  
                            Write-Output "Memory:       $([Math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory/1GB)) GB" 
                            If ($ARMDetect -eq "Qualcomm") 
                            {

                            }
                            Else 
                            {

                                Write-Output "CPU Temp:     $(Get-Temperature)"
                                
                            }
                            Write-Output ""
                            Write-output "=======================================" 
                            Write-output "     Disk Information                  " 
                            Write-output "=======================================" 
                            #$SSD= (get-physicaldisk | Where-object MediaType -like ssd | select-object * |Format-list)
                            Write-output ""
                            get-physicaldisk | Where-object MediaType -like ssd | select-object FriendlyName, Bustype,Mediatype,FirmwareVersion, Healthstatus,Size, SerialNumber, AdapterSerialNumber, Physicallocation | format-list 
                            #foreach ($SSD in Get-physicalDisk) 
                            #{$SSD | select-object FriendlyName, Bustype,Mediatype,FirmwareVersion, Healthstatus,Size, SerialNumber, AdapterSerialNumber, Physicallocation | format-list }
                            
                            Write-Output "Disk Temps:" 
                            (Get-Disk | Get-StorageReliabilityCounter | select-object Temperature, UniqueID | format-table -autosize -wrap) 


                            If ($((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*") -eq $true)
                            {

                                            #Bios Security Variables 
                                            
                                            $SecureBoot = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "SecureBoot"}).CurrentSetting
                                            $DeviceGuard = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "DeviceGuard"}).CurrentSetting
                                            $DMA = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "EnhancedWindowsBiometricSecurity"}).CurrentSetting
                                            $Tamper = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "BottomCoverTamperDetected"}).CurrentSetting
                                            $BlockSID = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "BlockSIDAuthentication"}).CurrentSetting
                                            $AMTControl = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "AMTControl"}).CurrentSetting
                                            $LockBIOS = (get-wmiobject -class Lenovo_BiosSetting -namespace root\wmi | Where-Object {$_.CurrentSetting.split(",",[StringSplitOptions]::RemoveEmptyEntries) -eq "LockBIOSSettings"}).CurrentSetting
                                            $SVPCheck = (Get-WmiObject -Class Win32_ComputerSystem -Namespace Root\cimv2).AdminPasswordStatus

                                Write-Output " " 
                                
                                        If (!(test-path C:\Windows\minidump\*))
                                                {
                                                    Write-output "=======================================" 
                                                    Write-output "     Mini Dumps                        " 
                                                    Write-output "=======================================" 
                                                    write-output ""
                                                    Write-output "No minidumps found in C:\Windows\Minidump" 
                                                    write-output ""

                                                }

                                        else
                                                {        
                                                    #Gather mini-dump to folder

                                                    Write-output "=======================================" 
                                                    Write-output "     Mini Dumps                        " 
                                                    Write-output "=======================================" 
                                                    Get-ChildItem C:\windows\minidump\ | Where-Object {$_.Length -lt 10000KB}  | Format-Table


                                                }

                                        $DumpCHKDir = Test-path -Path C:\Windows\*Memory*.dmp
                                        $TargetDirDump = "C:\Windows\"
                                    
                                                If ($DumpCHKDir -eq $True)
                                                    {
                                                        Write-output "=======================================" 
                                                        Write-output "     Full Kernel Dumps                 " 
                                                        Write-output "=======================================" 
                                                        get-ChildItem $targetDirDump Memory*.dmp
                                    
                                                    }
                                    
                                                Else 
                                                    {
                                                        Write-output "=======================================" 
                                                        Write-output "     Full Kernel Dumps                 " 
                                                        Write-output "=======================================" 
                                                        Write-output "No Full Kernel Memory Dumps found in C:\Windows\"
                                    
                                                    }
                                Write-output ""
                                LenovoVan
                                Write-output "=======================================" 
                                Write-output "    Windows Updates (Available)        " 
                                Write-output "=======================================" 
                                    
                                If ((Get-NetConnectionProfile).IPv4Connectivity -contains "Internet" -or (Get-NetConnectionProfile).IPv6Connectivity -contains "Internet")
                                                    {
                                                        #List all missing updates
                                                        $session1 = New-Object -ComObject Microsoft.Update.Session -ErrorAction silentlycontinue

                                                        $searcher = $session1.CreateUpdateSearcher()

                                                        $result = $searcher.Search("IsInstalled=0")

                                                        #Updates are waiting to be installed 
                                                        $updates = $result.Updates;

                                                        $updates | Format-Table Title, IsDownloaded, IsHiden, IsInstalled, IsMandatory, IsPresent, AutoSelection, AutoDownload -AutoSize -Wrap
                                                    }
                                
                                Else 
                                                    {
                                                        Write-Output ""
                                                        Write-output "To determine Windows update details, please connect to the internet to determine missing updates"
                                                        Write-Output ""
                                                    }

                                Write-output "=======================================" 
                                Write-output "    Memory Details                     " 
                                Write-output "=======================================" 
                                MemDetails
                                Get-CimInstance -Class CIM_PhysicalMemory | Select-Object Tag, capacity, speed, Manufacturer, PartNumber
                                Write-output ""
                                Write-output "Virtual Memory:        $(((Get-computerinfo).OsSizeStoredInPagingFiles / 1000000))GB"
                                Write-Output " " 
                                Write-output "=======================================" 
                                Write-output "    USB Flash Drives                   " 
                                Write-output "=======================================" 
                                    if ($null -eq $(Get-WmiObject win32_diskdrive | Where-Object{$_.interfacetype -eq "USB"}))
                                    
                                            {
                                                ""
                                                Write-output " No USB Flash Drives Attached"
                                                ""
                                            }
                                    else 
                                            {
                                                Get-WmiObject win32_diskdrive | Where-Object{$_.interfacetype -eq "USB"}
                                            }
                                Odo
                                Write-output "=======================================" 
                                Write-output "    BIOS Security Settings             " 
                                Write-output "=======================================" 
                                Write-Output " " 

                                    if ($SVPCheck -eq 1)
                                            {
                                            Write-Output "SVP Password: Set"
                                            }
                                    else
                                            {
                                            Write-Output "SVP Password: NOT Set"
                                            }
                                
                                    if ($LockBIOS -eq "Enabled")
                                            {
                                            Write-Output "BIOS Settings Locked: Yes"
                                            }
                                    else
                                            {
                                            Write-Output "BIOS Settings Locked: No"
                                            }
                                Write-Output "$($SecureBoot)"  
                                Write-Output "$($DMA)"  
                                Write-Output "$($DeviceGuard)"  
                                Write-Output "$($Tamper)"  
                                Write-Output "$($BlockSID)"  
                                Write-Output "$($AMTCONTROL)" 
                                Write-output "$(Get-BiosSettings Security)"
                            }
                            else 
                            {
                               #Write-Host "This System does not have API access to System BIOS." 
                            }

                            Write-Output " " 
                            Write-output "=======================================" 
                            Write-output "     Device Manager Issues             " 
                            Write-output "======================================="
                            DevMan
                            Write-output "=======================================" 
                            Write-output "    Bitlocker Status                   " 
                            Write-output "=======================================" 
                            Write-output $(Get-BitLockerVolume -MountPoint "C:" | format-list) 
                            Write-Output " " 
                            Write-output "=======================================" 
                            Write-output "     Power                             " 
                            Write-output "=======================================" 
                            Write-output ""
                            Write-Output "Power Plan:           $((Get-WmiObject -Class win32_powerplan -Namespace root\cimv2\power).ElementName)"
                            write-Output "Power Slider:         $(Slider -ErrorAction:SilentlyContinue)"  
                            if ($systype -eq 2) 
                                                            {
                                                                            Write-Output "Power Source:         $($juice = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline 
                                                                                                            
                                                                                                                if ($juice -eq $False)
                                                                                                                {
                                                                                                                    #'On battery power'
                                                                                                                    Write-output "Battery" 
                                                                                                                }
                                                                                                        
                                                                                                                if ($juice -eq $True)
                                                                                                                {
                                                                                                                    #'Connected to AC'
                                                                                                                    Write-output "AC Power"
                                                                                                                })"  
                                                                            Write-Output "Power Mgr Dvr:        $((Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"}).DriverVersion)" 
                                                                            Write-Output "Thermal Solution:     $((Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo Intelligent Thermal*"}).DriverVersion)"
                                                                            Write-Output "Fast Startup:         $($FastStartup =(Get-ItemProperty -Path $registryPath -Name $registryName | Select-Object -ExpandProperty "HiberbootEnabled")   

                                                                                                                if ($FastStartup -eq 1)
                                                                                                                {
                                                                                                                    Write-Output "Enabled"
                                                                                                                }
                                                                                                                else {
                                                                                                                    Write-Output "Disabled"
                                                                                                                })"
                                                                            write-output "Smart Standby:        $((Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo Smart Standby*"}).DriverVersion)"
                                                                            $SmartStandbyPath = Test-Path -path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\SmartStandby\'
                                                                            If ($SmartStandbyPath -eq $True)
                                                                            {
                                                                            Write-output "Standby Budget %:     $((Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\SmartStandby\').StandbyBudgetPercent)"
                                                                            }
                                                            }
                            Write-Output "" 
                            Write-Output "=======================================" 
                            Write-output "     Power Timers                      " 
                            Write-Output "=======================================" 
                            <#($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$.SettingType -eq _.SettingType -eq 'AC'}).settingvalue / 60
                            ($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60
                            ($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60
                            ($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_'AC'}).settingvalue / 60#>
                            #Sleep, Hibernation, Screen Off Timers
                                            $PowerPlanObj = [PSCustomObject]@{
                                                InstanceId = $null
                                                ElementName = $null
                                                Settings =  New-Object System.Collections.Generic.List[PSObject]  
                                            }

                                            try {
                                                # Get the Active Power Plan
                                                $ActivePlan = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_Powerplan where IsActive=True" -ErrorAction Stop
                                                #write-output ("Active Plan: " + $ActivePlan.InstanceId + " - " + $ActivePlan.ElementName)    
                                                # Set the Active Plan info in the object
                                                $PowerPlanObj.InstanceId = $ActivePlan.InstanceId
                                                $PowerPlanObj.ElementName = $ActivePlan.ElementName
                                            } catch {
                                                write-host "Error Querying root\cimv2\power Win32_Powerplan - make sure you have an elevated window"
                                                write-output $_.ToString()
                                                exit
                                            }

                                            # Get the readable names for the settings
                                            try {
                                                $SettingNames = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_PowerSetting" -ErrorAction Stop
                                            } catch {
                                                write-host "Error Querying root\cimv2\power Win32_PowerSetting"
                                                write-host $_.ToString()
                                                exit
                                            }
                                            # Loop through the setting names and add them to a hashtable by setting id (use this to get the friendly name)
                                            $SettingHash = @{}
                                            foreach ($i in $SettingNames) {
                                                # Turn this Microsoft:PowerSetting\{29f6c1db-86da-48c5-9fdb-f2b67b1f44da} 
                                                # into {29f6c1db-86da-48c5-9fdb-f2b67b1f44da} for the key
                                                $SettingId = $i.InstanceId.Split("\")[-1]
                                                # Add it to the hash
                                                $SettingHash.Add($SettingId,$i)
                                                # Example: $i.ElementName = Sleep after
                                            }

                                            # Change Microsoft:PowerPlan\{381b4222-f694-41f0-9685-ff5bb260df2e} 
                                            # to 381b4222-f694-41f0-9685-ff5bb260df2e for the query
                                            $ActivePlanId = $PowerPlanObj.InstanceId.Split("\")[-1].Replace("{","").Replace("}","")
                                            try {
                                                $Settings = Get-WmiObject -Namespace "root\cimv2\power" -Query "select InstanceId,SettingIndexValue from Win32_PowerSettingDataIndex Where InstanceId Like '%$ActivePlanId%'" -ErrorAction Stop
                                            } catch {
                                                write-host "Error Querying root\cimv2\power Win32_PowerSettingDataIndex"
                                                write-host $_.ToString()
                                                exit
                                            }

                                            foreach ($i in $Settings) {
                                                $SettingObj = [PSCustomObject]@{

                                                    SettingName = $SettingHash.($i.InstanceId.Split("\")[-1]).ElementName
                                                    SettingType = $null
                                                    SettingValue = $i.SettingIndexValue
                                                    
                                                }
                                                # Tag the settings AC or DC
                                                if ($i.InstanceId -match "AC") {
                                                    $SettingObj.SettingType = "AC"
                                                }
                                                if ($i.InstanceId -match "DC") {
                                                    $SettingObj.SettingType = "DC"
                                                }
                                                # Add the setting to the list
                                                $PowerPlanObj.Settings.Add($SettingObj)
                                            }
                            Write-output ""
                            Write-output "Plugged In:"
                            write-output ""               
                            Write-output "`tSleep After                   $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                            Write-output "`tHibernate After:              $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                            Write-output "`tTurn off display after:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Turn off display after'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue / 60) mins"
                            Write-output "`tDisplay Brightness:           $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Display brightness'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                            Write-output "`tPower Button Action:          $(PowerButtonActionAC)"
                                        if ($systype -eq 2) 

                                                        {
                                                            Write-output "`tCritical Battery Level:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery level'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                                                            Write-output "`tCritical Battery Action:      $(CriticalBatteryActionAC)"
                                                            Write-output "`tLid Close Action:             $(LidCloseAC)"
                                                            write-output ""  
                                                        }

                                        if ($systype -eq 2) 

                                                        {                      
                                                            Write-output "On Battery"
                                                            write-output ""
                                                            Write-output "`tSleep After:                  $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Sleep after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins" 
                                                            Write-output "`tHibernate After:              $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Hibernate after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins" 
                                                            Write-output "`tTurn off display after:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Turn off display after'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue / 60) mins"
                                                            Write-output "`tDisplay Brightness:           $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Display brightness'} | Where-Object{$_.SettingType -eq 'DC'}).settingvalue) %"
                                                            Write-output "`tPower Button Action:          $(PowerButtonActionDC)"
                                                            Write-output "`tCritical Battery Level:       $(($PowerPlanObj.Settings | Where-Object{$_.SettingName -eq 'Critical battery level'} | Where-Object{$_.SettingType -eq 'AC'}).settingvalue) %"
                                                            Write-output "`tCritical Battery Action:      $(CriticalBatteryActionDC)"
                                                            Write-output "`tLid Close Action:             $(LidCloseDC)"
                                                            write-output ""
                                                        }
                            Write-Output "=======================================" 
                            Write-output "     Sleep States                      " 
                            Write-Output "=======================================" 
                            Write-Output " " 
                            Powercfg -a

                            Write-Output "=======================================" 
                            Write-output "     Productivity Software             " 
                            Write-Output "=======================================" 
                            Write-Output " " 
                            Teams -ErrorAction SilentlyContinue
                            Office
                            ZoomChk
                            Write-Output " " 



                            #QuickData AntiVirus and Firewall

                            Write-Output "=======================================" 
                            Write-output "     AntiVirus                         " 
                            Write-Output "=======================================" 
                            Write-Output " " 
                            $AntiVirus  
                            Write-Output " " 
                            Write-Output "=======================================" 
                            Write-output "     Firewall                          " 
                            Write-Output "=======================================" 
                            Write-Output " "
                            $Firewall 
                            Write-Output " " 
                    
                            #QuickData Battery
                            if ($systype -eq 2)
                                            {
                                                Write-Output "======================================="
                                                Write-output "     Battery Data                      " 
                                                Write-Output "=======================================" 
                                                write-Output "Name:                         $((Get-WmiObject Win32_PortableBattery).DeviceID)"   
                                                Write-Output "Manufacturer:                 $manufacturer"
                                                $BatteryDataPath = Test-path -path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\PWRMGRV\ConfKeys\Data\Battery1'

                                                If ($BatteryDataPath -eq $True)
                                                {
                                                BattFW
                                                }   
                                                Write-Output "FRU Model:                    $BatteryPN"
                                                If ($BatteryDataPath -eq $True)
                                                {
                                                Write-output "Barcode Number:               $((Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\PWRMGRV\ConfKeys\Data\Battery1')."Barcode Number")"
                                                }
                                                Write-Output "Plugged in:                   $pluggedIn"
                                                Write-Output "Discharging:                  $discharging"
                                                Write-Output "Charging                      $charging"
                                                Write-Output "Remaining Charge:             $(ChargePercent -ErrorAction:SilentlyContinue)%"
                                                Write-Output "Cycle Count:                  $cycleCount"
                                                Write-Output "Design Capacity:              $designCap mWh"
                                                Write-Output "Last Full Charge Capacity:    $LastChargedCap mWh"
                                                Write-Output "Battery Health:               $health%"
                                                Write-Output "" 
                                            }
                            #QuickData Wi-Fi

                            Write-Output "======================================="
                            Write-output "    Wi-Fi Data                         " 
                            Write-Output "=======================================" 
                            (write-output $(Get-WmiObject Win32_PnPSignedDriver | select-object DeviceName, DriverProviderName, DriverVersion | Where-Object{($_.DeviceName -like '*Wi-Fi*' -and $_.DriverProviderName -notlike '*Microsoft*')}))
                            Write-output ""
                            write-output "WLAN AutoConfig is set to $((sc.exe qc "wlansvc" | Select-String "START_TYPE" | ForEach-Object { ($_ -replace '\s+', ' ').trim().Split(" ") | Select-Object -Last 1 }))"
                            Write-Output " " 

                            #QuickData NetWork Adapters

                            Write-Output "======================================="
                            Write-output "    Network Adapters                   " 
                            Write-Output "=======================================" 
                            (write-output $(Get-NetAdapter | Select-Object InterfaceDescription, DriverVersion | format-table -AutoSize -Wrap) )

                            #QuickData BIOMETRIC
                            if ($True -eq (Get-WmiObject Win32_PnPSignedDriver | select-object DeviceName, DeviceClass, DriverVersion | Where-Object{($_.DeviceClass -like '*Biometric*')}))

                                        {
                                                Write-Output "======================================="
                                                Write-output "    Biometric                          " 
                                                Write-Output "=======================================" 
                                                write-output  (Get-WmiObject Win32_PnPSignedDriver | select-object DeviceName, DeviceClass, DriverVersion | Where-Object{($_.DeviceClass -like '*Biometric*')}) 
                                                Write-Output " " 
                                        }
                            else        
                                        {
                                            Write-Output "======================================="
                                            Write-output "    Biometric                          " 
                                            Write-Output "=======================================" 
                                            Write-Output "No Biometric devices detected." 
                                        }
                            #QuickData Audio Devices

                            Write-Output "======================================="
                            Write-output "    Audio Devices                      " 
                            Write-Output "=======================================" 
                            write-output $(Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{$_.DeviceName -match 'Audio'} | Format-table -AutoSize)
                            Write-output ""

                            #QuickData Camera
                            if (Get-WmiObject Win32_PnPEntity | Where-Object {$_.PnpClass -match 'Camera'})
                                            {
                                                    Write-Output "======================================="
                                                    Write-output "    Camera Information                 " 
                                                    Write-Output "=======================================" 
                                                    Write-output "Physical Cameras:"
                                                    $PhysicalCam = Get-WmiObject Win32_PnPEntity | Where-Object {$_.PnpClass -match 'Camera'} | Select-Object PNPClass, Caption, Description, Status, manufacturer | Format-Table
                                                    $CamDriver = (Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{$_.DeviceName -like '*Camera*'}).DriverVersion
                                                    $CamStruct = (Get-WmiObject Win32_PnPEntity | Where-Object {$_.caption -match 'Camera'} | Select-Object PNPClass, Caption, Description, Status, manufacturer | Format-Table)
                                                    write-output "`t"$($PhysicalCam)
                                                    write-output ""
                                                    write-output "`t"$($CamStruct)
                                                    write-output ""
                                                    Write-output "Integrated Camera Driver: $($CamDriver)"
                                                    Write-Output " " 
                                                                    if (pnputil /enum-drivers | Select-String "lnvvsndmft" -Context 5)
                                                                            {
                                                                            Write-output "**********Lenovo View Extension*************" 
                                                                            Write-output "$(pnputil /enum-drivers | Select-String "lnvvsndmft" -Context 5)"
                                                                            }

                                                                    else    
                                                                            {
                                                                            Write-output ""
                                                                            Write-output "Lenovo View Extension Driver not installed"
                                                                            }
                                                    Write-output ""
                                            }
                            #QuickData Bluetooth

                            Write-Output "======================================="
                            Write-output "    Bluetooth Information              " 
                            Write-Output "=======================================" 
                            $BTDevice = (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Bluetooth(R)*'}).Description
                            $BTDriver = (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Bluetooth(R)*'}).DriverVersion
                            Write-output "Device: $($BTDevice)"
                            Write-output "Driver: $($BTDriver)"
                            Write-output ""
                            Write-output " Bluetooth Devices"
                            (write-output  $(Get-PnpDevice | Where-Object {$_.Class -eq "Bluetooth"} | Format-Table -AutoSize -Wrap) )
                            Write-output ""

                            #QuickData Video Card

                            Write-Output "======================================="
                            Write-output "    Video Card                         " 
                            Write-Output "=======================================" 
                            (Get-WmiObject win32_videocontroller | Select-object Description, DriverVersion, DriverDate, InfFilename, InfSection, MaxRefreshrate, MinRefreshrate, PNPdeviceID, VideoModeDescription | Format-list)
                            <#$VideoCard = (Get-WmiObject Win32_PnPSignedDriver | Where-Object{($_.DeviceClass -like '*Display*')})
                            $VideoController = (Get-WmiObject win32_videocontroller)
                            $VideoDevice = (Get-WmiObject win32_videocontroller).DeviceName

                            ForEach-Object {$VideoDevice}       { 
                                                                    Write-Output "Device:                   $($VideoCard.DeviceName)"
                                                                    write-output "DriverVersion:            $($VideoCard.DriverVersion)"
                                                                    write-output "DriverDate:               $($VideoController.DriverDate)"
                                                                    write-output "DriverOEMINF:             $($VideoController.InfFilename)"
                                                                    Write-Output "CurrentRefreshRate:       $($VideoController.currentrefreshrate)"
                                                                    Write-Output "MaxRefreshRate:           $($VideoController.maxrefreshrate)"
                                                                    Write-Output "MinRefreshRate:           $($VideoController.minrefreshrate)"
                                                                    Write-output "CurrentResolution:        $($VideoController.CurrentHorizontalresolution)x$($VideoController.CurrentVerticalresolution)"
                                                                    Write-output "PNPDeviceID:              $($VideoController.PNPDeviceID)"
                                                                    Write-Output " " 
                                                                } #>  
                            #QuickData Attached Displays

                            Write-Output "======================================="
                            Write-output "    Attached Displays                  " 
                            Write-Output "======================================="
                            Dxdiag /t C:\temp\Dxdiag.log
                            start-sleep 60
                            Get-content "C:\temp\Dxdiag.log"  | select-string 'Monitor Name' 
                            Get-Content "C:\temp\Dxdiag.log"  | select-string 'Monitor Model'
                            start-sleep 10
                            Remove-item C:\temp\Dxdiag.log
                            write-output  $(Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams | select-object InstanceName, Active, MaxHorizontalImageSize, MaxVerticalImageSize, VideoInputType | Format-Table) 
                            Write-Output (Get-PnpDevice -Class Monitor | where-object {$_.status -eq "ok"} | Get-PnpDeviceProperty -KeyName "DEVPKEY_Device_DeviceDesc"| select-object Data,InstanceId) | format-table -autosize -wrap
                            Write-Output " " 
                            Write-Output "Video Input Type 1 = Digital, 0 = Analog" 
                            Write-Output " " 
                            Write-Output "Video Connection Types" 
                            write-output  $(get-ciminstance -namespace root/wmi -classname WmiMonitorConnectionParams | select-object InstanceName, Active, VideoOutputTechnology | Format-Table) 
                            Write-Output " " 
                            Write-Output "Type 4 = DVI, Type 5 = HDMI, Type 10 = DP External, 2147483648 = Native Display " 
                            Write-Output " " 
                            #Write-output "Display Brightness:       $((Get-Ciminstance -Namespace root/WMI -ClassName WmiMonitorBrightness).CurrentBrightness)"
                            Write-Output "Screen Saver TimeOut:             $((Get-WmiObject Win32_Desktop -EA STOP).screensavertimeout)"
                            Scale
                            Write-output "Current Refresh Rate:             $Refresh"
                            Write-output ""

                            #QuickData Smart Cards

                            if ($true -eq (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*SMART CARD*'}))
                                            {
                                                    Write-Output "=======================================" 
                                                    Write-output "    Smart Card                         " 
                                                    Write-Output "=======================================" 
                                                    $(Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*SMART CARD*'} | Select-object DeviceName, DriverVersion | format-table) 
                                                    Write-Output " " 
                                            }
                            else            
                                            {
                                                    Write-Output "=======================================" 
                                                    Write-output "    Smart Card                         " 
                                                    Write-Output "=======================================" 
                                                    write-output "No smart card devices are detected."
                                                    Write-Output " " 
                                            }
                            #QuickData TrackPoint

                            if($True -eq (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*TrackPoint*'} ))
                                            {
                                                    Write-Output "=======================================" 
                                                    Write-output "    TrackPoint                         " 
                                                    Write-Output "=======================================" 
                                                    Write-output  $(Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*TrackPoint*'} | Select-object DeviceName, DriverVersion | format-table) 
                                                    Write-Output " " 
                                            }

                            else            {
                                
                                                    Write-Output "=======================================" 
                                                    Write-output "    TrackPoint                         " 
                                                    Write-Output "=======================================" 
                                                    write-output "No track point devices are detected."
                                                    Write-Output " " 
                                            }                 
                            #QuickData Mouse
                                            
                            if ($True -eq (Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Mouse*'}))
                                            {
                                                    Write-Output "=======================================" 
                                                    Write-output "    Mouse                              " 
                                                    Write-Output "=======================================" 
                                                    Write-output  $(Get-WmiObject Win32_PnPSignedDriver | Where-Object {$_.DeviceName -like '*Mouse*'} | Select-object DeviceName, DriverVersion | format-table) 
                                                    Write-Output " " 
                                            }
                                
                            else            {

                                                    Write-Output "=======================================" 
                                                    Write-output "    Mouse                              " 
                                                    Write-Output "=======================================" 
                                                    Write-Output "no mice detected"
                                                    Write-Output " "  
                                            }
                            #QuickData BIOS Settings
                            
                            If ($systype -eq 2)
                                            {
                                                If ($True -eq $(Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}))
                                                    {
                                                        
                                                        


                                                                Write-Output "======================================="
                                                                Write-output "    BIOS Settings                      " 
                                                                Write-Output "=======================================" 
                                                                                        
                                                                #ThinkPad Logic
                                                                                                    
                                                                Get-BiosSettings | ForEach-Object{$_.View()} 
                                                                                                    
                                                                #Get-WmiObject -Namespace root\wmi -Class Lenovo_BiosSetting | Select-object CurrentSetting 
                                                            
                                                                    


                                                    }
                                        
                                            else    {

                                                            Write-Output "======================================="
                                                            Write-output "    BIOS Settings                      " 
                                                            Write-Output "=======================================" 
                                                        
                                                            Write-output "This System does not have an API interface to BIOS settings" 
                                                
                                                    }
                                            }  

                            If ($systype -eq 1)

                                            {
                                                If ($True -eq $(Get-WmiObject -List -Namespace 'root\wmi' | Where-Object { $_.Name -eq 'Lenovo_BIOSSetting'}))
                                                
                                                    {
                                                        Write-Output "======================================="
                                                        Write-output "    BIOS Settings                      " 
                                                        Write-Output "=======================================" 
                                                        $DesktopBIOS = (Get-WmiObject -class Lenovo_BiosSetting -namespace root\wmi | select-object currentsetting | Out-String).Trim()
                                                        $DesktopBIOS
                                                    }
                                                
                                                else 

                                                    {
                                                        Write-Output "======================================="
                                                        Write-output "    BIOS Settings                      " 
                                                        Write-Output "=======================================" 
                                                    
                                                        Write-output "This System does not have an API interface to BIOS settings" 
                                                    }
                                            }

                            #QuickData PS Version Info

                                    Write-output "=======================================" 
                                    Write-output "     MISC Data                         " 
                                    Write-output "=======================================" 
                                    Write-output $PSVersionTable 

                    Start-sleep 5

                }


Function All    {
                    
                    # Case Data Acquistion Tool Version 3.3.0
                    # Please Run in Admin Powershell
                  
                    #Title Logic
                    if ($systype -eq 2)
            
                                {
                                            $ThinkPadBanner = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*"
            
                                            If ($ThinkPadBanner -eq $false)
                                            {
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t      Lenovo Consumer CDAT v$($CDATVer)`n"
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t            $(Get-Date)                `n"
            
                                            }
            
                                            if ($ThinkPadBanner -eq $True)
                                            {
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t      Lenovo ThinkPad CDAT v$($CDATVer)`n"
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t            $(Get-Date)                `n"
                                        
                                            }
                                }
                                
                    else 
                                {
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t      Lenovo DT/WS CDAT v$($CDATVer)   `n"
                                                Write-Host "`n`t`t **************************************`n"
                                                Write-Host "`n`t`t            $(Get-Date)                `n"
                                }
            # Messaging to user the start of the process
            
            write-host "Preparing Environments - please wait..."
            
            
            
            #Preparing directory structure
            
            #Temp Dir Logic
            
            $Tempdir = "C:\temp\"
                    
            If (!(test-path $Tempdir))
            {
                [VOID] (mkdir $Tempdir)
            }
            
            #CDAT Dir Logic
            
            $CDATdir = "C:\temp\CDAT$CDATv\"
            
            If (!(test-path $CDATdir))
            {
                [VOID] (mkdir $CDATdir)
            }
            
            #Nested Dir Logic
            
            $HomeDir = "C:\temp\CDAT$CDATv\"
            
            If (test-path $Homedir)
            {
                [VOID] (mkdir C:\temp\CDAT$CDATv\Mini-dump\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\TPM-Bitlocker\ -Force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Power-Battery\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Windows-Event-Logs\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Audio\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Video-Graphics\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Preload\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Boot\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Network\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Installed-HWD\ -force) 
                [VOID] (mkdir C:\temp\CDAT$CDATv\Windows\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Group-Policy\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Lenovo-Dock\Json\ -force)
                [VOID] (mkdir C:\temp\CDAT$CDATv\Templates\ -force)
            }
            
            
            # Templates file transfer
            
            Copy-Item -Path .\templates\template.html -Destination C:\temp\CDAT$CDATv\Templates\template.html
                                                    
            
                                                if ($systype -eq 2) 
            
                                                                    {  
                                                                            # Odometer Code Section
            
                                                                            <# 
            
                                                                            DISCLAIMER: 
            
                                                                            These sample scripts are not supported under any Lenovo standard support   
                                                                            program or service. The sample scripts are provided AS IS without warranty   
                                                                            of any kind. Lenovo further disclaims all implied warranties including,   
                                                                            without limitation, any implied warranties of merchantability or of fitness for   
                                                                            a particular purpose. The entire risk arising out of the use or performance of   
                                                                            the sample scripts and documentation remains with you. In no event shall   
                                                                            Lenovo, its authors, or anyone else involved in the creation, production, or   
                                                                            delivery of the scripts be liable for any damages whatsoever (including,   
                                                                            without limitation, damages for loss of business profits, business interruption,   
                                                                            loss of business information, or other pecuniary loss) arising out of the use   
                                                                            of or inability to use the sample scripts or documentation, even if Lenovo   
                                                                            has been advised of the possibility of such damages.  
            
                                                                            #> 
            
                                                                            <# 
                                                                            .SYNOPSIS 
                                                                            This script reads the raw SMBIOS table data from WMI and derives the set of 
                                                                            Odometer metrics.  These are then stored in the root\Lenovo:Lenovo_Odometer 
                                                                            class in WMI which can be inventoried more easily. 
            
                                                                            .DESCRIPTION 
                                                                            Odometer data is updated at each reboot. This script can be executed by 
                                                                            scheduled task to run aFormat-lister each boot to collect the current metrics. The
                                                                            Odometer metrics include:
                                                                                - CPU Uptime - amount of time cpu has been active in seconds
                                                                                - Shock events - based on detections from accellarometer
                                                                                - Thermal events - registered high-temp conditions where cpu was throttled
                                                                                - Battery cycles - number of charge cycles performed on battery
                                                                                - SSD Read/Writes - number of reads and writes on one or more internal SSDs
            
                                                                            .NOTES
                                                                            +---------------------------------------------------------------------------------------------+ 
                                                                            |   DATE        : 2020.06.12 
                                                                            |   AUTHOR      : Lenovo Commercial Deployment Readiness Team 
                                                                            |   DESCRIPTION : Version 1.0 
                                                                            +---------------------------------------------------------------------------------------------+ 
            
            
                                                                            #> 
            
                                                                            <# 
                                                                                Create the root\Lenovo:Lenovo_Odometer class in WMI if it doesn't exist 
                                                                            #>
                                                                            function CreateClass {
                                                                                $ns = [wmiclass]'root:__NAMESPACE'
                                                                                $sc = $ns.CreateInstance()
                                                                                $sc.Name = 'Lenovo'
                                                                                $sc.Put()
            
                                                                                $class = New-Object System.Management.ManagementClass ("root\Lenovo", [string]::Empty, $null)
                                                                                $class["__CLASS"] = "Lenovo_Odometer"
                                                                                $class.Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Qualifiers.Add("SMS_Group_Name", "Lenovo_Odometer")
                                                                                $class.Qualifiers.Add("SMS_Class_Id", "Lenovo_Odometer")
            
                                                                                $class.Properties.Add("SystemID", [System.Management.CimType]::String, $false)
                                                                                $class.Properties.Add("CPU_Uptime", [System.Management.CimType]::String, $false)
                                                                                $class.Properties.Add("Shock_events", [System.Management.CimType]::String, $false)
                                                                                $class.Properties.Add("Thermal_events", [System.Management.CimType]::String, $false)
                                                                                $class.Properties.Add("Battery_cycles", [System.Management.CimType]::String, $false)
                                                                                $class.Properties.Add("SSD_Read_Write_count", [System.Management.CimType]::String, $false)
            
                                                                                $class.Properties["SystemID"].Qualifiers.Add("Key", $true)
                                                                                $class.Properties["SystemID"].Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Properties["CPU_Uptime"].Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Properties["Shock_events"].Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Properties["Thermal_events"].Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Properties["Battery_cycles"].Qualifiers.Add("SMS_Report", $true)
                                                                                $class.Properties["SSD_Read_Write_count"].Qualifiers.Add("SMS_Report", $true)
            
                                                                                $class.Put()
                                                                            } 
            
                                                                            <#  Add the current metric values to the :Lenovo_Odometer class  #>
                                                                            function AddValues {
            
                                                                                param (
                                                                                    [parameter (Mandatory=$true, position=0, ParameterSetName='OdValues')]
                                                                                    [string]$system,
                                                                                    [parameter (Mandatory = $true, position = 1, ParameterSetName = 'OdValues')]
                                                                                    [string]$cpu_uptime,
                                                                                    [parameter (Mandatory = $true, position = 2, ParameterSetName = 'OdValues')]
                                                                                    [string]$shock,
                                                                                    [parameter (Mandatory = $true, position = 3, ParameterSetName = 'OdValues')]
                                                                                    [string]$thermal,
                                                                                    [parameter (Mandatory = $true, position = 4, ParameterSetName = 'OdValues')]
                                                                                    [string]$battery,
                                                                                    [parameter (Mandatory = $true, position = 5, ParameterSetName = 'OdValues')]
                                                                                    [string]$ssd
                                                                                )
            
                                                                                    try {
                                                                                        $thissystem = Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -Filter "SystemID = '$system'"
                                                                                        if ($thissystem.SystemID -eq $system) {
                                                                                            $thissystem.CPU_Uptime = $cpu_uptime
                                                                                            $thissystem.Shock_events = $shock
                                                                                            $thissystem.Thermal_events = $thermal
                                                                                            $thissystem.Battery_cycles = $battery
                                                                                            $thissystem.SSD_Read_Write_count = $ssd 
                                                                                            $thissystem.Put()
                                                                                        } else {  
                                                                                            Set-WmiInstance -Path '\\.\root\Lenovo:Lenovo_Odometer' -PutType CreateOnly -Arguments @{SystemID = $system; CPU_Uptime = $cpu_uptime; Shock_events = $shock; Thermal_events = $thermal;  Battery_cycles = $battery; SSD_Read_Write_count = $ssd}               
                                                                                        }
                                                                                    }
                                                                                    catch {
                                                                                        "Did not add: " + $system
                                                                                    }      
                                                                            }
            
                                                                            ## Main ##
            
                                                                                # // Create the Lenovo WMI Namespace // #
                                                                                [void](Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror)
                                                                                
                                                                                if ($wmiclasserror) {
                                                                                    try {
                                                                                        # Write-Output "================================="
                                                                                        # Write-Output "Creating the Lenovo WMI Namespace"
                                                                                        # Write-Output "================================="
                                                                                        CreateClass
                                                                                    }
                                                                                    catch {
                                                                                        Write-Warning -Message "Could not create WMI class" ; Exit 1
                                                                                    }
                                                                                }
                                                                                
                                                                                #Get a system ID made from MTM - Serial#
                                                                                [string]$systemID = (Get-WmiObject -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty Name) + " - " + (Get-WmiObject -Class Win32_ComputerSystemProduct | Select-Object -ExpandProperty IdentifyingNumber)
                                                                                
                                                                                #Get Raw SMBIOS Table data
                                                                                $objWMI = get-wmiobject -namespace root\WMI -computername localhost -Query "Select * from MSSmBios_RawSMBiosTables"
                                                                                
                                                                                foreach ($obj in $objWmi)
                                                                                {
                                                                                    $raw = $obj.SMBiosData
                                                                                }
                                                                                
                                                                                $cpu_uptime = "No CPU Uptime data found."
                                                                                $shock = "No Shock data found."
                                                                                $thermal = "No Thermal data found."
                                                                                $battery = ""
                                                                                $ssd = ""
                                                                                
                                                                                for ($i=0; $i -lt $raw.Count; $i++) {
                                                                                    if ($raw[$i] -eq 141) { 
                                                                                        $sigindex = $i + 4
                                                                                        $sig = [char]$raw[$sigindex] + [char]$raw[($sigindex + 1)] + [char]$raw[($sigindex + 2)] + [char]$raw[($sigindex + 3)]
                                                                                        if ($sig -eq 'THNK') {
                                                                                            #verified Odometer item
                                                                                            
                                                                                            #length of structure
                                                                                            $tablelength = $raw[$i + 1]
                                                                                            
                                                                                            #location of metric identifier
                                                                                            $metricindex = $i + 10
                                                                                            
                                                                                            #start location of data
                                                                                            $datastart = $i + 14
                                                                                
                                                                                            #metric identifier consists of 4 bytes
                                                                                            $metrictype = $raw[$metricindex] + $raw[($metricindex + 1)] + $raw[($metricindex + 2)] + $raw[($metricindex + 3)]
                                                                                
                                                                                            #convert metric identifier to name using combined four bytes using the decimal values from raw table data
                                                                                            # and get data value
                                                                                
                                                                                            ##initialize strings with default values##
                                                                                            [string]$metricname = ""
                                                                                
                                                                                
                                                                                            Switch ($metrictype)
                                                                                            {
                                                                                                0   { 
                                                                                                        $metricname = "CPU Uptime" 
                                                                                                        [array]$data = ($raw[$datastart], $raw[$datastart + 1], $raw[$datastart + 2], $raw[$datastart + 3])
                                                                                                        $cpu_uptime = [bitconverter]::ToInt32($data,0)
                                                                                                    }
                                                                                                16  { 
                                                                                                        $metricname = "Vibration Shock"
                                                                                                        [array]$data = ($raw[$datastart], $raw[$datastart + 1], $raw[$datastart + 2], $raw[$datastart + 3])
                                                                                                        $shock = [bitconverter]::ToInt32($data,0)
                                                                                                    }
                                                                                                48  { 
                                                                                                        $metricname = "Thermal Throttling Events" 
                                                                                                        [array]$data = ($raw[$datastart], $raw[$datastart + 1], $raw[$datastart + 2], $raw[$datastart + 3])
                                                                                                        $thermal = [bitconverter]::ToInt32($data,0)
                                                                                                    }
                                                                                                64  { 
                                                                                                        # Battery Cycles:  some systems may have two batteries
                                                                                                        $metricname = "Battery Cycles" 
                                                                                                        $data = $null
                                                                                                        #determine number of data sets
                                                                                                        [int]$battcount = ($tablelength - 14)/4
                                                                                                        for ([int]$batt=0; $batt -lt $battcount; $batt++) {
                                                                                                            for ([int]$n=0; $n -lt 4; $n++) {
                                                                                                                $data = $data + $raw[$datastart + $n]
                                                                                                            }
                                                                                                            if ($battery -eq "") {
                                                                                                                $battery = "Battery " + $batt + ": " + [bitconverter]::ToInt32($data,0)
                                                                                                            } else {
                                                                                                                $battery += "; Battery " + $batt + ": " + [bitconverter]::ToInt32($data,0)
                                                                                                            }
                                                                                                            $data = $null
                                                                                                            $datastart = $datastart + 4
                                                                                                        }
                                                                                                    }
                                                                                                80  { 
                                                                                                        # SSD Reads/Writes:  covers internal SSD and NVME drives
                                                                                                        $metricname = "SSD Read_Write Counts"
                                                                                                        $data = $null
                                                                                                        #determine number of data sets
                                                                                                        [int]$drivecount = ($tablelength - 14)/16
                                                                                                        for ([int]$drive=0; $drive -lt $drivecount; $drive++) {
                                                                                                            for ([int]$n=0; $n -lt 8; $n++) {
                                                                                                                $data = $data + $raw[$datastart + $n]
                                                                                                            } 
                                                                                                            $read = [bitconverter]::ToInt32($data,0)
                                                                                                            if ($ssd -eq "") {
                                                                                                                $ssd = "Drive " + $drive + ": " + $read
                                                                                                            } else {
                                                                                                                $ssd += "; Drive " + $drive + ": " + $read
                                                                                                            }
                                                                                                            
                                                                                                            $data = $null
                                                                                                            $datastart = $datastart + 8  
                                                                                                            for ($n=0; $n -lt 8; $n++) {
                                                                                                                $data = $data + $raw[$datastart + $n]
                                                                                                            } 
                                                                                                            $write = [bitconverter]::ToInt32($data,0)
                                                                                                            $ssd += "/" + $write
                                                                                                            $datastart = $datastart + 8
                                                                                                            $data = $null
                                                                                                        }
                                                                                                        
                                                                                                    
                                                                                                    }
                                                                                                Default { $metricname = "Unknown Metric" }
                                                                                            }
                                                                                
                                                                                        }
                                                                                    }
                                                                                }
                                                                                if ($battery -eq "") {
                                                                                    $battery = "No battery data found"
                                                                                    }
                                                                                if ($ssd -eq "") {
                                                                                    $ssd = "No SSD data found"
                                                                                    }
                                                                                
                                                                                [void] (AddValues $systemID $cpu_uptime $shock $thermal $battery $ssd)
                                                                    }
            
            
                                                    if ($systype -eq 2) 
            
            
                                                                    {                #Battery AC determination
            
                                                                                    $juice = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline
            
                                                                                                                if ($juice -eq $false)
                                                                                                                {
                                                                                                                    #'On battery power'
                                                                                                                    #Write-output "Battery" 
                                                                                                                }
            
                                                                                                                if ($juice -eq $True)
                                                                                                                {
                                                                                                                    #'Connected to AC'
                                                                                                                    #Write-output "AC Power"
                                                                                                                }
                                                                    
                                                                                #Quick Battery Data
            
                                                                                [CmdletBinding()]
            
                                                                                $Batteries = @() + (get-wmiobject -namespace root\wmi batteryStaticData)
                                                                                                        if ($Batteries.Active -eq $false) 
                                                                                                                                {
                                                                                                                                    Write-Output "No batteries detected on this device."
                                                                                                                                }
                                                                                                                                
                                                                                                        else    {
                                                                                                                            # $chargedCapacities = @() + (Get-WmiObject -Namespace 'ROOT\WMI' BatteryFullChargedCapacity)
                                                                                                                            # $statuses = @() + (Get-WmiObject -Namespace 'ROOT\WMI' BatteryStatus)
                                                                                                                            # $cycles = @() + (Get-WmiObject -Namespace 'ROOT\WMI' BatteryCycleCount)
            
                                                                                                                            for ($i = 0; $i -lt $Batteries.Count; ++$i)
                                                                                                                                            {
                                                                                                                                                $battery = $Batteries[$i]
                                                                                                                                                #$chargeCapacity = $chargedCapacities[$i]
                                                                                                                                                #$status = $statuses[$i]
                                                                                                                                                #$cycle = $cycles[$i]
            
                                                                                                                                                #$manufacturer = (get-wmiobject -namespace root\wmi Batterystaticdata).ManufactureName
                                                                                                                                                #$model = (get-wmiobject -namespace root\wmi Batterystaticdata).DeviceName
                                                                                                                                                #$pluggedIn = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline
                                                                                                                                                #$charging = (get-wmiobject -namespace root\wmi batterystatus).Charging
                                                                                                                                                #$discharging = (get-wmiobject -namespace root\wmi batterystatus).Discharging
                                                                                                                                                $designCap = (get-wmiobject -namespace root\wmi batteryStaticData).DesignedCapacity
                                                                                                                                                $lastChargeCap = (get-wmiobject -namespace root\wmi batteryFullChargedCapacity).FullChargedCapacity
                                                                                                                                                #$remainingCap = (get-wmiobject -namespace root\wmi batterystatus).RemainingCapacity
                                                                                                                                                #$cycleCount = (get-wmiobject -namespace root\wmi batteryCycleCount).CycleCount
            
            
                                                                                                                                                #Some Lenovo Batteries report Design Cap as 0, so to compensate...
                                                                                                                                                        if ($designCap -eq 0)
                                                                                                                                                        {$health = ""}
                                                                                                                                                        else{
                                                                                                                                                        $health = [int](($lastChargeCap * 100) / $designCap)    # Percentage   
                                                                                                                                                        }
            
                                                                                                                                            }
            
                                                                                                                }
                                                                    }
            
                                                                    
            
            #QDTS Case Number variable set
            
                        #$QDTS = -Prompt "Case Number:"
            
                            #$QDTS = Read-Host -Prompt "QDTS Case # (if unavialble press ENTER)"
            
            #Gathering Quick Data, Potential Issues.
                         
                        Write-output "Gathering system data, this may take several minutes..."
                        QuickData > C:\temp\CDAT$CDATv\CDAT$CDATv-QuickData-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log
                        Write-output "Gathering data on potential issues on your system, please wait..."
                        KnownIssues > C:\temp\CDAT$CDATv\CDAT$CDATv-Issues-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                        Write-output "System Data capture is complete."

            #Gathering AMT VPro Information
            
            If ($ProcDetect -eq "GenuineIntel")
            
                        {
                            If ((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*")
                                
                                {
                                    
                                    Intel_VPro
                                
                                }
            
                            else 
                                {
                                    
                                
                                }
                            
                        }   
            
            #Begin Transcript of on screen actions
            
                    [VOID] (Start-Transcript -path "C:\temp\CDAT$CDATv\CDAT$CDATv-Transcript-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log")
            
            #Capturing system information
            
                    Write-output "Creating - MSINFO32 Log, please wait..."
                    [void] (msinfo32 /nfo C:\temp\CDAT$CDATv\Installed-HWD\MSInfo32.NFO)
                    start-sleep 30
                    #[Void] (msinfo32 /report C:\temp\CDAT$CDATv\Installed-HWD\MSINFO32Report.txt)
                    #start-sleep 10
            
            # Grabbing Intel ME FW dependent on WMI interface SW Install
            
                    If ($ProcDetect -eq "AuthenticAMD")
            
                            {
                                If ((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*")
                                    
                                    {
                                        
                                        AMD_DASH
                                    
                                    }
                                
                                else 
                                    
                                    {
                                    <# Action when all if and elseif conditions are false #>
                                    }
                                
            
                            }
            
                    If ($ProcDetect -eq "GenuineIntel")
            
                            {
                                If ((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*")
                                    
                                    {
                                        
                                        Intel_ME
                                    
                                    }
            
                                else 
                                    {
                                        
                                    
                                    }
                                
                            }
            
            #Gathering Video Card and Display Information
            
                    Write-Output "Creating - Video Card Adapter Log"
                    Get-WmiObject Win32_VideoController | select-object VideoProcessor, Description, DriverVersion, DriverDate, VideoModeDescription  > C:\temp\CDAT$CDATv\Video-Graphics\VideoCardInfo.log
                    Get-WmiObject Win32_VideoController >> C:\temp\CDAT$CDATv\Video-Graphics\VideoCardInfo.log
                    Write-output "Creating - Attached Display List"
                    Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams > C:\temp\CDAT$CDATv\Video-Graphics\AttachedDisplayList.log
                    Write-output "Creating - DXDiag Log, please wait..."
                    Dxdiag /t C:\temp\CDAT$CDATv\Video-Graphics\Dxdiag.log
            
            #Gathering Display Signal Compression Data

                    ./templates/DSC_Control_v4.1.exe Q > C:\temp\CDAT$CDATv\Video-Graphics\DSC.Log
                    #DSC -ErrorAction SilentlyContinue > C:\temp\CDAT$CDATv\Video-Graphics\DSC.log

            #Gathering VMM Data for Docks and Displays

                  <#  Write-Output "Creating - additonal dock and display information"
                    If ($null -eq $(DockDetect))
                    {
                   
                    }

                    else 
                    {
                        ./templates/VMM/vmm_casecade.cmd 
                    } #>
            
            #Gathering Disk Drive Information
            
                    Write-Output "Creating - Disk info Log"
                    Get-Disk | Format-Table -AutoSize > C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
                    Get-Partition -DiskNumber 0 >> C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
                    (Get-Disk | Get-StorageReliabilityCounter | Select-Object -Property "*") >> C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
                    fsutil fsinfo statistics C: >> C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
                    fsutil fsinfo sectorinfo C: >> C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
                    fsutil fsinfo ntfsInfo C: >> C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
            
                    # Get-PhysicalDisk | Get-StorageFirmwareInformation >>  C:\temp\CDAT$CDATv\Installed-HWD\DiskInfo.log
            
            
            # Grabbing RAMM Info
            
                    Write-Output "Creating - RAMM Module Log"
                    Get-CimInstance -Class CIM_PhysicalMemory | Select-Object Tag, capacity, speed, Manufacturer, PartNumber > C:\temp\CDAT$CDATv\Installed-HWD\InstalledRamm.log
                    Get-WmiObject win32_physicalmemory | Format-Table Manufacturer,Banklabel,Configuredclockspeed,Devicelocator,Capacity,Serialnumber -autosize >> C:\temp\CDAT$CDATv\Installed-HWD\InstalledRamm.log
            
            # AC and Power Status
            if ($systype -eq 2) 
                                {
                                            
                                            Write-Output "Creating - AC Status Log"
                                            $battery = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline
                                            
                                            if ($battery -eq $False)
                                            {
                                                    #'On battery power'
                                                    Write-output "Creating - ACandPowerStatus.log"
                                                    Write-output "=======================================" > C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powered by AC or Battery"                >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "=======================================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "This system is running on Battery Power" >>  C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powercfg Sleep Data       " >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -a >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "PowerManager Driver Values" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powercfg Timers and Values" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -qh >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "PowerPlan Scheme          " >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -L >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log

                                                    
                                            }
            
                                            else
                                            {
                                                    #'Connected to AC'
                                                    Write-output "Creating - ACandPowerStatus.log"
                                                    Write-output "=======================================" > C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powered by AC or Battery"                >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "=======================================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "This system is running on AC Power" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powercfg Sleep Data       " >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -a >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "PowerManager Driver Values" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "Powercfg Timers and Values" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -qh >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "PowerPlan Scheme          " >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    Write-output "==========================" >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
                                                    powercfg -L >> C:\temp\CDAT$CDATv\Power-Battery\ACandPowerStatus.log
            
                                            }
            
                                }
            # Creating Computer Info Log
            
                        Write-output "Creating - Computer Info Log"
                        [Void] (Get-ComputerInfo > C:\temp\CDAT$CDATv\CDAT$CDATv-ComputerInfo-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)
            
            # Creating Installed HWD List
            
                        Write-output "Creating - Installed Hardware List"
                        Get-PnpDevice | Select-Object Status,FriendlyName, InstanceID | format-table -wrap > C:\temp\CDAT$CDATv\Installed-HWD\InstalledHardwareList.log
            
            # Creating Hidden and Previously Installed Device List
            
                        Write-output "Creating - Hidden & Previous Installed USB Devices Log"
                        # Get-PnpDevice | sort-object -property name | where-object -property Status -eq unknown | Select-Object Status, FriendlyName, InstanceID > C:\temp\CDAT$CDATv\Installed-HWD\HiddenAndPreviouslyInstalledUSBDevice.log
                        Get-PnpDevice | sort-object -property name | where-object -property Status -eq unknown | Select-Object Status, FriendlyName, InstanceID |format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\HiddenAndPreviouslyInstalledUSBDevice.log" -width 300
            
            # Creating Computer Network Device Logs
            
                        Write-output "Creating - Computer Network Device Logs"
                        [VOID] (Get-NetAdapter > C:\temp\CDAT$CDATv\Network\NetworkInterfaces.log)
                        [VOID] (Get-NetAdapterHardwareInfo >> C:\temp\CDAT$CDATv\Network\NetworkInterfaces.log)
                        Write-output "Creating - Computer Network Device Bindings Log"
                        [VOID] (Get-NetAdapterBinding > C:\temp\CDAT$CDATv\Network\NetworkInterfacesBindings.log)
                        Write-output "Creating - Computer Network Device Advanced Properties Log"
                        [VOID] (Get-NetAdapterAdvancedProperty | format-table -autosize -wrap >> C:\temp\CDAT$CDATv\Network\NetworkInterfaces.log)
                        Write-output "Creating - Computer Network Device Power Management Logs"
                        [VOID] (Get-NetAdapterPowerManagement >> C:\temp\CDAT$CDATv\Network\NetworkAdapterPowerManagement.log)
                        if (Test-Connection google.com -Quiet) 
                            {
                                Write-Output "Creating - MISC Network Connective Test Data"
                                [VOID] (Get-NetRoute > C:\temp\CDAT$CDATv\Network\NetRoute.log)
                                [VOID] (Get-NetIPAddress > C:\temp\CDAT$CDATv\Network\NetIPAddressIPConfig.log)
                                [VOID] (Test-NetConnection > C:\temp\CDAT$CDATv\Network\PingTestDefaultGateway.log)
                                [VOID] (Test-NetConnection -TraceRoute > C:\temp\CDAT$CDATv\Network\TraceRoute.log)
                            } 
                        
                        else
                            {
                                Write-Host "No Internet Connection Available"
                            }
                            
                        Write-output "Creating - Bluetooh System Log"
                        (BT > C:\temp\CDAT$CDATv\Network\BluetoothSystemReport.log)
            
            # Creating WWAN Information Log
            
                        Write-output "Creating - WWAN Information Logs"
                        [VOID] (netsh mbn show interfaces > C:\temp\CDAT$CDATv\Network\WWAN.log)
            
            # Creating WLAN Information Log
                
                        Write-output "Creating - WLAN Information Log"
                        [VOID] (netsh wlan show all > C:\temp\CDAT$CDATv\Network\WLANnetsh.log)
            
            #Creating WLAN Report
            
                        Write-output "Creating - WLAN Report Log"
                        [void] (netsh wlan show wlanreport duration="45")
                        Copy-Item -Path "$($env:ProgramData)\Microsoft\Windows\WlanReport\wlan-report-latest.html" -Destination C:\temp\CDAT$CDATv\Network\ -ErrorAction Ignore
            
            # Creating Wi-FI Encryption Types
            
                        Write-output "Creating - Wi-Fi Encryption Types"
                        [VOID] (netsh wlan show networks mode=BSSID > C:\temp\CDAT$CDATv\Network\Network_WiFi_encryption_details.log)
            
            # Creating EDID Values Log
            
                        Write-output "Creating - Display EDID Information from the Registry"
                        [void] (reg export "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\DISPLAY" C:\temp\CDAT$CDATv\Installed-HWD\AttachedDisplayEDID.log /y)
            
            # Creating SMBIOS Info Log
            
                        Write-output "Creating - SMBIOS Information"
                        Get-CimInstance -NameSpace root/WMI -ClassName MSSmBios_RawSMBiosTables -ErrorAction SilentlyContinue `
                        | Export-Clixml -Path "C:\temp\CDAT$CDATv\Installed-HWD\smbios-table-cli.xml"
                
            #Gathering PID VID Data
            
                        Write-output "Creating - VID/PID Data"
                        Get-WmiObject Win32_USBControllerDevice |ForEach-Object{[wmi]($_.Dependent)} |Sort-object Description,DeviceID | format-table Description,DeviceID -autosize -wrap > C:\temp\CDAT$CDATv\Installed-HWD\PIDVID.log
            
            # Gather Windows Data
            
                        # Gathering Registry Info
            
                            Write-output "Creating - Windows Registry Data, please wait..."
                            (reg.exe export HKLM\SYSTEM\CurrentControlSet HKLMSYSTEMCurrentControlSetreg.log)
                            
                            start-sleep 10
            
                            (reg.exe export HKLM\HARDWARE HKLMHARDWAREreg.log)
            
                            [Void] (copy-item HKLMSYSTEMCurrentControlSetreg.log C:\temp\CDAT$CDATv\Installed-HWD\HKLMSYSTEMCurrentControlSetreg.log)
                            [Void] (copy-item HKLMSYSTEMCurrentControlSetreg.log C:\temp\CDAT$CDATv\Installed-HWD\HKLMHARDWAREreg.log)
                            
                            start-sleep 10
            
                            [Void] (remove-item HKLMSYSTEMCurrentControlSetreg.log)
                            [Void] (remove-item HKLMHARDWAREreg.log)
            
                        # Windows Environment Variables
            
                                Write-Output "Creating - Windows Env Variables Log"
                                Get-ChildItem env: | Select-Object -Property @("Key", "Value") | Out-file "C:\temp\CDAT330\Windows\WindowsEnvVar.log"
            
                                Write-output "Creating - Windows Apps Installed Information Log"
                                Get-AppxPackage -AllUsers | Select-object Name, PackageFullName | Format-table -autosize -wrap > C:\temp\CDAT$CDATv\Windows\WindowsInstalledApps.log
                                
                                Write-output "Creating - Windows 3rd Party Applicaton Log"
                                get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*| Select-Object displayname, InstallDate, DisplayVersion > C:\temp\CDAT$CDATv\Windows\3rdPartyInstalledApps.log
            
                                Get-Package | sort-object Name | format-table -wrap -autosize > C:\temp\CDAT$CDATv\Windows\AllInstalledPrograms.log
                                Get-WmiObject -Class Win32_InstalledWin32Program | select-object name, version | format-table -autosize -wrap >> C:\temp\CDAT$CDATv\Windows\AllInstalledPrograms.log
                                
                                Write-output "Creating - Windows Process Log"
                                Get-Process | Format-List * > C:\temp\CDAT$CDATv\Windows\WindowsProcessLog.log
                                
                                Write-output "Creating - Windows Startup Items"  
                                Get-CimInstance Win32_StartupCommand | Select-Object Name, Location, User | Format-table -autosize -Wrap > C:\temp\CDAT$CDATv\Windows\WindowsStartup.log
            
                                Write-output "Creating - Windows Scheduled Tasks"
                                Get-ScheduledTask | format-table -autosize -wrap > C:\temp\CDAT$CDATv\Windows\ScheduledTasks.log
                                
                                Write-output "Creating - Windows Services Features Log"
                                get-windowsoptionalfeature -online | format-table > C:\temp\CDAT$CDATv\Windows\WindowsFeatures.txt
                                
                                Write-output "Creating - Windows Optional Service Features Log"
                                Get-WmiObject Win32_OptionalFeature > C:\temp\CDAT$CDATv\Windows\WindowsOptionalFeatures.txt
            
                                Write-output "Creating - Windows Hot Fix Installed KB Log"
                                Get-HotFix | format-table -autosize -wrap >C:\temp\CDAT$CDATv\Windows\Hotfix.log
            
                                Write-output "Creating - Windows Services Log"
                                Get-Service | format-table -autosize -wrap > C:\temp\CDAT$CDATv\Windows\WIndowsServices.log
            
                                Write-output "Creating - Windows Event Logs, please wait..."
                        
                        # Config Application Event Log
                                Write-output "- Harvesting application event log files."
                                $logFileName = "Application" # Add Name of the Logfile (System, Application, etc)
                                $path = "C:\temp\" # Add Path, needs to end with a backslash
                                $exportFileName = "CollectionData_WindowsEventLogs_" + $logFileName + (get-date -f MMddyyyy) + ".evt"
                                Write-debug "Application Event Log - Operation did not complete"
                                $logFile = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName}
                                Write-debug "Application Event Log - Operation did not complete"
                                [void] ($logFile.backupeventlog($path + $exportFileName))
                                Write-debug "Application Event Log - Operation did not complete"
                                Write-output "- Preparing application event log files."
                                start-sleep 10
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_Application* C:\temp\CDAT$CDATv\Windows-Event-Logs\
                                Write-output "- Application Event Log harvest complete."
                                
                        # Config System Event Log
                                Write-output "- Harvesting system event log files."
                                $logFileName1 = "System" # Add Name of the Logfile (System, Application, etc)
                                $path1 = "C:\temp\" # Add Path, needs to end with a backslash 
                                $exportFileName1 = "CollectionData_WindowsEventLogs_" + $logFileName1 + (get-date -f MMddyyyy) + ".evt"
                                Write-debug "System Event Log - Operation did not complete"
                                $logFile1 = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName1}
                                Write-debug "System Event Log - Operation did not complete"
                                [void] ($logFile1.backupeventlog($path1 + $exportFileName1))
                                Write-debug "System Event Log - Operation did not complete"
                                Write-output "- Preparing system event log files."
                                start-sleep 10
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_System* C:\temp\CDAT$CDATv\Windows-Event-Logs\
                                Write-output "- System Event Log harvest complete."
                
                        # Config Security Event Log
                                Write-output "- Harvesting security event log files."
                                $logFileName2 = "Security" # Add Name of the Logfile (System, Application, etc)
                                $path2 = "C:\temp\" # Add Path, needs to end with a backslash
                                $exportFileName2 = "CollectionData_WindowsEventLogs_" + $logFileName2 + (get-date -f MMddyyyy) + ".evt"
                                Write-debug "Security Event Log - Operation did not complete"
                                $logFile2 = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName2}
                                Write-debug "Security Event Log - Operation did not complete"
                                [void] ($logFile2.backupeventlog($path2 + $exportFileName2))
                                Write-debug "Security Event Log - Operation did not complete"
                                Write-output "- Preparing security event log files."
                                start-sleep 10
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_Security* C:\temp\CDAT$CDATv\Windows-Event-Logs\
                                Write-output "- Security Event Log harvest complete."
            
                        # Gathering Windows Events in Text Format
                                Write-output "Creating - system event log files in txt format."
                                Get-eventlog -logname System | format-table -wrap > C:\temp\CDAT$CDATv\Windows-Event-Logs\WinEventSystemLog.txt
                                Write-output "Creating - application event log files in txt format."
                                Get-eventlog -logname Application -newest 150 > C:\temp\CDAT$CDATv\Windows-Event-Logs\WinEventApplicationLog.txt
                                Write-output "Creating - security event log files in txt format."
                                Get-eventlog -logname Security | format-table -wrap > C:\temp\CDAT$CDATv\Windows-Event-Logs\WinEventSecurityLog.txt
            
            
                        # Gathering Unexpected Shutdowns
                        
                                Write-output "Creating - Windows Event Logs - Unexpected Shutdowns"
                                WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=6008)]]" > C:\temp\CDAT$CDATv\Windows-Event-Logs\CollectionData-WindowsEvent-UnexpectedShutdowns6008.log
            
                        # Gathering Unclean Shutdowns
            
                                Write-output "Creating - Windows Event Logs - Rebooted without Clean Shutdown"
                                WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=41)]]" > C:\temp\CDAT$CDATv\Windows-Event-Logs\CollectionData-WindowsEvent-UncleanShutdown41.log
            
                        # Gathering Exiting Connected Standby
            
                                Write-output "Creating - Windows Event Logs - Exiting Connected Standby"
                                WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=507)]]" > C:\temp\CDAT$CDATv\Windows-Event-Logs\CollectionData-WindowsEvent-ConnectedStandbyExit507.log
            
                        # Gathering System Idle Time
            
                                Write-Output "Creating - Windows System Idle Time log"
            
                                if (Test-Path 'C:\temp\CDAT330\Templates\template.html')
            
                                    {
            
                                        Idlefunction -ErrorAction SilentlyContinue
                                    
                                    }
                                
                                else 
                                     {
                                        write-output "This report cannot be executed, please ensure that \Templates\ directory is present in the same directory as CDAT"  > C:\temp\CDAT$CDATv\SystemUsageIdleTime.log
                                    
                                     }
            
                        # Gathering WER Crash logs
            
                                Write-output "Creating - Windows Error Reporting Logs"
            
                                     WER -ErrorAction:SilentlyContinue
            
                        # Gathering Live Kernel Dump
            
                                # Write-output "Creating - Live Kernel Dump, please wait..."
                                # $Kernel = (get-storagesubsystem).FriendlyName
                                # Get-StorageDiagnosticInfo -StorageSubSystemFriendlyName "$Kernel" -IncludeLiveDump -DestinationPath "C:\temp\CDAT$CDATv\Windows\"
            
            
            
            
            
            #Gathering Windows Update Log Files
            
                # Convert Wua History ResultCode to a Name
                # 0, and 5 are not used for history
                # See https://msdn.microsoft.com/en-us/library/windows/desktop/aa387095(v=vs.85).aspx
                function Convert-WuaResultCodeToName
                {
                    param(
                        [Parameter(Mandatory=$true)]
                        [int] $ResultCode
                    )
            
                    $Result = $ResultCode
                    switch($ResultCode)
                    {
                    1 {
                        $Result = "Succeeded"
                    }
                    2 {
                        $Result = "Succeeded"
                    }
                    3 {
                        $Result = "Succeeded With Errors"
                    }
                    4 {
                        $Result = "Failed"
                    }
                    }
            
                    return $Result
                }
            
                function Get-WuaHistory
                {
            
                # Get a WUA Session
                $session = (New-Object -ComObject 'Microsoft.Update.Session')
            
                # Query the latest 1000 History starting with the first recordp     
                $history = $session.QueryHistory("",0,1000) | ForEach-Object {
                    $Result = Convert-WuaResultCodeToName -ResultCode $_.ResultCode
            
                    # Make the properties hidden in com properties visible.
                    $_ | Add-Member -MemberType NoteProperty -Value $Result -Name Result
                    $Product = $_.Categories | Where-Object {$_.Type -eq 'Product'} | Select-Object -First 1 -ExpandProperty Name
                    $_ | Add-Member -MemberType NoteProperty -Value $_.UpdateIdentity.UpdateId -Name UpdateId
                    $_ | Add-Member -MemberType NoteProperty -Value $_.UpdateIdentity.RevisionNumber -Name RevisionNumber
                    $_ | Add-Member -MemberType NoteProperty -Value $Product -Name Product -PassThru
            
                    Write-Output $_
                } 
            
                #Remove null records and only return the fields we want
                $history | 
                    Where-Object {![String]::IsNullOrWhiteSpace($_.title)} | 
                        Select-Object Result, Date, Title, SupportUrl, Product, UpdateId, RevisionNumber
                }  
            
            # Get all the update History, formatted as a table
            
                Write-host "Creating - Windows Update History Report"
                Get-WuaHistory | Format-Table -Wrap > C:\temp\CDAT$CDATv\Windows\WUpdateReport.log
            
            # Gathering ThinkPad BIOS Settings via API
                If ($systype -eq 2)
                        {
                                #ThinkPad Logic
            
                                    $ThinkPadBIOS = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*"
            
                                    If ($ThinkPadBIOS -eq $True)
                                    {
                                        Write-Host "Creating - Bios Settings Log"
                                        Get-BiosSettings | ForEach-Object{$_.View()} > C:\temp\CDAT$CDATv\CDAT$CDATv-BIOS-$((Get-WmiObject win32_bios).SMBiosBIOSVersion)-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log 
            
                                    }
                                    
                                    $ThinkBookBIOS = (Get-computerinfo).CsSystemFamily -like "ThinkBook*"

                                    If ($ThinkBookBIOS -eq $True)
                                    {
                                        Write-Host "Creating - Bios Settings Log"
                                        Get-BiosSettings | ForEach-Object{$_.View()} > C:\temp\CDAT$CDATv\CDAT$CDATv-BIOS-$((Get-WmiObject win32_bios).SMBiosBIOSVersion)-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log 
            
                                    }
                        }   
                        
                If ($systype -eq 1)
                                    {
                                        $DesktopBIOS = (Get-WmiObject -class Lenovo_BiosSetting -namespace root\wmi | select-object currentsetting | Out-String).Trim()
                                        Write-host "Creating - Bios Setting Log"
                                        $DesktopBIOS > C:\temp\CDAT$CDATv\CDAT$CDATv-ThinkBIOSSettings-$((Get-WmiObject win32_bios).SMBiosBIOSVersion)-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log 
            
                                    }
            # Gathering all Installed Drivers
            
                    Write-output "Creating - Driver Log"
                    Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\Drivers.log" -width 300
                    #Get-PnpDevice | sort-object -property name | where-object -property Status -eq unknown | Select-Object Status, FriendlyName, InstanceID | format-table -autosize | out-file -encoding utf8 ".\HWD_Drivers\InstalledHWDHiddenAndPreviouslyInstalledUSBDevice.log" -width 300
                    DriverQuery /si /fo table > C:\temp\CDAT$CDATv\Installed-HWD\DriversINF.log
            
            # Gathering Install Driver INF Install CollectionDataWindowsEventFailures
            
                    Write-output "Creating - Driver INF Install Date Log, please wait..."
                    [VOID] (DriverDate  > C:\temp\CDAT$CDATv\Installed-HWD\DriversINFInstallDate.log)
            
                    Write-output "Creating - 3rd party driver OEM INF List"
                    [VOID](Dism /english /online /get-drivers /Format:Table > C:\temp\CDAT$CDATv\Installed-HWD\Driver3rdPartyOEMINF.log)
            
            # Gathering Power Manager Driver Info for ThinkPad
            
               #ThinkPad Logic
               Write-output "Creating - Lenovo Power Manager Driver Log"        
               If ($((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*") -eq $true)
               {
                    Get-WmiObject Win32_PnPSignedDriver | where-object{$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion > C:\temp\CDAT$CDATv\Power-Battery\LenovoPMDriver.log
               }
               else 
               {
                    Write-Host "This System is not a ThinkPad does not support Lenovo Power Manager Drivers." > C:\temp\CDAT$CDATv\NonThinkPadPowerManagerDriver.log
               }
            
            #Gathering Power Manager Driver Info for ThinkPad
            
               #ThinkPad Logic
               Write-output "Creating - Lenovo Power Manager Software Log"        
               If ($((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*") -eq $true)
               {
                    Copy-Item -Path 'C:\ProgramData\Lenovo\Power Manager\*.*' -Destination "C:\temp\CDAT$CDATv\Power-Battery\"
                    Write-output "Creating - Smart Power Manager registry logs"
                    reg.exe query HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Lenovo\PWRMGRV /s > C:\temp\CDAT$CDATv\ThinkPadPowerManagerRegistrySettings.log
                    Write-output "Creating - Smart standby registry logs"
                    reg.exe query HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Lenovo\SmartStandby /s > C:\temp\CDAT$CDATv\ThinkPadSmartStandbyRegistrySettings.log
               }
               else 
               {
                    Write-Host "This System is not a ThinkPad does not support Lenovo Power Manager Software." > C:\temp\CDAT$CDATv\NonThinkPadPowerManagerSoftware.log
               }
            
            #Gathering TPM Information
            
                Write-output "Creating - TPM General Information"
                Get-Tpm > C:\temp\CDAT$CDATv\TPM-Bitlocker\TPMInfo.log
                
                Write-output "Creating - TPM Logs"
                [void] (tpmtool getdeviceinformation C:\temp\CDAT$CDATv\TPM-Bitlocker\)
                [void] (tpmtool gatherlogs C:\temp\CDAT$CDATv\TPM-Bitlocker\)
                
                Write-output "Creating - Bitlocker Log"
                manage-bde -Status  > C:\temp\CDAT$CDATv\TPM-Bitlocker\BitlockerStatus.log
            
                Write-output "Creating - Boot Configuration Data"
                bcdedit > C:\temp\CDAT$CDATv\Boot\BootConfigData.log
                BCDEDIT  /ENUM ALL > C:\temp\CDAT$CDATv\Boot\BCDEdit.log
                
                Write-output "Creating - Bitlocker Data"
                Get-BitLockerVolume > C:\temp\CDAT$CDATv\TPM-Bitlocker\BitlockerData.log
            
            #Capturing CPU information
            
                Write-output "Creating - CPU Information Log"
                Get-WmiObject Win32_Processor > C:\temp\CDAT$CDATv\Installed-HWD\CPUInfo.log
            
            #Gathering Device Status 
            
                Write-output "Creating - Device Status Log"
                
                <#
                    Device logic to table calculate the windows code into more common sense strings.
                #>
                
                $ConfigManagerErrorCode = @{
                    Name = 'ConfigManagerErrorCode'
                    Expression = {
                    # property is an array, so process all values
                    $value = $_.ConfigManagerErrorCode
                    
                    switch([int]$value)
                        {
                        0          {'This device is working properly.'}
                        1          {'This device is not configured correctly.'}
                        2          {'Windows cannot load the driver for this device.'}
                        3          {'The driver for this device might be corrupted, or your system may be running low on memory or other resources.'}
                        4          {'This device is not working properly. One of its drivers or your registry might be corrupted.'}
                        5          {'The driver for this device needs a resource that Windows cannot manage.'}
                        6          {'The boot configuration for this device conflicts with other devices.'}
                        7          {'Cannot filter.'}
                        8          {'The driver loader for the device is missing.'}
                        9          {'This device is not working properly because the controlling firmware is reporting the resources for the device incorrectly.'}
                        10         {'This device cannot start.'}
                        11         {'This device failed.'}
                        12         {'This device cannot find enough free resources that it can use.'}
                        13         {'Windows cannot verify this device''s resources.'}
                        14         {'This device cannot work properly until you restart your computer.'}
                        15         {'This device is not working properly because there is probably a re-enumeration problem.'}
                        16         {'Windows cannot identify all the resources this device uses.'}
                        17         {'This device is asking for an unknown resource type.'}
                        18         {'Reinstall the drivers for this device.'}
                        19         {'Failure using the VxD loader.'}
                        20         {'Your registry might be corrupted.'}
                        21         {'System failure: Try changing the driver for this device. Windows is removing this device.'}
                        22         {'This device is disabled.'}
                        23         {'System failure: Try changing the driver for this device.'}
                        24         {'This device is not present, is not working properly, or does not have all its drivers installed.'}
                        25         {'Windows is still setting up this device.'}
                        26         {'Windows is still setting up this device.'}
                        27         {'This device does not have valid log configuration.'}
                        28         {'The drivers for this device are not installed.'}
                        29         {'This device is disabled because the firmware of the device did not give it the required resources.'}
                        30         {'This device is using an Interrupt Request (IRQ) resource that another device is using.'}
                        31         {'This device is not working properly because Windows cannot load the drivers required for this device.'}
                        default    {"$value"}
                        }
                        
                    }  
                }
                #endregion define calculated property
                
                # retrieve all instances...
                Get-CimInstance -ClassName Win32_PNPEntity | 
                    # ...and output properties "Caption" and "ConfigManagerErrorCode". The latter is defined
                    # by the hashtable in $ConfigManagerErrorCode:
                    Select-Object -Property Caption, $ConfigManagerErrorCode  | format-table -autosize | out-file -encoding utf8 "C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log" -width 300
                    #> C:\temp\CDAT$CDATv\Installed-HWD\DeviceStatus.log
                    
                
                    #Gather Devices with Issues
            
                        Write-output "Creating - Devices with Issues Report"
                        Get-WmiObject Win32_PNPEntity | Where-Object{$_.ConfigManagerErrorCode -ne 0} | Select-object Name, DeviceID  | format-table -wrap > C:\temp\CDAT$CDATv\Installed-HWD\DevicesWithIssues.log
            
            #Gathering Group Policy
            
                 #ThinkPad Logic
            
                 $ThinkPadGP = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily -like "ThinkPad*"
            
                 If ($ThinkPadGP -eq $false)
                 {
                   
            
                 }
            
                 else 
                 {
                    GPRESULT /H C:\temp\CDAT$CDATv\Group-Policy\GPReportHTML.html /f 
                    GPResult /x C:\temp\CDAT$CDATv\Group-Policy\GPReportXML.xml
                    GPREsult /R > C:\temp\CDAT$CDATv\Group-Policy\GPReportTXT.log
                 }
            
            #Gathering Sleep Study Data

                    Write-output "Creating - Sleep Study - Generic Log"
                    [void] (powercfg /SleepStudy /duration 28 /output C:\temp\CDAT$CDATv\Power-Battery\sleepstudy.html)
            
            if ($systype -eq 2)
                            {

                                    [void] (powercfg /systemSleepdiagnostics /output C:\temp\CDAT$CDATv\Power-Battery\Sleep-diagnostics.html)
            
                                    
                                    Write-output "Creating - Sleep Study - Power Plan Log"
                                    [void] (Get-WmiObject -Class win32_powerplan -Namespace root\cimv2\power > C:\temp\CDAT$CDATv\Power-Battery\PowerPlan.log)
                                    [void] (powercfg /L >> C:\temp\CDAT$CDATv\Power-Battery\PowerPlan.log)
                                    
                                    Write-output "Creating - Sleep Study - Sleep States Log, please wait..."
                                    [void] (powercfg -a > C:\temp\CDAT$CDATv\Power-Battery\Powerconfig.log)
                                    
                            }
            #Gathering Sleep Study Battery Report 
            
            if ($systype -eq 2)
                                {
                                        Write-output "Creating - Sleep Study - Battery Report Log"
                                        [void] (powercfg -batteryreport -duration 14 /output C:\temp\CDAT$CDATv\Power-Battery\battery-report.html)
                                }
            #SRumutil
            if ($systype -eq 2)
                    {
                            Write-output "Creating - PowerConfig SRUMUtil Report"
                            [void] (powercfg -srumutil)
                            [VOID] (Copy-Item SRUMutil.csv C:\temp\CDAT$CDATv\Power-Battery\SRUMUTIL.csv)
            
                            SRUM

                            Start-sleep 15

                            [void] (Remove-Item .\Srumutil.csv)
            
                            Start-sleep 10
            
                            [VOID] (Copy-Item srumutil.html C:\temp\CDAT$CDATv\Power-Battery\SRUMUTIL.html)
                    }
            # Sleep, Hibernation, Screen Off Timers
                                $PowerPlanObj = [PSCustomObject]@{
                                    InstanceId = $null
                                    ElementName = $null
                                    Settings =  New-Object System.Collections.Generic.List[PSObject]  
                                }
            
                                try {
                                    # Get the Active Power Plan
                                    $ActivePlan = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_Powerplan where IsActive=True" -ErrorAction Stop
                                    [Void](write-output ("Active Plan: " + $ActivePlan.InstanceId + " - " + $ActivePlan.ElementName))    
                                    # Set the Active Plan info in the object
                                    $PowerPlanObj.InstanceId = $ActivePlan.InstanceId
                                    $PowerPlanObj.ElementName = $ActivePlan.ElementName
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_Powerplan - make sure you have an elevated window"
                                    write-host $_.ToString()
                                    exit
                                }
            
                                # Get the readable names for the settings
                                try {
                                    $SettingNames = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_PowerSetting" -ErrorAction Stop
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_PowerSetting"
                                    write-host $_.ToString()
                                    exit
                                }
                                # Loop through the setting names and add them to a hashtable by setting id (use this to get the friendly name)
                                $SettingHash = @{}
                                foreach ($i in $SettingNames) {
                                    # Turn this Microsoft:PowerSetting\{29f6c1db-86da-48c5-9fdb-f2b67b1f44da} 
                                    # into {29f6c1db-86da-48c5-9fdb-f2b67b1f44da} for the key
                                    $SettingId = $i.InstanceId.Split("\")[-1]
                                    # Add it to the hash
                                    $SettingHash.Add($SettingId,$i)
                                    # Example: $i.ElementName = Sleep after
                                }
            
                                # Change Microsoft:PowerPlan\{381b4222-f694-41f0-9685-ff5bb260df2e} 
                                # to 381b4222-f694-41f0-9685-ff5bb260df2e for the query
                                $ActivePlanId = $PowerPlanObj.InstanceId.Split("\")[-1].Replace("{","").Replace("}","")
                                try {
                                    $Settings = Get-WmiObject -Namespace "root\cimv2\power" -Query "select InstanceId,SettingIndexValue from Win32_PowerSettingDataIndex Where InstanceId Like '%$ActivePlanId%'" -ErrorAction Stop
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_PowerSettingDataIndex"
                                    write-host $_.ToString()
                                    exit
                                }
            
                                foreach ($i in $Settings) {
                                    $SettingObj = [PSCustomObject]@{
                                        PlanId = $PowerPlanObj.InstanceId
                                        PlanName = $PowerPlanObj.ElementName
                                        SettingId = $i.InstanceId.Split("\")[-1]
                                        SettingValue = $i.SettingIndexValue
                                        SettingType = $null
                                        SettingName = $SettingHash.($i.InstanceId.Split("\")[-1]).ElementName
                                    }
                                    # Tag the settings AC or DC
                                    if ($i.InstanceId -match "AC") {
                                        $SettingObj.SettingType = "AC"
                                    }
                                    if ($i.InstanceId -match "DC") {
                                        $SettingObj.SettingType = "DC"
                                    }
                                    # Add the setting to the list
                                    $PowerPlanObj.Settings.Add($SettingObj)
                                }
                                # Output the settings
                                $PowerPlanObj.Settings | Format-table -autosize -wrap > C:\temp\CDAT$CDATv\Power-Battery\PowerTimers.Log
            
            
            #Gathering Reboot History
            
                    Write-Output "Creating - Reboot History Report"
                    Get-RebootHistory -erroraction SilentlyContinue $env:computername -DaysFromToday 180 -MaxEvents 1000 > C:\temp\CDAT$CDATv\Power-Battery\RebootHistory.log
            
            #Gathering Anti Virus Data
            
                    Write-output "Creating - Installed AntiVirus List"
                    Get-WmiObject -class "AntiVirusProduct" -Namespace "root\SecurityCenter2" > C:\temp\CDAT$CDATv\CDAT$CDATv-InstalledAntiVirus-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
            
            #Gathering .Net Framework Data
            
                    Write-output "Creating - Microsoft .Net Framework Info"
                    #$Version = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Version
                    $Info = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"
                    write-output ".NET Framework Info" $Info > C:\temp\CDAT$CDATv\Windows\NetFrameworkInfo.log
            
            #Gathering Camera Data
            
                    Write-output "Creating - Camera Details"
                    Get-WmiObject Win32_PnPEntity | Where-Object {$_.caption -match 'camera'} > C:\temp\CDAT$CDATv\Installed-HWD\camera.log
            
            #PowerConfig Energy Report
            
                    Write-output "Creating - PowerConfig Energy Report, please wait..."
                    [void] (powercfg /energy /output "C:\temp\CDAT$CDATv\Power-Battery\Powercfg-energy.html")
            
            #Audio Device Collection
            
                Write-output 'Creating - Audio Device Logs'
                write-output "Creating - Audio PNP Log"
                Get-WmiObject Win32_PnPEntity | select-object Caption, PNPClass | Where-Object {$_.caption -match 'audio'} > C:\temp\CDAT$CDATv\Audio\AudioPNP.log
                write-output "Creating - Audio Device List Log"
                Get-WmiObject Win32_PNPEntity | Where-Object{$_.Name -match 'Audio'} | Select-object Name, Status, Manufacturer, Present > C:\temp\CDAT$CDATv\Audio\AudioDeviceList.log
                write-output "Creating - Audio Driver Logs"
                Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{$_.DeviceName -match 'Audio'} > C:\temp\CDAT$CDATv\Audio\AudioDrivers.log
                write-output "Creating - Audio Smart Sound Driver Logs"
                
            #Smart Audio Logic
            
                        $SmartAudio = Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{($_.DeviceName -like '*Intel*' -and $_.DeviceName -like '*Smart*')}
            
                        If ($SmartAudio -eq $true)
                        {
                            Write-Host "Creating - Audio Intel SST Log"
                            Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{($_.DeviceName -like '*Intel*' -and $_.DeviceName -like '*Smart*')} > C:\temp\CDAT$CDATv\Audio\IntelSmartSoundAudioDrivers.log
            
                        }
            
                        else 
                        {
                            Write-Host "Creating - Audio Intel SST Log"
                            Write-output "Intel Smart Audio Devices are NOT present on this system" > C:\temp\CDAT$CDATv\Audio\NoIntelSSTAudio.log
                        }
            
            
            
            #minidump Logic
            
                $minidump = "C:\Windows\minidump\"
            
                If (!(test-path $minidump))
                {
            
                    Write-Output 'Creating - Potential Minidump Data Collection, please wait...'
                    Write-Host "No minidumps found in C:\Windows\Minidump"  -ForegroundColor green
                    Write-output "No minidumps found in C:\Windows\Minidump" > C:\temp\CDAT$CDATv\mini-dump\NoMiniDumpsFound.log 
                }
            
                else
                {        
                    #Gather mini-dump to folder
            
                    Get-ChildItem C:\windows\minidump\ | 
                    Where-Object {$_.Length -lt 10000KB} |
                    Copy-item -Destination 'C:\temp\CDAT330\mini-dump\'
                    Write-Output 'Creating - Potential Minidump Data Collection, please wait...' 
            
                }
            
            #MFGSTAT and Preload Logic
            
                #Gather MFGSTAT to folder
            
                [VOID] (ROBOCOPY    C:\windows\panther                                  C:\temp\CDAT$CDATv\Preload\WINDOWS\Panther /XD "setup.exe" "actionqueue"  /MIR  /Xf *.TMP *.png *.js *.tmp *.exe)
                [VOID] (ROBOCOPY    C:\WINDOWS\PANTHER\unattendGC                       C:\temp\CDAT$CDATv\Preload\WINDOWS\Panther\UnattendGC  *.xml)
                [VOID] (ROBOCOPY    C:\WINDOWS\PANTHER\unattendGC                        C:\temp\CDAT$CDATv\Preload\WINDOWS\Panther\UnattendGC *.LOG)
                [VOID] (ROBOCOPY    C:\WINDOWS\INF                                       C:\temp\CDAT$CDATv\Preload\WINDOWS\INF SETUPAPI.???.LOG.* )
                [VOID] (ROBOCOPY    C:\WINDOWS\INF                                       C:\temp\CDAT$CDATv\Preload\WINDOWS\INF SETUPAP*.*  )
                [VOID] (ROBOCOPY    C:\WINDOWS\INF                                      C:\temp\CDAT$CDATv\Preload\WINDOWS\INF SETUPAPI.???.??? )  
                [VOID] (ROBOCOPY    C:\WINDOWS\                                     C:\temp\CDAT$CDATv\Preload\ machineinfo.sav)
                [VOID] (ROBOCOPY     C:\WINDOWS                                        C:\temp\CDAT$CDATv\Preload\ MODULES.LOG)
            
                $MFGStat = "C:\windows\MFGSTAT.zip"
                
                If (!(test-path $MFGStat))
                {
            
                    Write-Host 'MFGStat is not present this is only contained on Lenovo Preloaded OS' -ForegroundColor DarkGreen
            
                }
            
                else
                {     
            
                    # If MFG file is present Write Host 
                    
                    Write-Host 'MFGStat is found copying data file' -ForegroundColor DarkGreen
                    [VOID] (Copy-item C:\windows\MFGSTAT.zip -Destination "C:\temp\CDAT$CDATv\Preload\")
                    [VOID] (attrib "C:\temp\CDAT$CDATv\Preload\MFGSTAT.ZIP" -s -h)
            
            
                }
            
                [VOID] (attrib "C:\temp\CDAT$CDATv\Preload\Modules.log" -s -h)
            
            #Odometer Data Capture
            
                Write-output "Creating - Odometer Diag values"
                (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror > C:\temp\CDAT$CDATv\CDAT$CDATv-Odometer-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log)    
                
            # System Update Capture
            
                $Vantage = $((Get-WMIObject -Namespace root\Lenovo -ClassName *Lenovo_Updates* -list -recurse -EA 0).Name)
                
                If ($Vantage -eq "Lenovo_Updates")
            
                {
                            #Gather System Update Data to folder
                            Write-Output 'Creating - Lenovo Vantage System Update Data, please wait...'
                            Get-WmiObject -Namespace ROOT\Lenovo -Class Lenovo_Updates | select-object InstallDate, PackageID, Severity, Status, Version,Title | format-table > C:\temp\CDAT$CDATv\CDAT$CDATv-VantageUpdates-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                }
            
                else
                {        
                    Write-Output 'Creating - Lenovo Vantage System Update Data, please wait...'
                    Write-Host "Lenovo Commercial Vantage is not installed, please install to gather this data." -ForegroundColor Red
                    Write-output "Lenovo Commercial Vantage is not installed, please install to gather this data." > C:\temp\CDAT$CDATv\CDAT$CDATv-VantageUpdateNotInstalled-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log 
            
                }
            
                
            #IM Control Plugins
                                        Write-Output "Creating - IM Controller plugin log"
                                        $VersionArray = @()
                                        $PluginFolder = "C:\ProgramData\Lenovo\ImController\Plugins"
                                        if (Test-Path $PluginFolder) {
                                            $PluginDirNames = Get-ChildItem $PluginFolder
                                            foreach ($dir in $PluginDirNames) {
                                                if (Test-Path "$($dir.FullName)\x86\$($dir.Name).dll") {
                                                    $VersionArray += GetPluginVersion "$($dir.FullName)\x86\$($dir.Name).dll" "$($dir.Name)"
                                                }
                                                elseif (Test-Path "$($dir.FullName)\x64\$($dir.Name).dll") {
                                                    $VersionArray += GetPluginVersion "$($dir.FullName)\x64\$($dir.Name).dll" "$($dir.Name)"
                                                }
                                            }
                                        
                                            # Output
                                            $VersionArray |
                                            Where-Object { $_.PluginName } |
                                            Select-Object PluginName, ProductVersion, FileVersion |
                                            export-csv -path "C:\temp\CDAT$CDATv\CDAT$CDATv-IMControllerPlugins-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).csv" 
                                        }
            #Gather Dock Information
                
                Write-Output "Creating - Lenovo Dock Manager Config Files"
            
                $DocklogPath = "C:\ProgramData\Lenovo\DockManager\Logs\INFO_dockmgr.log"
                $DockConfigData = "C:\ProgramData\Lenovo\DockManager\Config\"
            
                
                If (!(Test-Path $DocklogPath)) 
                        {
                            
                        }
            
                else    
                        {
                            Copy-Item $DockConfigData\DockInfo.json -Destination C:\temp\CDAT$CDATv\Lenovo-Dock\Json\
                            Copy-Item $DockConfigData\DockManager.json -Destination C:\temp\CDAT$CDATv\Lenovo-Dock\Json\
                            Copy-Item $DockConfigData\dm-dockattach-history.json -Destination C:\temp\CDAT$CDATv\Lenovo-Dock\Json\
                            get-content -Raw C:\temp\CDAT$CDATv\Lenovo-Dock\Json\dm-dockattach-history.json | convertfrom-json > C:\temp\CDAT$CDATv\Lenovo-Dock\dm-dockattach-history.log
                            get-content -Raw C:\temp\CDAT$CDATv\Lenovo-Dock\Json\DockInfo.json | convertfrom-json > C:\temp\CDAT$CDATv\Lenovo-Dock\DockInfo.log
                            get-content -Raw C:\temp\CDAT$CDATv\Lenovo-Dock\Json\DockManager.json | convertfrom-json > C:\temp\CDAT$CDATv\Lenovo-Dock\DockManager.log
                            Copy-Item $DocklogPath -Destination "C:\temp\CDAT$CDATv\Lenovo-Dock\"
                            
                        }
            
                
                If (Check_Program_Installed("Dockmanager_is1") = $True)
            
                        {
                            
                            Write-output "Creating - Dock Manager Data, please wait..."
                            Get-WmiObject -Namespace ROOT\Lenovo\Dock_Manager -Class DockManager > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockManager-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                            Get-WmiObject -Namespace ROOT\Lenovo\Dock_Manager -Class DockDeviceDisplayPort > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockManagerDisplayPort-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                            Get-WmiObject -Namespace ROOT\Lenovo\Dock_Manager -Class DockInfo > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockManagerInfo-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                    
                        }
                
                
                else 
            
                        {
                       
                        Write-host "Lenovo Dock Manager is not installed, please install to gather this data" 
                        Write-output "Lenovo Dock Manager is not installed, please install to gather this data" -ForegroundColor DarkGreen > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time)-LenovoDockManagerNotInstalled.log 
                    
                        }
            
            # Gather Dock Registry Settings
            
            If (Check_Program_Installed("Dockmanager_is1") = $True)
            
                        {
                            $DockReg = $null -eq (Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Lenovo\Dock Manager'-ErrorAction SilentlyContinue)
            
                            If ($DockReg -eq $True)
                            {
                                Write-Output "HKLM:\SOFTWARE\WOW6432Node\Lenovo\Dock Manager is not present in the System Registry" > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockRegistrySettings-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                            }
                            else 
                            {
                            Write-Output "Creating - Lenovo Dock Registry Files"
                            [VOID](Invoke-Command  {reg export 'HKLM\SOFTWARE\WOW6432Node\Lenovo\Dock Manager' C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockRegistrySettings-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log})
                            }
            
                            $DockRegPol = $null -eq (Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\Policies\Lenovo\Dock Manager'-ErrorAction SilentlyContinue)
            
                            If ($DockRegPol -eq $True)
                            {
                                Write-Output "HKLM:\SOFTWARE\WOW6432Node\Policies\Lenovo\Dock Manager is not present in the System Registry" > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockRegistrySettingsGpolicy-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                            }
                            else 
                            {
                            Write-Output "Creating - Lenovo Dock Registry Group Policy Files"
                            [VOID] (Invoke-Command  {reg export 'HKLM\SOFTWARE\WOW6432Node\Policies\Lenovo\Dock Manager' C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-LenovoDockRegistrySettingsGpolicy-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log })
                            }
                        }
                
                
                else 
            
                        {
                       
                        Write-output "Lenovo Dock Manager is not installed, please install to gather this data" > C:\temp\CDAT$CDATv\Lenovo-Dock\CDAT$CDATv-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time)-LenovoDockManagerNotInstalled.log 
                    
                        }
            
                        start-sleep 30

            # Create Failing Sample Checklist
                        
                        Write-output "Creating - System Sample Checklist"
                        FailSample > C:\temp\CDAT$CDATv\CDAT$CDATv-SystemSampleChecklist-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log
                        
            
            # Create a report of all the files gathered
            
                $(get-date) >> C:\temp\CDAT$CDATv\CDAT$CDATv-SystemCollectionReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                Write-Output "CDAT v3.3.0 -ALL Collection" >> C:\temp\CDAT$CDATv\CDAT$CDATv-SystemCollectionReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                Write-output $PSVersionTable >> C:\temp\CDAT$CDATv\CDAT$CDATv-SystemCollectionReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                Get-childitem -Recurse -path C:\temp\CDAT$CDATv\ >> C:\temp\CDAT$CDATv\CDAT$CDATv-SystemCollectionReport-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log         
            
            # User Messaging to Wait
                #$SystemSampleName = C:\temp\CDAT$CDATv\-SystemSampleChecklist-*
                Write-Host ""
                Write-Host "`n`t`Please wait, while we cleanup and finish collection`n"
                Write-output "`n`t`Please provide the requested items and feedback from the CDAT330-SystemSampleChecklist log included in the completed zip file.`n"
                Write-Host "`n`t`Zipping to Lenovo-CDAT330-All-1-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
            
            #Stop Transcript
            
                [VOID] (Stop-Transcript)
            
            # Compressing Files to one zip
            
                [void] (Compress-Archive -force -LiteralPath C:\temp\CDAT$CDATv\  -DestinationPath .\Lenovo-CDAT330-All-1-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
            
            # Performing Directory & File Cleanup
                start-sleep 30
                [VOID] (Remove-Item "C:\temp\CDAT$CDATv\" -Force -recurse)
                [VOID] (Remove-Item -force -recurse C:\Temp\CollectionData*.evt)
                [void] (Remove-Item .\SRUMUTIL*.html)
            
            # End Data Collection Statement
            
                Write-Host "`n`t`Please provide the compressed file to Lenovo for further analysis.`n"
                } 


Function PowerBattery {
                            #Banner Dialog

                            Write-Host "`n`t`t **********************************************`n"
                            Write-Host "`n`t`t      CDATv$CDATVEr PWR & Battery Collection    `n"
                            Write-Host "`n`t`t **********************************************`n"

                        $PowerHomeDir = ".\Power_And_Battery"

                        If (!(test-path $PowerHomedir))
                            {

                                [VOID] (mkdir ".\Power_And_Battery")

                            }

                        Write-output 'Created - Power Manager Information'
                        Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion > .\Power_And_Battery\PowerLenovoPMDriver.log
                        $PowerMgrPath = test-path -path 'C:\ProgramData\Lenovo\Power Manager\'
                        if ($PowerMgrPath -eq $True)
                                        {
                                        Copy-Item -Path 'C:\ProgramData\Lenovo\Power Manager\*.*' -Destination '.\Power_And_Battery\'
                                        }
                        Write-Output "Created - Sleep Study - Generic Log"
                        [void] (powercfg /SleepStudy /duration 28 /output .\Power_And_Battery\Powersleepstudy.html)

                        Write-Output "Created - Sleep Study - Power Plan Log"
                        [void] (Get-WmiObject -Class win32_powerplan -Namespace root\cimv2\power > .\Power_And_Battery\PowerPlan.log)

                        Write-Output "Creating - Sleep Study - Sleep States Log, please wait..."
                        [void] (powercfg -a > .\Power_And_Battery\Powerconfig.log)

                        Write-output "Creating - Sleep Study - Battery Report Log. please wait..."
                        [void] (powercfg -batteryreport /duration 14 /output .\Power_And_Battery\battery-report.html)

                        $battery = (Get-WmiObject -Class Win32_Battery).Batterystatus 
                        $systype=(Get-WmiObject win32_ComputerSystem).PCSystemType 
                    
                                    if ($battery -eq 1)
                                    {
                                        #'On battery power'
                                        # Write-output "Created - ACandPowerStatus.log"
                                        Write-output "=======================================" > .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powered by AC or Battery"                >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "This system is running on Battery Power" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powercfg Sleep Data       " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -a >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "PowerManager Driver Values" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powercfg Timers and Values" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -qh >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "PowerPlan Scheme          " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -L >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Battery Data              " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Get-WmiObject -Class Win32_Battery >> .\Power_And_Battery\ACandPowerStatus.log
                                        If ($systype -eq 2)
                                                    {
                                                            Write-Output "Creating Basic Battery Data Log"
                                                            Write-Output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-output "     Battery Data                      " >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            write-Output "Name:                         $((Get-WmiObject Win32_PortableBattery).DeviceID)"   >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Manufacturer:                 $manufacturer" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Model:                        $BatteryPN" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Plugged in:                   $pluggedIn" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Discharging:                  $discharging" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Charging                      $charging" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Remaining Charge:             $([Math]::Round($remainingCap/$lastChargedCap * 100))%" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Cycle Count:                  $cycleCount" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Design Capacity:              $designCap" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Last Full Charge Capacity:    $lastChargeCap" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "Battery Health:               $health%" >> .\Power_And_Battery\ACandPowerStatus.log
                                                            Write-Output "" >> .\Power_And_Battery\ACandPowerStatus.log
                                                    }
                                    }
                            
                                    else
                                    {
                                        #'Connected to AC'
                                        # Write-Output 'This system is running on AC Power'
                                        Write-output "Created - ACandPowerStatus.log"
                                        Write-output "=======================================" > .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powered by AC or Battery"                >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "This system is running on AC Power" >>  .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powercfg Sleep Data       " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -a >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "PowerManager Driver Values" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Get-WmiObject Win32_PnPSignedDriver | where-object {$_.Description -like "Lenovo PM*"} | Select-object Description, DriverVersion >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Powercfg Timers and Values" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -qh >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "PowerPlan Scheme          " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        powercfg -L >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "Battery Data              " >> .\Power_And_Battery\ACandPowerStatus.log
                                        Write-output "==========================" >> .\Power_And_Battery\ACandPowerStatus.log
                                        Get-WmiObject -Class Win32_Battery >> .\Power_And_Battery\ACandPowerStatus.log
                                        If ($systype -eq 2) 
                                                {
                                                        Write-Output "Created - Basic Battery Data Log"
                                                        Write-Output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-output "     Battery Data                      " >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "=======================================" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        write-Output "Name:                         $((Get-WmiObject Win32_PortableBattery).DeviceID)"   >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Manufacturer:                 $manufacturer" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Model:                        $BatteryPN" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Plugged in:                   $pluggedIn" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Discharging:                  $discharging" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Charging                      $charging" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Remaining Charge:             $([Math]::Round($remainingCap/$lastChargedCap * 100))%" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Cycle Count:                  $cycleCount" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Design Capacity:              $designCap" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Last Full Charge Capacity:    $lastChargeCap" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "Battery Health:               $health%" >> .\Power_And_Battery\ACandPowerStatus.log
                                                        Write-Output "" >> .\Power_And_Battery\ACandPowerStatus.log
                                                }
                                    }

                        Write-Output "Created - PowerConfig Schemes Report"
                        [void] (powercfg /L > .\Power_And_Battery\Powercfg_Schemes.txt)
                        
                        If ($systype -eq 2) 
                                    {
                                        Write-Output "Creating - PowerConfig SRUMUtil Report, please wait..."
                                        [void] (powercfg -srumutil)
                                        [void] (Copy-Item srumutil.csv .\Power_And_Battery\)

                                        [VOID] (SRUM)
                                        [void] (Remove-Item .\SRUMUTIL.csv)

                                        Start-sleep 10

                                        [VOID] (Copy-Item srumutil.html .\Power_And_Battery\SRUMUTIL.html)
                                        [void] (Remove-Item .\SRUMUTIL*.html)

                                        write-output "Creating - Power Manager Registry Data"
                                        reg.exe query HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Lenovo\PWRMGRV /s > .\Power_And_Battery\ThinkPadPowerManagerRegistrySettings.log

                                        Write-output "Creating - Smart standby registry logs"
                                        reg.exe query HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Lenovo\SmartStandby /s > .\Power_And_Battery\ThinkPadSmartStandbyRegistrySettings.log

                                    }       
                        Write-output "Creating - PowerConfig Energy Report, please wait..."
                        [void] (powercfg /energy /output ".\Power_And_Battery\Powercfg-energy.html")

                        Write-output "Creating - System Quick Data, please wait..."
                        QuickData > .\Power_And_Battery\Lenovo-CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log

                        # Sleep, Hibernation, Screen Off Timers
                                $PowerPlanObj = [PSCustomObject]@{
                                    InstanceId = $null
                                    ElementName = $null
                                    Settings =  New-Object System.Collections.Generic.List[PSObject]  
                                }

                                try {
                                    # Get the Active Power Plan
                                    $ActivePlan = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_Powerplan where IsActive=True" -ErrorAction Stop
                                    [Void](write-output ("Active Plan: " + $ActivePlan.InstanceId + " - " + $ActivePlan.ElementName))    
                                    # Set the Active Plan info in the object
                                    $PowerPlanObj.InstanceId = $ActivePlan.InstanceId
                                    $PowerPlanObj.ElementName = $ActivePlan.ElementName
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_Powerplan - make sure you have an elevated window"
                                    write-host $_.ToString()
                                    exit
                                }

                                # Get the readable names for the settings
                                try {
                                    $SettingNames = Get-WmiObject -Namespace "root\cimv2\power" -Query "select ElementName,InstanceID from Win32_PowerSetting" -ErrorAction Stop
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_PowerSetting"
                                    write-host $_.ToString()
                                    exit
                                }
                                # Loop through the setting names and add them to a hashtable by setting id (use this to get the friendly name)
                                $SettingHash = @{}
                                foreach ($i in $SettingNames) {
                                    # Turn this Microsoft:PowerSetting\{29f6c1db-86da-48c5-9fdb-f2b67b1f44da} 
                                    # into {29f6c1db-86da-48c5-9fdb-f2b67b1f44da} for the key
                                    $SettingId = $i.InstanceId.Split("\")[-1]
                                    # Add it to the hash
                                    $SettingHash.Add($SettingId,$i)
                                    # Example: $i.ElementName = Sleep after
                                }

                                # Change Microsoft:PowerPlan\{381b4222-f694-41f0-9685-ff5bb260df2e} 
                                # to 381b4222-f694-41f0-9685-ff5bb260df2e for the query
                                $ActivePlanId = $PowerPlanObj.InstanceId.Split("\")[-1].Replace("{","").Replace("}","")
                                try {
                                    $Settings = Get-WmiObject -Namespace "root\cimv2\power" -Query "select InstanceId,SettingIndexValue from Win32_PowerSettingDataIndex Where InstanceId Like '%$ActivePlanId%'" -ErrorAction Stop
                                } catch {
                                    write-host "Error Querying root\cimv2\power Win32_PowerSettingDataIndex"
                                    write-host $_.ToString()
                                    exit
                                }

                                foreach ($i in $Settings) {
                                    $SettingObj = [PSCustomObject]@{
                                        PlanId = $PowerPlanObj.InstanceId
                                        PlanName = $PowerPlanObj.ElementName
                                        SettingId = $i.InstanceId.Split("\")[-1]
                                        SettingValue = $i.SettingIndexValue
                                        SettingType = $null
                                        SettingName = $SettingHash.($i.InstanceId.Split("\")[-1]).ElementName
                                    }
                                    # Tag the settings AC or DC
                                    if ($i.InstanceId -match "AC") {
                                        $SettingObj.SettingType = "AC"
                                    }
                                    if ($i.InstanceId -match "DC") {
                                        $SettingObj.SettingType = "DC"
                                    }
                                    # Add the setting to the list
                                    $PowerPlanObj.Settings.Add($SettingObj)
                                }
                                # Output the settings
                                $PowerPlanObj.Settings | Format-table -autosize -wrap > .\Power_And_Battery\PowerTimers.log   
                                
                                Write-Host "`n`t`Zipping to Lenovo-CDAT-Power-8-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                [VOID] (Compress-Archive -Force -Path ".\Power_And_Battery"  -DestinationPath Lenovo-CDAT330-Power-8-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                [VOID] (Remove-Item ".\Power_And_Battery" -Force -recurse)
                    }


Function NetworkWAN 
                            {
                                    
                                        #Banner Dialog

                                        Write-Host "`n`t`t **********************************************`n"
                                        Write-Host "`n`t`t     CDATv$CDATVEr Network and WAN Collection   `n"
                                        Write-Host "`n`t`t **********************************************`n"

                                    $NetHomeDir = ".\Network_And_Wan"

                                    If (!(test-path $NetHomedir))
                                    {

                                        [VOID] (mkdir ".\Network_And_Wan")

                                    }
                                    Write-output "Creating - Computer Network Device Logs"
                                    [VOID] (Get-NetAdapter > .\Network_And_Wan\NetworkNetInterfaces.log)
                                    [VOID] (Get-NetAdapterHardwareInfo >> .\Network_And_Wan\NetworkNetInterfaces.log)
                                    [VOID] (Get-NetAdapterAdvancedProperty | format-table -autosize -wrap >> .\Network_And_Wan\NetworkNetInterfaces.log)
                                    Write-output "Creating - Computer Network Device Bindings Log"
                                    [VOID] (Get-NetAdapterBinding > .\Network_And_Wan\NetworkInterfacesBindings.log)
                                    Write-output "Creating - Computer Network Device Advanced Properties Log"
                                    [VOID] (Get-NetAdapterAdvancedProperty | format-table -autosize -wrap > .\Network_And_Wan\NetworkAdaptersPowerManagement.log) 
                                    Write-output "Creating - Computer Network Device Power Management Log"
                                    [VOID] (Get-NetAdapterPowerManagement > .\Network_And_Wan\NetworkAdaptersPowerManagement.log)
                                    Write-output "Creating - WLAN Information Log"
                                    [VOID] (netsh wlan show all > .\Network_And_Wan\NetworkWLANnetsh.log)
                                    Write-output "Creating - WWAN Information Logs"
                                    [VOID] (netsh mbn show interfaces > .\Network_And_Wan\NetworkWWAN.log)
                                    Write-output "Creating - Wi-Fi Encryption Types"
                                    netsh wlan show networks mode=BSSID > .\Network_And_Wan\NetworkWiFi_encryption_details.log
                                    if (Test-Connection google.com -Quiet) 
                                            {
                                                Write-Output "Creating - MISC Network Connective Test Data"
                                                [VOID] (Get-NetRoute > .\Network_And_Wan\NetRoute.log)
                                                [VOID] (Get-NetIPAddress > .\Network_And_Wan\NetIPAddressIPConfig.log)
                                                [VOID] (Test-NetConnection > .\Network_And_Wan\PingTestDefaultGateway.log)
                                                [VOID] (Test-NetConnection -TraceRoute > .\Network_And_Wan\TraceRoute.log)
                                            } 
                                
                                    else
                                            {
                                                Write-host "No network connectivity available"
                                            }
                                    

                                    Write-output "Creating - System Quick Data, please wait..."
                                    QuickData > .\Network_And_Wan\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log

                                    #Creating WLAN Report

                                    Write-output "Creating - WLAN Report Log"
                                    [void] (netsh wlan show wlanreport duration="45")
                                    Copy-Item -Path "$($env:ProgramData)\Microsoft\Windows\WlanReport\wlan-report-latest.html" -Destination .\Network_And_Wan\ -ErrorAction Ignore

                                    Write-Host "`n`t`Zipping to Lenovo-CDAT330-Network-Wan-6-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                    [VOID] (Compress-Archive -force -Path ".\Network_And_Wan"  -DestinationPath Lenovo-CDAT330-Network-Wan-6-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                    [VOID] (Remove-Item ".\Network_And_Wan" -Force -recurse)    
                                    
                            }

Function BootSecurity
                            {

                                #Banner Dialog

                                        Write-Host "`n`t`t **********************************************`n"
                                        Write-Host "`n`t`t     CDATv$CDATVEr TPM BCD and BL Collection    `n"
                                        Write-Host "`n`t`t **********************************************`n"
                                
                                $BCDHomeDir = ".\BCD_TPM_BL"

                                        If (!(test-path $BCDHomedir))
                                        {

                                            [VOID] (mkdir ".\BCD_TPM_BL")

                                        }

                                        Write-output "Created - Boot Configuration Data"
                                        bcdedit > .\BCD_TPM_BL\BootConfigData.log
                                        BCDEDIT  /ENUM ALL > .\BCD_TPM_BL\BCDEdit.log

                                        Write-output 'Created - TPM Information logs'
                                        [void] (tpmtool getdeviceinformation > .\BCD_TPM_BL\TPMDeviceInfo.log)
                                        [void] (tpmtool gatherlogs .\BCD_TPM_BL)

                                        Write-output "Creating - System Quick Data, please wait..."
                                        QuickData > .\BCD_TPM_BL\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log

                                        Write-Host "`n`t`Zipping to Lenovo-CDAT330-TPM-BL-BCD-5-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                        [VOID] (Compress-Archive -force -Path ".\BCD_TPM_BL"  -DestinationPath Lenovo-CDAT330-BCD-TPM-BL-5-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                        [VOID] (Remove-Item ".\BCD_TPM_BL" -Force -recurse)

                            }


Function BIOSCollection
                            {
                                
                                        #Banner Dialog

                                        Write-Host "`n`t`t **********************************************`n"
                                        Write-Host "`n`t`t       CDATv$CDATVEr BIOS Setting Collection   `n"
                                        Write-Host "`n`t`t **********************************************`n"
                                
                                
                                
                                        $BIOSHomeDir = ".\BIOS_Settings"

                                            If (!(test-path $BIOSHomedir))
                                                {

                                                    [VOID] (mkdir ".\BIOS_Settings")

                                                }
                                                Write-output "Creating - System Quick Data, please wait..."
                                                QuickData > $BIOSHomeDir\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log
                                                Write-output "Creating - BIOS Settings Data, please wait..."
                                                LenovoBIOS >> $BIOSHomeDir\BIOSSettings-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("yyyy-MM-dd")).log
                                                Write-Host "`n`t`Zipping to Lenovo-CDAT330-BIOS-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                                [VOID] (Compress-Archive -force -Path ".\BIOS_Settings"  -DestinationPath Lenovo-CDAT330-BIOS-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                                [VOID] (Remove-Item ".\BIOS_Settings" -Force -recurse)
                            }

Function HWDDriver     
                            {
                                #Banner Dialog

                                            Write-Host "`n`t`t **********************************************`n"
                                            Write-Host "`n`t`t      CDATv$CDATVEr HWD & Drivers Collection    `n"
                                            Write-Host "`n`t`t **********************************************`n"
                                
                                #Directory Structure

                                $HWDHomeDir = ".\HWD_Drivers"

                                        If (!(test-path $HWDHomedir))
                                        {

                                            [VOID] (mkdir ".\HWD_Drivers")

                                        }
                                # Creating Installed HWD List

                                Write-output "Created - Installed Hardware List"
                                Get-PnpDevice | Select-Object Status,FriendlyName, InstanceID | format-table -wrap > .\HWD_Drivers\InstalledHardwareList.log
                                ./templates/DSC_Control_v4.1.exe Q > .\HWD_Drivers\DSC_v41.Log

                                # Creating Dxdiag
                                Dxdiag /t .\HWD_Drivers\DxDiag.log

                                # Creating Hidden and Previously Installed Device List

                                Write-output "Created - Hidden & Previous Installed USB Devices Log"
                                Get-PnpDevice | sort-object -property name | where-object -property Status -eq unknown | Select-Object Status, FriendlyName, InstanceID >  .\HWD_Drivers\InstalledHWDHiddenAndPreviouslyInstalledUSBDevice.log
                                Get-PnpDevice | sort-object -property name | where-object -property Status -eq unknown | Select-Object Status, FriendlyName, InstanceID |format-table -autosize | out-file -encoding utf8 ".\HWD_Drivers\InstalledHWDHiddenAndPreviouslyInstalledUSBDevice.log" -width 300

                                Write-Output "Created - RAMM Module Log"
                                Get-CimInstance -Class CIM_PhysicalMemory | Select-Object Tag, capacity, speed, Manufacturer, PartNumber >  .\HWD_Drivers\InstalledHWDRamm.log
                                Get-WmiObject win32_physicalmemory | Format-Table Manufacturer,Banklabel,Configuredclockspeed,Devicelocator,Capacity,Serialnumber -autosize >> .\HWD_Drivers\InstalledHWDRamm.log

                                Write-Output "Created - Video Card Adapter Log"
                                Get-WmiObject Win32_VideoController | select-object VideoProcessor, Description, DriverVersion, DriverDate, VideoModeDescription >  .\HWD_Drivers\InstalledHWDVideoCardInfo.log
                                Get-WmiObject Win32_VideoController >> .\HWD_Drivers\InstalledHWDVideoCardInfo.log

                                Write-output "Created - Display EDID Information from the Registry"
                                [VOID] (reg export "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\DISPLAY" .\HWD_Drivers\InstalledHWDAttachedDisplayEDID.log /y)

                                Write-output "Created - Bluetooth System Report"
                                BT > .\HWD_Drivers\BluetoothSystemReport.log

                                Get-WmiObject Win32_USBControllerDevice |ForEach-Object{[wmi]($_.Dependent)} |Sort-Object Description,DeviceID | Format-Table Description,DeviceID -AutoSize -wrap >  .\HWD_Drivers\InstalledHWDPIDVID.log
                                Write-output "Created - PID VID Values for attached Displays"

                                Write-output "Created - Driver Log"
                                Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | format-table -wrap >  .\HWD_Drivers\InstalledHWDDrivers.log
                                Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | format-table -autosize | out-file -encoding utf8 ".\HWD_Drivers\Drivers.log" -width 300
                                DriverQuery /si /fo table > .\HWD_Drivers\InstalledHWDDriversINF.log

                                Write-output "Created - Driver INF Install Date Log"
                                [VOID] (DriverDate  > .\HWD_Drivers\DriversINFInstallDate.log)

                                Write-output "Created - 3rd party driver OEM INF List"
                                [VOID](Dism /english /online /get-drivers /Format:Table > .\HWD_Drivers\Driver3rdPartyOEMINF.log)
                        


                                Write-output 'Created - CPU Information'
                                Get-WmiObject Win32_Processor >  .\HWD_Drivers\InstalledCPUInfo.log

                                Write-Output "Created - Disk info Log"
                                Get-Disk | Format-Table -AutoSize >  .\HWD_Drivers\InstalledDiskInfo.log
                                Get-Partition -DiskNumber 0 >>  .\HWD_Drivers\InstalledDiskInfo.log
                                Get-Disk | Get-StorageReliabilityCounter | Select-Object -Property "*" >>  .\HWD_Drivers\InstalledDiskInfo.log
                                # Get-PhysicalDisk | Get-StorageFirmwareInformation >>  .\HWD_Drivers\InstalledDiskInfo.log

                                write-output "Created - Audio PNP Log"
                                Get-WmiObject Win32_PnPEntity | select-object Caption, PNPClass | Where-Object {$_.caption -match 'audio'} >  .\HWD_Drivers\InstalledHWDAudioPNP.log
                                write-output "Created - Audio Device List Log"
                                Get-WmiObject Win32_PNPEntity | Where-Object{$_.Name -match 'Audio'} | Select-object Name, Status, Manufacturer, Present >  .\HWD_Drivers\InstalledAudioDeviceList.log
                                write-output "Created - Audio Driver Logs"
                                Get-WmiObject Win32_PnPSignedDriver| select-object DeviceName, DriverVersion | Where-Object{$_.DeviceName -match 'Audio'} >  .\HWD_Drivers\InstalledAudioDrivers.log

                                Write-output "Created - Camera Details"
                                Get-WmiObject Win32_PnPEntity | Where-Object {$_.caption -match 'camera'} >  .\HWD_Drivers\InstalledCamera.log

                                if (Get-WmiObject Win32_PnPSignedDriver | select-object DeviceName, DriverVersion | Where-Object{($_.DeviceName -like '*Intel*' -and $_.DeviceName -like '*WMI*')})              
                                    {
                                    Write-Output "Created - Intel ME Firmware Dump"
                                    [VOID] (Get-Ciminstance -class ME_System -namespace 'Root\Intel_ME' >  .\HWD_Drivers\InstalledHWDIntelME.log)
                                    Get-childitem  -path .\IntelME*
                                    }

                                    else
                                    {
                                    #Write-output "Your CPU is non Intel and does not support Intel ME or does not have Intel ME WMI provider software installed, if your CPU is Intel install that software package and run this tool again." 
                                    Write-output "Your CPU is non Intel and does not support Intel ME or does not have Intel ME WMI provider software installed, if your CPU is Intel install that software package and run this tool again." > .\HWD_Drivers\IntelME.log
                                    Write-output "Your CPU is an $((Get-WmiObject Win32_Processor).Name)" >>  .\HWD_Drivers\InstalledHWDIntelME.log
                                    }

                                Write-output "Created - MSInfo NFO Log"
                                [void] (msinfo32 /nfo  .\HWD_Drivers\MSInfo32.NFO)
                                start-sleep 75
                                #[Void] (msinfo32 /report .\HWD_Drivers\MSINFO32Report.txt)
                                start-sleep 30

                                Write-output "Created - Odometer Diag values"
                                (Get-WmiObject -Namespace root\Lenovo -Class Lenovo_Odometer -ErrorAction SilentlyContinue -ErrorVariable wmiclasserror >  .\HWD_Drivers\InstalledHWDOdometerData.log)
                            
                                start-sleep 90

                                Write-output "Creating - System Quick Data, Please Wait..."
                                QuickData > .\HWD_Drivers\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log
                                
                                Write-Host "`n`t`Zipping to Lenovo-CDAT330-HWD-Drivers-4-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                [VOID] (Compress-Archive -force -Path ".\HWD_Drivers"  -DestinationPath Lenovo-CDAT330-HWD-Drivers-4-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                [VOID] (Remove-Item ".\HWD_Drivers" -Force -recurse)
                            }

Function WINEvtDump 
                            {
                                #Banner Dialog

                                        Write-Host "`n`t`t **********************************************`n"
                                        Write-Host "`n`t`t      CDATv$CDATVer WIN EVT & BSOD Collection   `n"
                                        Write-Host "`n`t`t **********************************************`n"

                                #Directory Setup

                                        $WinHomeDir = ".\Win_Events"

                                            If (!(test-path $WinHomedir))
                                            {

                                                [VOID] (mkdir ".\Win_Events")

                                            }
                        
                                Write-output "Creating - Windows Event Logs, please wait..."
                                #Get-EventLog -Log "Application" > EventLog_Application.log
                                #Get-EventLog -Log "Security" > EventLog_Security.log
                                #Get-EventLog -Log "System" > EventLog_System.log
                                #Get-EventLog -LogName System | Group-Object -Property UserName -NoElement | Select-Object -Property Count, Name >> Eventlog_System.log
                                #Get-EventLog -LogName Security | Group-Object -Property UserName -NoElement | Select-Object -Property Count, Name >> Eventlog_Security.log
                                #Get-EventLog -LogName Application | Group-Object -Property UserName -NoElement | Select-Object -Property Count, Name >> Eventlog_Application.log
                                
                                # Config Application Event Log
                                $logFileName = "Application" # Add Name of the Logfile (System, Application, etc)
                                $path = "C:\temp\" # Add Path, needs to end with a backslash
                                # 
                                $exportFileName = "CollectionData_WindowsEventLogs_" + $logFileName + (get-date -f MMddyyyy) + ".evt"
                                $logFile = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName}
                                [void] ($logFile.backupeventlog($path + $exportFileName))
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_Application* .\Win_Events
                                
                                # Config System Event Log
                                $logFileName1 = "System" # Add Name of the Logfile (System, Application, etc)
                                $path1 = "C:\temp\" # Add Path, needs to end with a backslash
                                # 
                                $exportFileName1 = "CollectionData_WindowsEventLogs_" + $logFileName1 + (get-date -f MMddyyyy) + ".evt"
                                $logFile1 = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName1}
                                [void] ($logFile1.backupeventlog($path1 + $exportFileName1))
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_System* .\Win_Events
                                
                                # Config Security Event Log
                                $logFileName2 = "Security" # Add Name of the Logfile (System, Application, etc)
                                $path2 = "C:\temp\" # Add Path, needs to end with a backslash
                                # 
                                $exportFileName2 = "CollectionData_WindowsEventLogs_" + $logFileName2 + (get-date -f MMddyyyy) + ".evt"
                                $logFile2 = Get-WmiObject Win32_NTEventlogFile | Where-Object {$_.logfilename -eq $logFileName2}
                                [void] ($logFile2.backupeventlog($path2 + $exportFileName2))
                                Copy-Item C:\Temp\CollectionData_WindowsEventLogs_Security* .\Win_Events
                                
                                # Windows Event Log Errors

                                        $Events = Get-WinEvent -LogName Application 
                                        $Events | Select-String -InputObject {$_.message} -Pattern 'Failed' > .\Win_Events\CollectionDataWindowsEventFailures.log

                                # Gathering Windows Events in Text Format

                                            Get-eventlog -logname System | format-table -wrap > .\Win_Events\WinEventSystemLog.txt
                                            Get-eventlog -logname Application | format-table -wrap > .\Win_Events\WinEventApplicationLog.txt
                                            Get-eventlog -logname Security | format-table -wrap > .\Win_Events\WinEventSecurityLog.txt

                                # Gathering Unexpected Shutdowns
                                        
                                            Write-output "Created - Windows Event Logs - Unexpected Shutdowns"
                                            WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=6008)]]" > .\Win_Events\CollectionData-WindowsEvent-UnexpectedShutdowns6008.log
                        
                                # Gathering Unclean Shutdowns
                        
                                            Write-output "Created - Windows Event Logs - Rebooted without Clean Shutdown"
                                            WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=41)]]" > .\Win_Events\CollectionData-WindowsEvent-UncleanShutdown41.log
                        
                                # Gathering Exiting Connected Standby
                        
                                            Write-output "Created - Windows Event Logs - Exiting Connected Standby"
                                            WEVTUtil query-events System /count:50 /rd:true /format:text /q:"Event[System[(EventID=507)]]" > .\Win_Events\CollectionData-WindowsEvent-ConnectedStandbyExit507.log
                        
                                # Gathering WER Crash logs
                        
                                            Write-output "Created - Windows Error Reporting Logs"
                                            get-winevent -filterHashtable @{logname='application';ID='1001'} -MaxEvents 200 | format-table -autosize -wrap > .\WIN_Events\WindowsErrorReportingDetail.log

                                # Minidump Collection

                                            $minidump1 = "C:\Windows\minidump\"

                                            If (!(test-path $minidump1))
                                            {
                                        
                                                Write-Output 'Creating - Potential Minidump Data Collection, please wait...'
                                                Write-Host "No minidumps found in C:\Windows\Minidump" --ForegroundColor green
                                                Write-output "No minidumps found in C:\Windows\Minidump" > .\Win_Events\NoMiniDumpsFound.log 
                                            }
                                        
                                            else
                                            {        
                                                #Gather mini-dump to folder
                                        
                                                Get-ChildItem C:\windows\minidump\ | 
                                                Where-Object {$_.Length -lt 10000KB} |
                                                Copy-item -Destination '.\Win_Events'
                                                Write-Output 'Creating - Potential Minidump Data Collection, please wait...' 
                                        
                                            }

                                start-sleep 5

                                Write-output "Creating - System Quick Data, Please Wait..."
                                QuickData > .\Win_Events\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log

                                # Performing Directory & File Cleanup

                                Write-Host "`n`t`Zipping to Lenovo-CDAT330-WIN-Event-BSOD-3-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                [VOID] (Compress-Archive -force -Path ".\Win_Events"  -DestinationPath Lenovo-CDAT330-WIN-Event-BSOD-3-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                [VOID] (Remove-Item ".\Win_Events" -Force -recurse)
                                [VOID] (Remove-Item -force -recurse C:\Temp\CollectionData*.evt)
                            }

Function WINPreload
                            {
                                Write-Host "`n`t`t ********************************************`n"
                                Write-Host "`n`t`t      CDATv$CDATVEr WIN & Preload Collection `n"
                                Write-Host "`n`t`t ********************************************`n"

                                $WinPreHomeDir = ".\Win_And_Preload"

                                        If (!(test-path $WinPreHomedir))
                                        {

                                            [VOID] (mkdir ".\Win_And_Preload")

                                        }

                                #Gathering Windows Update Log Files

                                            # Convert Wua History ResultCode to a Name
                                            # 0, and 5 are not used for history
                                            # See https://msdn.microsoft.com/en-us/library/windows/desktop/aa387095(v=vs.85).aspx
                                            function Convert-WuaResultCodeToName
                                            {
                                                param(
                                                    [Parameter(Mandatory=$true)]
                                                    [int] $ResultCode
                                                )

                                                $Result = $ResultCode
                                                switch($ResultCode)
                                                {
                                                1 {
                                                    $Result = "Succeeded"
                                                }
                                                2 {
                                                    $Result = "Succeeded"
                                                }
                                                3 {
                                                    $Result = "Succeeded With Errors"
                                                }
                                                4 {
                                                    $Result = "Failed"
                                                }
                                                }

                                                return $Result
                                            }

                                            function Get-WuaHistory
                                            {

                                            # Get a WUA Session
                                            $session = (New-Object -ComObject 'Microsoft.Update.Session')

                                            # Query the latest 1000 History starting with the first recordp     
                                            $history = $session.QueryHistory("",0,1000) | ForEach-Object {
                                                $Result = Convert-WuaResultCodeToName -ResultCode $_.ResultCode

                                                # Make the properties hidden in com properties visible.
                                                $_ | Add-Member -MemberType NoteProperty -Value $Result -Name Result
                                                $Product = $_.Categories | Where-Object {$_.Type -eq 'Product'} | Select-Object -First 1 -ExpandProperty Name
                                                $_ | Add-Member -MemberType NoteProperty -Value $_.UpdateIdentity.UpdateId -Name UpdateId
                                                $_ | Add-Member -MemberType NoteProperty -Value $_.UpdateIdentity.RevisionNumber -Name RevisionNumber
                                                $_ | Add-Member -MemberType NoteProperty -Value $Product -Name Product -PassThru

                                                Write-Output $_
                                            } 

                                            #Remove null records and only return the fields we want
                                            $history | 
                                                Where-Object {![String]::IsNullOrWhiteSpace($_.title)} | 
                                                    Select-Object Result, Date, Title, SupportUrl, Product, UpdateId, RevisionNumber
                                            }  

                                # Get all the update History, formatted as a table

                                        Write-host "Created - Windows Update History Report"
                                        Get-WuaHistory | Format-Table -Wrap > .\Win_And_Preload\WUpdateReport.log

                                Write-output "Created - Computer Info Log"
                                (Get-ComputerInfo > .\Win_And_Preload\ComputerInfo.log)

                                Write-output "Created - Win Info Log"  
                                Get-ComputerInfo > .\Win_And_Preload\WindowsInformation.log

                                Write-output "Created - Windows Basic System Information Log" > .\Win_And_Preload\WindowsBasicSystemInformation.log

                                Write-output "Created - Windows Apps Installed Information Log" 
                                Get-AppxPackage -AllUsers | Select-object Name, PackageFullName | Format-table -autosize -wrap > .\Win_And_Preload\WindowsInstalledApps.log

                                Write-output "Created - 3rd Party Apps Installed Information Log"
                                get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*| Select-Object displayname, InstallDate, DisplayVersion > .\Win_And_Preload\Windows3rdPartyInstalledApps.log
                                Get-Package | sort-object Name | format-table -wrap -autosize > .\Win_And_Preload\AllInstalledPrograms.log
                                Get-WmiObject -Class Win32_InstalledWin32Program | select-object name, version | format-table -autosize -wrap >> .\Win_And_Preload\AllInstalledPrograms.log          
                                Write-output "Created - Windows Process Log"
                                Get-Process | Format-List *  > .\Win_And_Preload\WindowsProcessLog.log

                                Write-output "Created - Windows Startup Items"  
                                Get-CimInstance Win32_StartupCommand | Select-Object Name, Location, User | Format-table -autosize -wrap > .\Win_And_Preload\WindowsStartup.log

                                Write-output "Created - Windows Services Features Log"
                                get-windowsoptionalfeature -online | format-table > .\Win_And_Preload\WindowsFeatures.txt

                                Write-output "Created - Windows Optional Service Features Log"
                                Get-WmiObject Win32_OptionalFeature > .\Win_And_Preload\WindowsOptionalFeatures.txt

                                Write-output "Created - Information - Scheduled Tasks"
                                Get-ScheduledTask | format-table -autosize -wrap > .\Win_And_Preload\WindowsScheduledTasks.log

                                Write-output "Created - Information - Services"
                                Get-Service | format-table -autosize -wrap> .\Win_And_Preload\WindowsServices.log

                                Write-output "Created - Hot Fix Installed KB Log"
                                Get-HotFix | format-table -autosize -wrap > .\Win_And_Preload\WindowsHotfix.log

                                Write-Output "Created - Microsoft .Net Framework Info"
                                $Version = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Version
                                $Info = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full"
                                Write-Output ".NET Framework Info" $Info  > .\Win_And_Preload\WindowsNetFrameworkInfo.log
                                Write-Output ".NET Framework Version Info" $Version >> .\Win_And_Preload\WindowsNetFrameworkVersion.log

                                Write-output "Created - Installed AntiVirus List"
                                Get-WmiObject -class "AntiVirusProduct" -Namespace "root\SecurityCenter2" > .\Win_And_Preload\WindowsInstalledAntiVirus.log

                                        write-output "Created - Group Policy Report"
                                        GPRESULT /H .\Win_And_Preload\WindowsGPReportHTML.html /f 
                                        GPResult /x .\Win_And_Preload\WindowsGPReportXML.xml

                                # Gathering Registry Info

                                        Write-output "Created - Windows Registry Data, please wait..."
                                        [VOID] (reg.exe export HKLM\SYSTEM\CurrentControlSet .\WIN_and_Preload\HKLM.SYSTEM.CurrentControlSet.reg.log)
                                        [VOID] (reg.exe export HKLM\HARDWARE .\WIN_and_Preload\HKLM.HARDWARE.reg.log)

                                        Start-sleep 30

                                # Windows Environment Variables

                                        Write-Output "Created - Windows Env Variables Log"
                                        Get-ChildItem env: | Select-Object -Property @("Key", "Value") | Out-file ".\WIN_and_Preload\WindowsEnvVar.log"

                                #MFGSTAT and Preload Logic

                                #Gather MFGSTAT to folder
                                                    [VOID] (ROBOCOPY    C:\windows\panther                             .\Win_And_Preload\Panther /XD "setup.exe" "actionqueue"  /MIR  /Xf *.TMP *.png *.js *.tmp *.exe)
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\PANTHER\unattendGC                  .\Win_And_Preload\Panther\UnattendGC  *.xml)
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\PANTHER\unattendGC                  .\Win_And_Preload\Panther\UnattendGC *.LOG)
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\INF                                 .\Win_And_Preload\INF SETUPAPI.???.LOG.* )
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\INF                                 .\Win_And_Preload\INF SETUPAP*.*  )
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\INF                                 .\Win_And_Preload\INF SETUPAPI.???.??? )  
                                                    [VOID] (ROBOCOPY    C:\WINDOWS\                                    .\Win_And_Preload\ machineinfo.sav)
                                                    [VOID] (ROBOCOPY    C:\WINDOWS                                     .\Win_And_Preload\ MODULES.LOG)
                                                    $MFGStat = "C:\windows\MFGSTAT.zip"
                                
                                                    If (!(test-path $MFGStat))
                                                    {
                                                
                                                        Write-Output 'MFGSTat is not present this is only contained on Lenovo Preloaded OS'
                                                
                                                    }
                                                
                                                    else
                                                    {     
                                                
                                                        # If MFG file is not present Write Host 
                                                        
                                                        Write-Output 'MFGSTat is found copying data file'
                                                        [VOID] (Copy-item C:\windows\MFGSTAT.zip -Destination '.\Win_And_Preload\')
                                                        [VOID] (attrib ".\Win_And_Preload\\MFGSTAT.ZIP" -s -h)
                                                
                                                
                                                    }
                                                    [VOID] (attrib ".\Win_And_Preload\Modules.log" -s -h)


                                Write-output "Creating - System Quick Data, please wait..."
                                QuickData > .\Win_And_Preload\CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).log

                                Write-Host "`n`t`Zipping to Lenovo-CDAT330-WIN-And-Preload-2-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$((Get-CimInstance win32_bios).serialnumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")).zip.`n"
                                [VOID] (Compress-Archive -force -Path ".\Win_And_Preload"  -DestinationPath Lenovo-CDAT330-WIN-And-Preload-2-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$((Get-CimInstance win32_bios).serialnumber)-$((Get-CimInstance -Class CIM_ComputerSystem).SystemFamily)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")))
                                [VOID] (Remove-Item ".\Win_And_Preload" -Force -recurse)

    
                        }

Function Slider 
                        {
                            #AC DC Determination
                        $juice = (get-wmiobject -namespace root\wmi batterystatus).PowerOnline

                        #Provide registry key path 
                        $regPath = "Registry::HKLM\SYSTEM\ControlSet001\Control\Power\User\PowerSchemes\"

                        #Provide registry entry display name 
                        $ACvalueName = "ActiveOverlayACPowerscheme"
                        $DCvalueName = "ActiveOverlayDCPowerscheme"

                        $regkeyexists = Test-Path -Path $regPath

                        ### IF on AC ###
                            if ($juice -eq $True) 
                                        
                                    {
                                        if ($regkeyexists) 
                                                    
                                                {

                                                        #Performance Values
                                                        $BestPerformance = 'ded574b5-45a0-4f42-8737-46345c09c238'
                                                        $BetterPerformance = '381B4222-F694-41F0-9685-FF5BB260DF2E'
                                                        $BetterBattery = '961CC777-2547-4F9D-8174-7D86181b8A7A'

                                                        #Check if registry entry named Status exists
                                                        $regentryexists = Get-ItemProperty -Path $regpath -Name $ACvalueName -ErrorAction SilentlyContinue
                                                        if ($regentryexists)    {
                                                                                    
                                                                                    $Performance = Get-ItemPropertyValue 'Registry::HKLM\SYSTEM\ControlSet001\Control\Power\User\PowerSchemes\' -Name ActiveOverlayACPowerscheme -ErrorAction SilentlyContinue
                                                                                    $DefaultPerformance = Get-ItemPropertyValue 'Registry::HKLM\SYSTEM\ControlSet001\Control\Power\User\PowerSchemes\' -Name ActivePowerscheme

                                                                                    If($Performance -eq $BestPerformance)
                                                                                        {
                                                                                            Write-output "Best Performance"
                                                                                        }

                                                                                    If($Performance -eq $BetterPerformance)
                                                                                        {
                                                                                            Write-output "Better Performance"
                                                                                        }

                                                                                    If($Performance -eq $BetterBattery)
                                                                                        {
                                                                                            Write-output "Bettter Battery"
                                                                                        }
                                                                                    
                                                                                    If ($Performance -eq '00000000-0000-0000-0000-000000000000')
                                                                                        {
                                                                                            If($DefaultPerformance -eq '381B4222-F694-41F0-9685-FF5BB260DF2E')
                                                                                                {
                                                                                                    Write-Output "Better Performance"
                                                
                                                                                                }
                                                
                                                                                            If($DefaultPerformance -eq 'ded574b5-45a0-4f42-8737-46345c09c238')
                                                                                                {
                                                                                                    Write-Output "Best Performance"
                                                                                                    
                                                                                                }
                                                                                            If($DefaultPerformance -eq '961CC777-2547-4F9D-8174-7D86181b8A7A')
                                                                                                {
                                                                                                    Write-Output "Better Battery"
                                                                                                    
                                                                                                }
                                                                                        }
                                                                                } 

                                            
                                                } 

                                    }


                        ### IF on DC ###
                        if ($juice -eq $False) 
                                        
                        {
                            if ($regkeyexists) 
                                        
                                    {

                                            #Performance Values
                                            $BestPerformance = 'ded574b5-45a0-4f42-8737-46345c09c238'
                                            $BetterPerformance = '381B4222-F694-41F0-9685-FF5BB260DF2E'
                                            $BetterBattery = '961CC777-2547-4F9D-8174-7D86181b8A7A'

                                            #Check if registry entry named Status exists
                                            $regentryexists = Get-ItemProperty -Path $regpath -Name $DCvalueName -ErrorAction SilentlyContinue
                                            if ($regentryexists)    {
                                                                        
                                                                        $Performance = Get-ItemPropertyValue 'Registry::HKLM\SYSTEM\ControlSet001\Control\Power\User\PowerSchemes\' -Name ActiveOverlayDCPowerscheme -ErrorAction SilentlyContinue
                                                                        $DefaultPerformance = Get-ItemPropertyValue 'Registry::HKLM\SYSTEM\ControlSet001\Control\Power\User\PowerSchemes\' -Name ActivePowerscheme

                                                                        If($Performance -eq $BestPerformance)
                                                                            {
                                                                                Write-output "Best Performance"

                                                                            }

                                                                        If($Performance -eq $BetterPerformance)
                                                                            {
                                                                                Write-output "Bettter Performance"
                                                                            }

                                                                        If($Performance -eq $BetterBattery)
                                                                            {
                                                                                Write-output "Bettter Battery"
                                                                            }
                                                                        
                                                                        If ($Performance -eq '00000000-0000-0000-0000-000000000000')
                                                                            {
                                                                                If($DefaultPerformance -eq '381B4222-F694-41F0-9685-FF5BB260DF2E')
                                                                                    {
                                                                                        Write-Output "Better Performance"
                                    
                                                                                    }
                                    
                                                                                If($DefaultPerformance -eq 'ded574b5-45a0-4f42-8737-46345c09c238')
                                                                                    {
                                                                                        Write-Output "Best Performance"
                                                                                        
                                                                                    }
                                                                                If($DefaultPerformance -eq '961CC777-2547-4F9D-8174-7D86181b8A7A')
                                                                                    {
                                                                                        Write-Output "Better Battery"
                                                                                        
                                                                                    }
                                                                            }
                                                                    } 

                                
                                    } 

                        }

                        }

    If ($ALL)    
                { 
                    ### All Collection Selection [1] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    ALL
                    Exit
                
                }
    
    If ($Preload)    
                {
                    ### Windows and Preload Selection [2] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    WINPreload
                    Exit
                }

    If ($EVENTS)    
                {
                    ### Win Evt and Mini Dump Selection [3] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    WINEvtDump
                    Exit
                }

    If ($Drivers)    
                {
                    ### BCD, TPM, BL Selection [4] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    HWDDriver
                    Exit

                }
                
    If ($Security)
                {
                    ### BCD, TPM, BL Selection [5] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    BootSecurity
                    Exit

                }

    If ($Network)
                {
                    ### Network and WAN Selection [6] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    NETWORKWAN
                    Exit

                }

    If ($BIOS)    
                { 
                    ### BIOS Setting Selection [7] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    BIOSCollection
                    EXIT
                    
                }

    If ($Power)
                {
                    ### Power, Sleep and Battery Selection [8] ###
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    PowerBattery
                    EXIT

                }

    If ($Data)    
                { 
                    ### QuickData Selection [9] ###
                    Write-output ""
                    Write-Host "Preparing environments, please wait..."
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    Write-output "Gathering System Quick Data in to a report, this may take several minutes please wait..."
                    Quickdata > .\CDAT$CDATv-QuickData-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log
                    Write-Host "Gathering System Quick Data in to a report is complete to file - CDAT$CDATv-QuickData-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log"
                    Write-output ""
                    Exit
                }

    If ($Issues)   
                { 
                    ### Potential Issues Selection [10] ###
                    Write-output ""
                    Write-Host "Preparing environments, please wait..."
                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                    Write-output "Gathering System Potential Issues in to a report, this may take several minutes please wait..."
                    KnownIssues > .\CDAT$CDATv-Issues-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log
                    Write-Host "Gathering System Potential Issues in to a report is complete to file - CDAT$CDATv-Issues-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log"
                    Write-output ""
                    Exit
                }

    If ($Readme)     
                {

                    $CDATv = "330"
                    $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                    $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                    CDATHelp
                    Exit

                }

# Elevate to Admin w/ UAC prompt


        if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
        {
            Write-Host "Escalating to Admin, please wait..." -ForegroundColor DarkGreen
            Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            exit
        }

        Set-Location $PSScriptRoot #Move to the script directory in case this was elevated

        Write-Output "Preparing CDAT Startup Data, please wait..."

        If ((Get-CimInstance -ClassName Win32_bios).manufacturer -eq "Lenovo")
                {

                        If (test-path .\Templates\)

                                {

                                }

                        else 
                        
                                {
                                    $CDATVer = "3.3.0"
                                    $CDATv = "330"
                                    Write-Output "The Templates directory is not present, please ensure Templates directory is in the same directory as CDATv$CDATv and try again"
                                    Exit
                                
                                }
                    }
        
        Else 
                    {
                        $SysMFG =(Get-CimInstance -ClassName Win32_bios).manufacturer

                        Write-output ""
                        Write-output "CDAT only runs on Lenovo branded systems, this system is a $SysMFG"
                        Write-output ""
                        EXIT

                    }



# Version ID

        $CDATVer = "3.3.0"
        $CDATv = "330"

# System type determination

        $systype=(Get-WmiObject win32_ComputerSystem).PCSystemType 

# Quick Data Variables

        If($systype -eq 2)

                {
                        $BatteryPN = (Get-WmiObject -namespace root\wmi -class BatteryStaticData).DeviceName
                }

        $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
        $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
        $SerialNumber = (Get-CimInstance win32_bios).serialnumber
        $Time = ((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmm")
        $BIOS1 = (Get-WmiObject win32_bios).SMBiosBIOSVersion
        $ECMajor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMajorVersion
        $ECMinor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMinorVersion
        $Baseboard = (Get-WmiObject win32_baseboard).SerialNumber
        

# Quick Data Battery Variables
        if ($systype -eq 2)
                {

                    $cycleCount = (get-wmiobject -namespace root\wmi batteryCycleCount).CycleCount

                }


OEMCheck
function Show-Menu

            {
                param (
                    [string]$Title = 'CDAT Menu'
                )
                Clear-Host
                Write-Host "`n`t`t **************************************`n"
                Write-Host "`n`t`t           Lenovo CDAT v$($CDATVer)    `n" 
                Write-Host "`n`t`t***************************************`n"
                
                Write-Host "`t`t[ 1] All Data Collections."
                Write-Host "`t`t[ 2] Windows & Preload Collection."
                Write-Host "`t`t[ 3] Win Events & Mini Dump Collection."
                write-host "`t`t[ 4] HWD, Vpro, ME & Driver Collection."
                write-host "`t`t[ 5] BCD, TPM, and BitLocker Collection."
                write-host "`t`t[ 6] Network and WAN Collection."
                Write-host "`t`t[ 7] BIOS Setting Collection."
                Write-host "`t`t[ 8] Power, Sleep & Battery Collection."
                Write-host "`t`t[ 9] Quick System Data Collection."
                Write-host "`t`t[10] Potential Issues Collection.`n"
                Write-Host "`t`t***************************************"
                Write-host "`t`t [R] Readme & Changes.`n"

                Write-Host "Press 'q' to quit."
            }

do
 {
    if($null -ne $select)
        {
            $selection = $select
            $select = $null
        }
    else 

        {
            Show-Menu
            $selection = Read-Host "Please select from the above options"         
        }
        switch ($selection)
    {
        
        '1' 
            {
                  
                    All
            
            } 
    
    
        '2' {

                    WINPreload

            } 
                
                
        '3' {
                    
                    WINEvtDump

            }

        '4'
            {

                    HWDDriver   

            }

        '5'
            {

                    BootSecurity

            }
        '6'
            {

                    NetworkWan

            }

        '7'
            {
                
                    BIOSCollection
                    
            }

        '8'
            {

                    PowerBattery

            }

        '9'

            {
            
                #Banner Dialog

                        Write-Host "`n`t`t **********************************************`n"
                        Write-Host "`n`t`t       CDATv$CDATVEr Quick Data Collection     `n"
                        Write-Host "`n`t`t **********************************************`n"

                # Working Message

                        Write-output "Gathering Data, please wait..."

                #Gathering Quick Data
                        
                        Write-output "Creating - System Quick Data, please wait..."

                        QuickData | Out-File .\Lenovo-CDAT$CDATv-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log

                        Write-Host "`n`t`Created - Lenovo-CDAT330-QuickData-9-$($Model)-$($SystemFamily)-$($SerialNumber)-$(((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")).log`n"

            }

        '10'

            {
                Write-Output "`nGathering System Potential Issues in to a report, please wait..."
                KnownIssues > CDAT$CDATv-Issues-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log
                Write-output "`n`tSaved to $(Get-Location)\CDAT$CDATv-Issues-$((Get-CimInstance -ClassName Win32_ComputerSystem).Model)-$($SystemFamily)-$($SerialNumber)-$($Time).log`n"
                    
                
            }


        '11'

                {

                        $BatteryBrand = (get-wmiobject -namespace root\wmi Batterystaticdata).ManufactureName
                        $BatteryPN = (Get-WmiObject -namespace root\wmi -class BatteryStaticData).DeviceName
                        $Model = (Get-CimInstance -ClassName Win32_ComputerSystem).Model
                        $SystemFamily = (Get-CimInstance -Class CIM_ComputerSystem).SystemFamily
                        $SerialNumber = (Get-CimInstance win32_bios).serialnumber
                        $Time = ((get-date).ToLocalTime()).ToString("MM-dd-yyyy HHmmss")
                        $BIOS1 = (Get-WmiObject win32_bios).SMBiosBIOSVersion
                        $ECMajor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMajorVersion
                        $ECMinor = (Get-WmiObject -Namespace root\CIMv2 -Class win32_bios).EmbeddedControllerMinorVersion
                        $Baseboard = (Get-WmiObject win32_baseboard).SerialNumber
                        $ProcDetect = (Get-WmiObject win32_processor).Manufacturer
                        $cycleCount = (get-wmiobject -namespace root\wmi batteryCycleCount).CycleCount



                        $x = [xelement]::new("SystemProperties",

                        [xelement]::new("SystemDetails",
                                
                                [xelement]::new("Date","$Time"),
                                [xelement]::new("Brand","$SystemFamily"),
                                [xelement]::new("Baseboard","$Baseboard"),
                                [xelement]::new("Arch","$ProcDetect"),
                                [xelement]::new("MTM","$Model"),
                                [xelement]::new("SN","$SerialNumber"),
                                [xelement]::new("BIOS","$BIOS1"),
                                [xelement]::new("EC","$($ECMajor).$($ECMinor)"),
                                [xelement]::new("BatteryBrand","$BatteryBrand"),
                                [xelement]::new("BatteryPN","$BatteryPN"),
                                [xelement]::new("BatteryCycle","$CycleCount")


                            )
                        
                        

                        )





                        ($x)  | Set-Content -Path ".\SystemProperties.xml"
                        
                    
                }
        'R'

                {
                
                    CDATHelp
                    
                }



     }

     pause
 }
 
 until ($selection -eq 'q')


# SIG # Begin signature block
# MIIoGQYJKoZIhvcNAQcCoIIoCjCCKAYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC4j2/kpj9keyJE
# cYDqWrIQP8nVbZfGPl6p3rG8hqy7EKCCISUwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXH
# JQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMf
# UBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w
# 1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRk
# tFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYb
# qMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUm
# cJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP6
# 5x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzK
# QtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo
# 80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjB
# Jgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXche
# MBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU
# 7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDig
# NqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZI
# hvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd
# 4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiC
# qBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl
# /Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeC
# RK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYT
# gAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/
# a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37
# xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmL
# NriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0
# YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJ
# RyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIG
# sDCCBJigAwIBAgIQCK1AsmDSnEyfXs2pvZOu2TANBgkqhkiG9w0BAQwFADBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# HhcNMjEwNDI5MDAwMDAwWhcNMzYwNDI4MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0
# ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0ExMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1bQvQtAorXi3XdU5WRuxiEL1M4zr
# PYGXcMW7xIUmMJ+kjmjYXPXrNCQH4UtP03hD9BfXHtr50tVnGlJPDqFX/IiZwZHM
# gQM+TXAkZLON4gh9NH1MgFcSa0OamfLFOx/y78tHWhOmTLMBICXzENOLsvsI8Irg
# nQnAZaf6mIBJNYc9URnokCF4RS6hnyzhGMIazMXuk0lwQjKP+8bqHPNlaJGiTUyC
# EUhSaN4QvRRXXegYE2XFf7JPhSxIpFaENdb5LpyqABXRN/4aBpTCfMjqGzLmysL0
# p6MDDnSlrzm2q2AS4+jWufcx4dyt5Big2MEjR0ezoQ9uo6ttmAaDG7dqZy3SvUQa
# khCBj7A7CdfHmzJawv9qYFSLScGT7eG0XOBv6yb5jNWy+TgQ5urOkfW+0/tvk2E0
# XLyTRSiDNipmKF+wc86LJiUGsoPUXPYVGUztYuBeM/Lo6OwKp7ADK5GyNnm+960I
# HnWmZcy740hQ83eRGv7bUKJGyGFYmPV8AhY8gyitOYbs1LcNU9D4R+Z1MI3sMJN2
# FKZbS110YU0/EpF23r9Yy3IQKUHw1cVtJnZoEUETWJrcJisB9IlNWdt4z4FKPkBH
# X8mBUHOFECMhWWCKZFTBzCEa6DgZfGYczXg4RTCZT/9jT0y7qg0IU0F8WD1Hs/q2
# 7IwyCQLMbDwMVhECAwEAAaOCAVkwggFVMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYD
# VR0OBBYEFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB8GA1UdIwQYMBaAFOzX44LScV1k
# TN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcD
# AzB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmww
# HAYDVR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQEMBQADggIB
# ADojRD2NCHbuj7w6mdNW4AIapfhINPMstuZ0ZveUcrEAyq9sMCcTEp6QRJ9L/Z6j
# fCbVN7w6XUhtldU/SfQnuxaBRVD9nL22heB2fjdxyyL3WqqQz/WTauPrINHVUHmI
# moqKwba9oUgYftzYgBoRGRjNYZmBVvbJ43bnxOQbX0P4PpT/djk9ntSZz0rdKOtf
# JqGVWEjVGv7XJz/9kNF2ht0csGBc8w2o7uCJob054ThO2m67Np375SFTWsPK6Wrx
# oj7bQ7gzyE84FJKZ9d3OVG3ZXQIUH0AzfAPilbLCIXVzUstG2MQ0HKKlS43Nb3Y3
# LIU/Gs4m6Ri+kAewQ3+ViCCCcPDMyu/9KTVcH4k4Vfc3iosJocsL6TEa/y4ZXDlx
# 4b6cpwoG1iZnt5LmTl/eeqxJzy6kdJKt2zyknIYf48FWGysj/4+16oh7cGvmoLr9
# Oj9FpsToFpFSi0HASIRLlk2rREDjjfAVKM7t8RhWByovEMQMCGQ8M4+uKIw8y4+I
# Cw2/O/TOHnuO77Xry7fwdxPm5yg/rBKupS8ibEH5glwVZsxsDsrFhsP2JjMMB0ug
# 0wcCampAMEhLNKhRILutG4UI4lkNbcoFUCvqShyepf2gpx8GdOfy1lKQ/a+FSCH5
# Vzu0nAPthkX0tGFuv2jiJmCG6sivqf6UHedjGzqGVnhOMIIGwjCCBKqgAwIBAgIQ
# BUSv85SdCDmmv9s/X+VhFjANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBMB4XDTIzMDcxNDAw
# MDAwMFoXDTM0MTAxMzIzNTk1OVowSDELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
# Z2lDZXJ0LCBJbmMuMSAwHgYDVQQDExdEaWdpQ2VydCBUaW1lc3RhbXAgMjAyMzCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAKNTRYcdg45brD5UsyPgz5/X
# 5dLnXaEOCdwvSKOXejsqnGfcYhVYwamTEafNqrJq3RApih5iY2nTWJw1cb86l+uU
# UI8cIOrHmjsvlmbjaedp/lvD1isgHMGXlLSlUIHyz8sHpjBoyoNC2vx/CSSUpIIa
# 2mq62DvKXd4ZGIX7ReoNYWyd/nFexAaaPPDFLnkPG2ZS48jWPl/aQ9OE9dDH9kgt
# XkV1lnX+3RChG4PBuOZSlbVH13gpOWvgeFmX40QrStWVzu8IF+qCZE3/I+PKhu60
# pCFkcOvV5aDaY7Mu6QXuqvYk9R28mxyyt1/f8O52fTGZZUdVnUokL6wrl76f5P17
# cz4y7lI0+9S769SgLDSb495uZBkHNwGRDxy1Uc2qTGaDiGhiu7xBG3gZbeTZD+BY
# QfvYsSzhUa+0rRUGFOpiCBPTaR58ZE2dD9/O0V6MqqtQFcmzyrzXxDtoRKOlO0L9
# c33u3Qr/eTQQfqZcClhMAD6FaXXHg2TWdc2PEnZWpST618RrIbroHzSYLzrqawGw
# 9/sqhux7UjipmAmhcbJsca8+uG+W1eEQE/5hRwqM/vC2x9XH3mwk8L9CgsqgcT2c
# kpMEtGlwJw1Pt7U20clfCKRwo+wK8REuZODLIivK8SgTIUlRfgZm0zu++uuRONhR
# B8qUt+JQofM604qDy0B7AgMBAAGjggGLMIIBhzAOBgNVHQ8BAf8EBAMCB4AwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAgBgNVHSAEGTAXMAgG
# BmeBDAEEAjALBglghkgBhv1sBwEwHwYDVR0jBBgwFoAUuhbZbU2FL3MpdpovdYxq
# II+eyG8wHQYDVR0OBBYEFKW27xPn783QZKHVVqllMaPe1eNJMFoGA1UdHwRTMFEw
# T6BNoEuGSWh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRH
# NFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5jcmwwgZAGCCsGAQUFBwEBBIGD
# MIGAMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wWAYIKwYB
# BQUHMAKGTGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0
# ZWRHNFJTQTQwOTZTSEEyNTZUaW1lU3RhbXBpbmdDQS5jcnQwDQYJKoZIhvcNAQEL
# BQADggIBAIEa1t6gqbWYF7xwjU+KPGic2CX/yyzkzepdIpLsjCICqbjPgKjZ5+PF
# 7SaCinEvGN1Ott5s1+FgnCvt7T1IjrhrunxdvcJhN2hJd6PrkKoS1yeF844ektrC
# QDifXcigLiV4JZ0qBXqEKZi2V3mP2yZWK7Dzp703DNiYdk9WuVLCtp04qYHnbUFc
# jGnRuSvExnvPnPp44pMadqJpddNQ5EQSviANnqlE0PjlSXcIWiHFtM+YlRpUurm8
# wWkZus8W8oM3NG6wQSbd3lqXTzON1I13fXVFoaVYJmoDRd7ZULVQjK9WvUzF4UbF
# KNOt50MAcN7MmJ4ZiQPq1JE3701S88lgIcRWR+3aEUuMMsOI5ljitts++V+wQtaP
# 4xeR0arAVeOGv6wnLEHQmjNKqDbUuXKWfpd5OEhfysLcPTLfddY2Z1qJ+Panx+VP
# NTwAvb6cKmx5AdzaROY63jg7B145WPR8czFVoIARyxQMfq68/qTreWWqaNYiyjvr
# moI1VygWy2nyMpqy0tg6uLFGhmu6F/3Ed2wVbK6rr3M66ElGt9V/zLY4wNjsHPW2
# obhDLN9OTH0eaHDAdwrUAuBcYLso/zjlUlrWrBciI0707NMX+1Br/wd3H3GXREHJ
# uEbTbDJ8WC9nR2XlG3O2mflrLAZG70Ee8PBf4NvZrZCARK+AEEGKMIIHZDCCBUyg
# AwIBAgIQBp8njCe2KeMfiG6lf1Y44zANBgkqhkiG9w0BAQsFADBpMQswCQYDVQQG
# EwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0
# IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0Ex
# MB4XDTI0MDgyMzAwMDAwMFoXDTI1MDkyMzIzNTk1OVowbDELMAkGA1UEBhMCVVMx
# FzAVBgNVBAgTDk5vcnRoIENhcm9saW5hMRQwEgYDVQQHEwtNb3JyaXN2aWxsZTEP
# MA0GA1UEChMGTGVub3ZvMQwwCgYDVQQLEwNHMTAxDzANBgNVBAMTBkxlbm92bzCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAPoezsFqB8Wx18Uukt2huCFQ
# Vh9p4vc2GK7ndvkyKVG1Uogs2xD/h+QZWkemAA88/lcF4HGbWvyczQLy1u88jadW
# 2I/tDd4HQ4ghbIiBL0H43rMT6rsK5NDuobB9PjpCYv+qRriZJ46Qaw5E19aHXrKy
# pRQXw+jk9EBc5wwelsHVGvSiPLtjLaHjO3+kiythmK0JbLCydBATtM5zCigPiZYY
# M3d3y5kYd93Ayjaw/NoogSxFkLQONhl977lKQTGZ6Rpi1GaP9uxPoAlkb3XOoQHH
# ETeApuzePOnMsH+TQ6L18/bSFamPfDqRk974kdy/4a2Xo121A7hL00Maqq0LlF+J
# Z5fw6nKOomUZJApw4ZC10bHmpQCs2IFCjLwRCbT+3WyY6bLJK4AKdfyhE5bksDxn
# AAvmYmhlm1CqI0n166+//CFQaN6hGO6ivh3tu7tC+YUmjdAeqnuVv/nRJ24XAAU9
# PFjkDhDhMm2X9vBaufH9b2J7nLvewcuouvjEsDvEmxvmH4Lh7f0ZpNQT0x+BXoDk
# x5z2zt9iA9YMP6LJarXE42VFwc+IpAIvHN0zXOh2Kl1dm59p1CXE6EXrXdCjIYxQ
# kvNl4dV4BSHYUn+6xNTaQ0v3IixsX7s4EjTRLbwL6HT2Tf8ABSN7NEjLDPDUnUQw
# vSn9AeUTbYjAP3R9IqXFAgMBAAGjggIDMIIB/zAfBgNVHSMEGDAWgBRoN+Drtjv4
# XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQUTUBc+SI3TdqU+ymSgO/O8tOqPk8wPgYD
# VR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEFBQcCARYbaHR0cDovL3d3dy5kaWdp
# Y2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcD
# AzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0Ex
# LmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1
# c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwgZQGCCsG
# AQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5j
# b20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3J0
# MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQADggIBAIC9m83bvFoRZU358OdVc5ot
# VnBpPaLXoV3jxRKOKDB0v2aF++rC6SFsIm9k4psZ41okb0jsI56TI5dH/FrZku/M
# zg6lIvNmCVskkxXm+R+R6y7I/wY4utOnT3945SjaIe/U2hdxmmP5JTffnzbGyoXa
# rOpQyQi0LW+7bDNnLelMwRC+UsZKq0TV6u5lvWaOQN6fwJLNlHiKGVnAMG8fbaH0
# H7eHfFCGpS2QT/xmdZLMgCt/vQvEnfPBmeZOW22bb4EMHnPVgKTWye33y6bRpOQi
# WiUseqqbGJN8HsocPS3hpHTa8dhYZgd0+w3dBoyezcWxPc16ie/JgfgwQgrMa47z
# ave6cZfVWpiv2BCCgU3enoRIee6nr5i5trRrlDCglzZt7zymqoheVLeD58rz8X5l
# aT+kFCXjmpLkn0hChF3xAJWAc/eWOV7A5AmNKQCq0waDAo1yUepgRlcJtkcn9LaN
# 8Ls87WbHfaZ5e1VVIMyzfAap4YMwAefwnHtVA4AtrFwlHSDbSLM/wKvFux7+6N5p
# kF1N8EKtmTQ4CQ8TNl/87SUy/jiTuHTNuOeCquNh8Ak+j02lph4Snyt4J0+hQNWv
# JJyXC7+ol+50UlJaYsHWkEYHbO8COrA5+Qxs0pn1JxpSJ9grUtrr0faPCehdffT+
# ALDA2mX7hXLi4xCzksb6MYIGSjCCBkYCAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUG
# A1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQg
# RzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0ExAhAGnyeMJ7Yp
# 4x+IbqV/VjjjMA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJ
# KoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQB
# gjcCARUwLwYJKoZIhvcNAQkEMSIEIBNWRNU3x8WydbTYkwwuaDLqQAdDEohGFR7x
# 52hsNwC9MA0GCSqGSIb3DQEBAQUABIICAHj6u0gyCfXeV6SX24sn9828b2hxlP2D
# cACppLWoE1P4bTENDp/T4PRhiy0ps9xdt//VPdtYmPmk1eMg2zkUhIdvviVDIj61
# dcXoPDIsgFaPBNnzqIsEy/1ulWc3HwLZUW9c4gVF5QhVwjq2u27T8W9N09ifaNCg
# SD8e7QM2pT716/DwsS8lg23vLFxhBtWVJwc4ume9Tg+YUdNsqDIFyUbXRS+zT0Ae
# lq5VNEZZfsY9B/Q0BrF/4iYw4GirYVTanTM0uAQGVwFCJZ/mXexFEgA8cnyU01Bk
# 2mpDGR1sGAbu+e26uGKDJhJtappL+VBXVLxV/ZLMDu30yDqc3oikzlaP40cUndpY
# cNMrwEKu8Ace84192yPdSiccekaVxCh15fGgcxfQXAp2khUQbzHsUB+TcbtxoEfm
# 15CEyyeTywek7+0Af6c+fmLuHQim4qgQjOhSESq9DzQYYO9K/ySjbS93VEbMZeCx
# YNPh+m11CAJp9AVDo/0DgxkxF+s4ikLdMWXgOkVfHOSPRnJO2lMspFngl7t69NBx
# pHBsZlV7pdUxODYGNieAi9FRvC+STW2/dKjihoXQNBHD07lzxRlsBBaiqBduJ07R
# KmyZmfEg/L7okAMUoOWIJpmEMD8OIP3BTjDkJMrhXav9+T/H7uQzxQ2eNcOtGHB3
# 2VgWO310wxv3oYIDIDCCAxwGCSqGSIb3DQEJBjGCAw0wggMJAgEBMHcwYzELMAkG
# A1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdp
# Q2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQQIQ
# BUSv85SdCDmmv9s/X+VhFjANBglghkgBZQMEAgEFAKBpMBgGCSqGSIb3DQEJAzEL
# BgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTI0MDkwNTE3NTYwMVowLwYJKoZI
# hvcNAQkEMSIEIAIG5yj5IEuOKErP0ToWHn2hZ3ynQtgma3MGtGKtgSBrMA0GCSqG
# SIb3DQEBAQUABIICAAp9kzt2gevhTmNwVy5PSZN6X3saEHL2UPQ9kJ5qzXpnXALV
# LicG/xt5FgalwnKNOQBIDSyGU4yMR+RnB4BT+lYaJFQ1okUweG+f0NK5h8opQbww
# cZmFskqGlPpw5QjdKIchRtGyNLeaMriQMMWd8ZZ7HgV9vFtpn9aehT/hdemMR8XR
# QnD6XvsmqkSm3XCMBfDzc1ZgO+nx7kNoY/4t1ltzA3iuXCaNohty2xwpc/6ztXH3
# AwsVit6Lop1JlyCowjLA7LHwzoUp5oLuPzgB91JIf/zBEMT2yqNkZ2lNcYKUtPKL
# wSWE2zg//GSQnscXDZCgTyCIQHOdj1Ochp8+6btBjts2uw98CpSDmFpUs2xxAA3R
# YTJeQHC3asIIodbgW/MquAU0iuhPgB33jFzn2u4pDTqFh+U16Hu2ElIl9TEOanuo
# Br0dUZaosLzVVMtRtdNa58b86S0gvZB+8eH0ztIgNDDapMmHkM4dvD00tckSZmcg
# 873x4822/PccDWl6uxRSE1wd3S2RWlH1oKuSp260Eo88HjQ+1k9hzxjgyAfF2tXt
# WaCOPZqXKn1AvX7ik6t4rs8eiqI10zTaZ64XTHr6AKg0jRfHbyhJFxE71QDpDBAp
# rypcJJp+Ut8cvX1LoL1lPuMbM6LCnQy+PqLDfnVCyQNx5WGRmi9So1P5PPW7
# SIG # End signature block
